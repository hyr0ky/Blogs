
### General Review Approach:  一般审查方法：

- Read the project's docs, specs, and whitepaper to understand what the smart contracts are meant to do.  
    阅读项目的文档、规格和白皮书，了解智能合约的作用。
- Construct a mental model of what you expect the contracts to look like before checking out the code.  
    在检查代码之前，构建一个你期望合同是什么样子的心理模型。
- Glance over the contracts to get a sense of the project's architecture. Tools like Surya can come in handy.  
    浏览一下合约，了解一下项目的架构。像 Surya 这样的工具会派上用场。
- Compare the architecture to your mental model. Look into areas that are surprising.  
    将架构与你的思维模型进行比较。寻找令人惊讶的地方。
- Create a threat model and make a list of theoretical high level attack vectors.  
    创建威胁模型并列出理论上的高级攻击媒介。
- Look at areas that can do value exchange. Especially functions like `transfer`, `transferFrom`, `send`, `call`, `delegatecall`, and `selfdestruct`. Walk backward from them to ensure they are secured properly.  
    检查可以进行值交换的区域。尤其是像 `transfer` 、 `transferFrom` 、 `send` 、 `call` 、 `delegatecall` 和 `selfdestruct` 这样的函数。从这些函数开始倒推，确保它们得到了妥善保护。
- Look at areas that interface with external contracts and ensure all assumptions about them are valid like share price only increases, etc.  
    查看与外部合同接口的区域，并确保对它们的所有假设都是有效的，例如股价仅上涨等。
- Do a generic line-by-line review of the contracts.  
    对合同进行逐行审查。
- Do another review from the perspective of every actor in the threat model.  
    从威胁模型中每个参与者的角度进行另一次审查。
- Glance over the project's tests + code coverage and look deeper at areas lacking coverage.  
    浏览项目的测试 + 代码覆盖率，并深入了解缺乏覆盖的区域。
- Run tools like Slither/Solhint and review their output.  
    运行 Slither/Solhint 等工具并查看其输出。
- Look at related projects and their audits to check for any similar issues or oversights.  
    查看相关项目及其审计，检查是否存在任何类似的问题或疏忽。

## Variables  变量

- `V1` - Can it be `internal`?  
    `V1` 它可以是 `internal` 吗？
- `V2` - Can it be `constant`?  
    `V2` 它可以是 `constant` 吗？
- `V3` - Can it be `immutable`?  
    `V3` 它可以是 `immutable` 吗？
- `V4` - Is its visibility set? (SWC-108)  
    `V4` - 它的可见性设置了吗？（SWC-108）
- `V5` - Is the purpose of the variable and other important information documented using natspec?  
    `V5` - 变量的用途和其他重要信息是否使用 natspec 记录？
- `V6` - Can it be packed with an adjacent storage variable?  
    `V6` - 它可以与相邻的存储变量一起打包吗？
- `V7` - Can it be packed in a struct with more than 1 other variable?  
    `V7` - 它可以与 1 个以上的其他变量一起打包在一个结构中吗？
- `V8` - Use full 256 bit types unless packing with other variables.  
    `V8` - 除非与其他变量打包，否则使用完整的 256 位类型。
- `V9` - If it's a public array, is a separate function provided to return the full array?  
    `V9` - 如果它是一个公共数组，是否提供了单独的函数来返回完整数组？
- `V10` - Only use `private` to intentionally prevent child contracts from accessing the variable, prefer `internal` for flexibility.  
    `V10` - 仅使用 `private` 来有意阻止子合约访问变量，为了灵活性，优先使用 `internal` 。

## Structs  结构
- `S1` - Is a struct necessary? Can the variable be packed raw in storage?  
    `S1` - 结构体是必需的吗？变量可以以原始形式打包到存储中吗？
- `S2` - Are its fields packed together (if possible)?  
    `S2` 它的字段是否打包在一起（如果可能的话）？
- `S3` - Is the purpose of the struct and all fields documented using natspec?  
    `S3` - 结构和所有字段的用途是否使用 natspec 记录？

## Functions  功能

- `F1` - Can it be `external`?  
    `F1` 可以是 `external` 吗？
- `F2` - Should it be `internal`?  
    `F2` 它应该是 `internal` 吗？
- `F3` - Should it be `payable`?  
    `F3` 是否应 `payable` ？
- `F4` - Can it be combined with another similar function?  
    `F4` 它可以与其他类似功能结合使用吗？
- `F5` - Validate all parameters are within safe bounds, even if the function can only be called by a trusted users.  
    `F5` 验证所有参数都在安全范围内，即使该函数只能由受信任的用户调用。
- `F6` - Is the checks before effects pattern followed? (SWC-107)  
    `F6` - 是否遵循了效果前的检查模式？（SWC-107）
- `F7` - Check for front-running possibilities, such as the approve function. (SWC-114)  
    `F7` - 检查是否存在抢先交易的可能性，例如批准功能。(SWC-114)
- `F8` - Is insufficient gas griefing possible? (SWC-126)  
    `F8` - 气体不足会导致悲伤吗？（SWC-126）
- `F9` - Are the correct modifiers applied, such as `onlyOwner`/`requiresAuth`?  
    `F9` - 是否应用了正确的修饰符，例如 `onlyOwner` / `requiresAuth` ？
- `F10` - Are return values always assigned?  
    `F10` 返回值总是被分配吗？
- `F11` - Write down and test invariants about state before a function can run correctly.  
    `F11` 在函数正确运行之前，写下并测试有关状态的不变量。
- `F12` - Write down and test invariants about the return or any changes to state after a function has run.  
    `F12` 写下并测试有关函数运行后返回或任何状态变化的不变量。
- `F13` - Take care when naming functions, because people will assume behavior based on the name.  
    `F13` 命名函数时要小心，因为人们会根据名称假设行为。
- `F14` - If a function is intentionally unsafe (to save gas, etc), use an unwieldy name to draw attention to its risk.  
    `F14` - 如果某个功能故意不安全（为了节省 gas 等），请使用一个难以理解的名称来引起人们对其风险的注意。
- `F15` - Are all arguments, return values, side effects and other information documented using natspec?  
    `F15` 所有参数、返回值、副作用和其他信息是否都使用 natspec 记录？
- `F16` - If the function allows operating on another user in the system, do not assume `msg.sender` is the user being operated on.  
    `F16` - 如果该函数允许对系统中的另一个用户进行操作，则不要假定 `msg.sender` 是被操作的用户。
- `F17` - If the function requires the contract be in an uninitialized state, check an explicit `initialized` variable. Do not use `owner == address(0)` or other similar checks as substitutes.  
    `F17` - 如果函数要求合约处于未初始化状态，请检查显式 `initialized` 变量。请勿使用 `owner == address(0)` 或其他类似的检查来替代。
- `F18` - Only use `private` to intentionally prevent child contracts from calling the function, prefer `internal` for flexibility.  
    `F18` - 仅使用 `private` 来有意阻止子合约调用该函数，为了灵活性，优先使用 `internal` 。
- `F19` - Use `virtual` if there are legitimate (and safe) instances where a child contract may wish to override the function's behavior.  
    `F19` - 如果存在合法（且安全）的实例，并且子合约可能希望覆盖函数的行为，则使用 `virtual` 。

## Modifiers  修饰符

- `M1` - Are no storage updates made (except in a reentrancy lock)?  
    `M1` 没有进行存储更新（重入锁除外）？
- `M2` - Are external calls avoided?  
    `M2` 是否避免外部呼叫？
- `M3` - Is the purpose of the modifier and other important information documented using natspec?  
    `M3` 修饰符的用途和其他重要信息是否使用 natspec 记录？

## Code  代码

- `C1` - Using SafeMath or 0.8 checked math? (SWC-101)  
    `C1` - 使用 SafeMath 或 0.8 检查数学？（SWC-101）
- `C2` - Are any storage slots read multiple times?  
    `C2` 是否有任何存储槽被多次读取？
- `C3` - Are any unbounded loops/arrays used that can cause DoS? (SWC-128)  
    `C3` - 是否使用了任何可能导致 DoS 的无界循环/数组？(SWC-128)
- `C4` - Use `block.timestamp` only for long intervals. (SWC-116)  
    `C4` - 仅对长时间间隔使用 `block.timestamp` 。(SWC-116)
- `C5` - Don't use block.number for elapsed time. (SWC-116)  
    `C5` - 不要使用 block.number 来表示已用时间。(SWC-116)
- `C7` - Avoid delegatecall wherever possible, especially to external (even if trusted) contracts. (SWC-112)  
    `C7` - 尽可能避免委托调用，尤其是对于外部合约（即使是可信的）。(SWC-112)
- `C8` - Do not update the length of an array while iterating over it.  
    `C8` 迭代数组时不要更新其长度。
- `C9` - Don't use `blockhash()`, etc for randomness. (SWC-120)  
    `C9` - 不要使用 `blockhash()` 等来实现随机性。(SWC-120)
- `C10` - Are signatures protected against replay with a nonce and `block.chainid` (SWC-121)  
    `C10` - 签名是否可以通过 nonce 和 `block.chainid` 防止重放 (SWC-121)
- `C11` - Ensure all signatures use EIP-712. (SWC-117 SWC-122)  
    `C11` - 确保所有签名都使用 EIP-712。(SWC-117 SWC-122)
- `C12` - Output of `abi.encodePacked()` shouldn't be hashed if using >2 dynamic types. Prefer using `abi.encode()` in general. (SWC-133)  
    `C12` - 如果使用 2 个以上的动态类型，则不应对 `abi.encodePacked()` 的输出进行哈希处理。一般情况下，建议使用 `abi.encode()` 。(SWC-133)
- `C13` - Careful with assembly, don't use any arbitrary data. (SWC-127)  
    `C13` - 组装时请小心，不要使用任何任意数据。(SWC-127)
- `C14` - Don't assume a specific ETH balance. (SWC-132)  
    `C14` - 不要假设特定的 ETH 余额。(SWC-132)
- `C15` - Avoid insufficient gas griefing. (SWC-126)  
    `C15` - 避免因气体不足而造成的破坏。(SWC-126)
- `C16` - Private data isn't private. (SWC-136)  
    `C16` - 私人数据并非私密。(SWC-136)
- `C17` - Updating a struct/array in memory won't modify it in storage.  
    `C17` 更新内存中的结构/数组不会在存储中修改它。
- `C18` - Never shadow state variables. (SWC-119)  
    `C18` - 切勿隐藏状态变量。(SWC-119)
- `C19` - Do not mutate function parameters.  
    `C19` 不要改变函数参数。
- `C20` - Is calculating a value on the fly cheaper than storing it?  
    `C20` - 即时计算一个值比存储它更便宜吗？
- `C21` - Are all state variables read from the correct contract (master vs. clone)?  
    `C21` - 所有状态变量是否都是从正确的合约（主合约与克隆合约）读取的？
- `C22` - Are comparison operators used correctly (`>`, `<`, `>=`, `<=`), especially to prevent off-by-one errors?  
    `C22` — 比较运算符是否使用正确（ `>` 、 `<` 、 `>=` 、 `<=` ），特别是为了防止出现偏差一错误？
- `C23` - Are logical operators used correctly (`==`, `!=`, `&&`, `||`, `!`), especially to prevent off-by-one errors?  
    `C23` — 逻辑运算符是否使用正确（ `==` 、 `!=` 、 `&&` 、 `||` 、 `!` ），特别是为了防止出现偏差一错误？
- `C24` - Always multiply before dividing, unless the multiplication could overflow.  
    `C24` 总是先乘后除，除非乘法可能溢出。
- `C25` - Are magic numbers replaced by a constant with an intuitive name?  
    `C25` 魔术数字是否被具有直观名称的常数所取代？
- `C26` - If the recipient of ETH had a fallback function that reverted, could it cause DoS? (SWC-113)  
    `C26` - 如果 ETH 的接收方有一个回退函数，它会导致 DoS 攻击吗？(SWC-113)
- `C27` - Use SafeERC20 or check return values safely.  
    `C27` 使用 SafeERC20 或安全地检查返回值。
- `C28` - Don't use `msg.value` in a loop.  
    `C28` 不要在循环中使用 `msg.value` 。
- `C29` - Don't use `msg.value` if recursive delegatecalls are possible (like if the contract inherits `Multicall`/`Batchable`).  
    `C29` 如果可以进行递归委托调用（例如，如果合约继承了 `Multicall` / `Batchable` ），请不要使用 `msg.value` 。
- `C30` - Don't assume `msg.sender` is always a relevant user.  
    `C30` 不要假设 `msg.sender` 始终是相关用户。
- `C31` - Don't use `assert()` unless for fuzzing or formal verification. (SWC-110)  
    `C31` - 除非用于模糊测试或形式验证，否则请勿使用 `assert()` 。(SWC-110)
- `C32` - Don't use `tx.origin` for authorization. (SWC-115)  
    `C32` - 不要使用 `tx.origin` 进行授权。(SWC-115)
- `C33` - Don't use `address.transfer()` or `address.send()`. Use `.call.value(...)("")` instead. (SWC-134)  
    `C33` - 不要使用 `address.transfer()` 或 `address.send()` 。请改用 `.call.value(...)("")` 。(SWC-134)
- `C34` - When using low-level calls, ensure the contract exists before calling.  
    `C34` - 使用低级调用时，请确保调用前合约存在。
- `C35` - When calling a function with many parameters, use the named argument syntax.  
    `C35` 当调用具有许多参数的函数时，使用命名参数语法。
- `C36` - Do not use assembly for create2. Prefer the modern salted contract creation syntax.  
    `C36` - 不要使用汇编来创建 create2 函数。建议使用现代的 salted 合约创建语法。
- `C37` - Do not use assembly to access chainid or contract code/size/hash. Prefer the modern Solidity syntax.  
    `C37` - 不要使用汇编来访问 chainid 或合约代码/大小/哈希值。建议使用现代 Solidity 语法。
- `C38` - Use the `delete` keyword when setting a variable to a zero value (`0`, `false`, `""`, etc).  
    `C38` - 将变量设置为零值（ `0` 、 `false` 、 `""` 等）时使用 `delete` 关键字。
- `C39` - Comment the "why" as much as possible.  
    `C39` 尽可能多地评论“为什么”。
- `C40` - Comment the "what" if using obscure syntax or writing unconventional code.  
    `C40` 如果使用模糊的语法或编写非常规代码，则注释“什么”。
- `C41` - Comment explanations + example inputs/outputs next to complex and fixed point math.  
    `C41` - 复杂和定点数学旁边的评论解释+示例输入/输出。
- `C42` - Comment explanations wherever optimizations are done, along with an estimate of much gas they save.  
    `C42` - 无论在何处进行优化，都要进行评论解释，并估算节省的气体量。
- `C43` - Comment explanations wherever certain optimizations are purposely avoided, along with an estimate of much gas they would/wouldn't save if implemented.  
    `C43` - 在故意避免某些优化的地方进行评论解释，以及实施后可以/不能节省的气体估计量。
- `C44` - Use `unchecked` blocks where overflow/underflow is impossible, or where an overflow/underflow is unrealistic on human timescales (counters, etc). Comment explanations wherever `unchecked` is used, along with an estimate of how much gas it saves (if relevant).  
    `C44` - 当溢出/下溢不可能发生，或者溢出/下溢在人类时间尺度（计数器等）上不切实际时，请使用 `unchecked` 块。请在注释中解释使用 `unchecked` 原因，并估算其节省的 gas 量（如适用）。
- `C45` - Do not depend on Solidity's arithmetic operator precedence rules. In addition to the use of parentheses to override default operator precedence, parentheses should also be used to emphasise it.  
    `C45` - 不要依赖 Solidity 的算术运算符优先级规则。除了使用括号覆盖默认运算符优先级外，还应使用括号来强调它。
- `C46` - Expressions passed to logical/comparison operators (`&&`/`||`/`>=`/`==`/etc) should not have side-effects.  
    `C46` 传递给逻辑/比较运算符（ `&&` / `||` / `>=` / `==` /等）的表达式不应该有副作用。
- `C47` - Wherever arithmetic operations are performed that could result in precision loss, ensure it benefits the right actors in the system, and document it with comments.  
    `C47` - 无论在何处执行可能导致精度损失的算术运算，都要确保它使系统中的正确参与者受益，并用注释记录下来。
- `C48` - Document the reason why a reentrancy lock is necessary whenever it's used with an inline or `@dev` natspec comment.  
    `C48` - 记录当使用内联或 `@dev` natspec 注释时需要重入锁的原因。
- `C49` - When fuzzing functions that only operate on specific numerical ranges use modulo to tighten the fuzzer's inputs (such as `x = x % 10000 + 1` to restrict from 1 to 10,000).  
    `C49` - 当模糊测试函数仅在特定数值范围内运行时，使用模数来收紧模糊测试器的输入（例如 `x = x % 10000 + 1` 限制从 1 到 10,000）。
- `C50` - Use ternary expressions to simplify branching logic wherever possible.  
    `C50` 尽可能使用三元表达式来简化分支逻辑。
- `C51` - When operating on more than one address, ask yourself what happens if they're the same.  
    `C51` - 当对多个地址进行操作时，问问自己如果它们相同会发生什么。

## External Calls  外部调用

- `X1` - Is an external contract call actually needed?  
    `X1` 实际上是否需要外部合约调用？
- `X2` - If there is an error, could it cause DoS? Like `balanceOf()` reverting. (SWC-113)  
    `X2` - 如果出现错误，会导致 DoS 攻击吗？比如 `balanceOf()` 回滚。(SWC-113)
- `X3` - Would it be harmful if the call reentered into the current function?  
    `X3` - 如果调用重新进入当前函数会有害吗？
- `X4` - Would it be harmful if the call reentered into another function?  
    `X4` - 如果调用重新进入另一个函数会有害吗？
- `X5` - Is the result checked and errors dealt with? (SWC-104)  
    `X5` - 是否检查结果并处理错误？（SWC-104）
- `X6` - What if it uses all the gas provided?  
    `X6` - 如果它用完了所提供的所有气体怎么办？
- `X7` - Could it cause an out-of-gas in the calling contract if it returns a massive amount of data?  
    `X7` 如果返回大量数据，是否会导致调用合约耗尽 gas？
- `X8` - If you are calling a particular function, do not assume that `success` implies that the function exists (phantom functions).  
    `X8` - 如果您正在调用特定函数，请不要假设 `success` 意味着该函数存在（幻影函数）。

## Static Calls  静态调用

- `S1` - Is an external contract call actually needed?  
    `S1` 是否确实需要外部合约调用？
- `S2` - Is it actually marked as view in the interface?  
    `S2` - 它实际上在界面中被标记为视图吗？
- `S3` - If there is an error, could it cause DoS? Like `balanceOf()` reverting. (SWC-113)  
    `S3` - 如果发生错误，会导致 DoS 攻击吗？例如 `balanceOf()` 的回滚。(SWC-113)
- `S4` - If the call entered an infinite loop, could it cause DoS?  
    `S4` - 如果呼叫进入无限循环，是否会导致 DoS？

## Events  活动

- `E1` - Should any fields be indexed?  
    `E1` 是否应为任何字段建立索引？
- `E2` - Is the creator of the relevant action included as an indexed field?  
    `E2` 相关操作的创建者是否包含在索引字段中？
- `E3` - Do not index dynamic types like strings or bytes.  
    `E3` 不要索引字符串或字节等动态类型。
- `E4` - Is when the event emitted and all fields documented using natspec?  
    `E4` - 事件何时发出并且所有字段是否使用 natspec 记录？
- `E5` - Are all users/ids that are operated on in functions that emit the event stored as indexed fields?  
    `E5` - 在发出事件的函数中操作的所有用户/ID 是否都存储为索引字段？
- `E6` - Avoid function calls and evaluation of expressions within event arguments. Their order of evaluation is unpredictable.  
    `E6` - 避免在事件参数中使用函数调用和表达式求值。它们的求值顺序不可预测。

## Contract  合同

- `T1` - Use an SPDX license identifier.  
    `T1` - 使用 SPDX 许可证标识符。
- `T2` - Are events emitted for every storage mutating function?  
    `T2` - 每个存储变异函数都会发出事件吗？
- `T3` - Check for correct inheritance, keep it simple and linear. (SWC-125)  
    `T3` - 检查正确的继承，保持简单且线性。(SWC-125)
- `T4` - Use a `receive() external payable` function if the contract should accept transferred ETH.  
    `T4` - 如果合约应该接受转移的 ETH，则使用 `receive() external payable` 函数。
- `T5` - Write down and test invariants about relationships between stored state.  
    `T5` 写下并测试有关存储状态之间关系的不变量。
- `T6` - Is the purpose of the contract and how it interacts with others documented using natspec?  
    `T6` - 合同的目的以及它如何与其他合同交互是否使用 natspec 记录？
- `T7` - The contract should be marked `abstract` if another contract must inherit it to unlock its full functionality.  
    `T7` - 如果另一个合同必须继承该合同才能解锁其全部功能，则该合同应标记为 `abstract` 。
- `T8` - Emit an appropriate event for any non-immutable variable set in the constructor that emits an event when mutated elsewhere.  
    `T8` - 为构造函数中设置的任何非不可变变量发出适当的事件，当该变量在其他地方发生变异时，该变量会发出事件。
- `T9` - Avoid over-inheritance as it masks complexity and encourages over-abstraction.  
    `T9` 避免过度继承，因为它掩盖了复杂性并鼓励过度抽象。
- `T10` - Always use the named import syntax to explicitly declare which contracts are being imported from another file.  
    `T10` 始终使用命名导入语法来明确声明从另一个文件导入哪些合同​​。
- `T11` - Group imports by their folder/package. Separate groups with an empty line. Groups of external dependencies should come first, then mock/testing contracts (if relevant), and finally local imports.  
    `T11` - 按文件夹/包对导入进行分组。各组之间用空行分隔。外部依赖项的组应放在最前面，然后是模拟/测试合约（如果相关），最后是本地导入。
- `T12` - Summarize the purpose and functionality of the contract with a `@notice` natspec comment. Document how the contract interacts with other contracts inside/outside the project in a `@dev` natspec comment.  
    `T12` - 使用 `@notice` natspec 注释总结合约的目的和功能。使用 `@dev` natspec 注释记录合约如何与项目内外的其他合约交互。

## Project  项目

- `P1` - Use the right license (you must use GPL if you depend on GPL code, etc).  
    `P1` - 使用正确的许可证（如果您依赖 GPL 代码等，则必须使用 GPL）。
- `P2` - Unit test everything.  
    `P2` 对所有内容进行单元测试。
- `P3` - Fuzz test as much as possible.  
    `P3` 尽可能进行模糊测试。
- `P4` - Use symbolic execution where possible.  
    `P4` 尽可能使用符号执行。
- `P5` - Run Slither/Solhint and review all findings.  
    `P5` 运行 Slither/Solhint 并检查所有发现。

## DeFi

- `D1` - Check your assumptions about what other contracts do and return.  
    `D1` 检查您对其他合同的作用和回报的假设。
- `D2` - Don't mix internal accounting with actual balances.  
    `D2` 不要将内部会计与实际余额混淆。
- `D3` - Don't use spot price from an AMM as an oracle.  
    `D3` 不要使用 AMM 的现货价格作为预言机。
- `D4` - Do not trade on AMMs without receiving a price target off-chain or via an oracle.  
    `D4` - 在没有通过链下或预言机收到价格目标的情况下，请勿在 AMM 上进行交易。
- `D5` - Use sanity checks to prevent oracle/price manipulation.  
    `D5` 使用健全性检查来防止预言机/价格操纵。
- `D6` - Watch out for rebasing tokens. If they are unsupported, ensure that property is documented.  
    `D6` - 注意变基令牌。如果它们不受支持，请确保该属性已记录在案。
- `D7` - Watch out for ERC-777 tokens. Even a token you trust could preform reentrancy if it's an ERC-777.  
    `D7` - 警惕 ERC-777 代币。即使是你信任的代币，如果是 ERC-777 代币，也可能被重入。
- `D8` - Watch out for fee-on-transfer tokens. If they are unsupported, ensure that property is documented.  
    `D8` - 注意转账手续费代币。如果不支持，请确保该属性已记录在案。
- `D9` - Watch out for tokens that use too many or too few decimals. Ensure the max and min supported values are documented.  
    `D9` - 注意使用过多或过少小数的令牌。确保记录支持的最大值和最小值。
- `D10` - Be careful of relying on the raw token balance of a contract to determine earnings. Contracts which provide a way to recover assets sent directly to them can mess up share price functions that rely on the raw Ether or token balances of an address.  
    `D10` - 谨慎依赖合约的原始代币余额来确定收益。如果合约提供了直接收回资产的方式，可能会扰乱依赖于地址原始以太币或代币余额的股价函数。
- `D11` - If your contract is a target for token approvals, do not make arbitrary calls from user input.  
    `D11` - 如果您的合约是代币批准的目标，请不要根据用户输入进行任意调用。
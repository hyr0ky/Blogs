# First Step
## Download Code
>while performing security audit,brings the tools you're familier and best with.
```ad-tip
无论什么项目，试试foundry开始，即使很丑陋呢
```
## Read fuck document
```ad-caution
<font color="#ff0000">阅读文档</font>，**一些功能可能非常正常**，但并不是该项目预期想要的功能
```
```ad-tip
use **CLOC** and **Solidity Metrics**

`brew install cloc` or `sudo apt install cloc`
`npm install -g solidity-code-metrics` or 在vs codium 里面下载solidity-metrics插件
```
- Cloc
	- `cloc --by-file --include-ext=sol [dir]`
- Solidity Metrics
	 - Solidity-code-metrics xxx.sol
	 - vs codium 选择文件夹->右键最下面 Solidity metrics
	 ![[78451004-0252de00-7683-11ea-93d7-4c5dc436a14b.gif]]
# Audit, Review, Audit, Repeat
## First step
>从**最小**的合同开始
## 改变思考方式
> *How can I break it?*
- 阅读每一行代码
- 记录此时自己可能攻击的想法
- 转而其他代码（跳出**兔子洞**）
- 联想不同代码
```ad-caution
不要过度深入其中一部分代码
```
## 沟通
> 代码开发者总是更知道代码的目的
- 尝试和代码开发者沟通
## 时间限制
>没必要害怕自己审不过漏洞，漏洞总是存在的
```ad-tip
给自己审计做一个时间限制
```
#### 2. 工具分类与应用场景
| 工具类型       | 代表工具                 | 作用场景                                 | 示例案例                                      |
|----------------|--------------------------|------------------------------------------|---------------------------------------------|
| **测试套件**   | Foundry, Hardhat         | 基础功能验证，覆盖常规用例               | `CaughtWithTest.sol` 的单元测试              |
| **静态分析**   | Slither, Aderyn          | 快速检测已知模式（如重入、溢出）         | `CaughtWithSlither.sol` 中的重入漏洞检测     |
| **模糊测试**   | Foundry Fuzzing          | 发现边界条件与异常输入导致的漏洞         | `CaughtWithFuzz.sol` 通过随机输入触发返回0   |
| **形式化验证** | Solidity 模型检查器      | 数学证明代码属性（如断言永不触发）       | `CaughtWithSymbolic.sol` 的断言违反检测      |
| **AI辅助工具** | GPT-4, Copilot           | 快速理解代码逻辑，生成测试框架           | 生成模糊测试模板或解释复杂合约逻辑          |



### 安装 Warnet

Warnet 运行于 Kubernetes（k8s）环境，需通过 Helm 包管理工具部署。  
支持本地集群（如 Minikube、Docker Desktop、k3d）或云端集群（如 Google GKE、Digital Ocean 等）。  
需提前安装 `kubectl` 和 `helm` 并确保其位于系统环境变量 `$PATH` 中。

### 步骤 1：安装 Warnet

#### 方式一：通过 pip 安装（推荐）
```bash
# 创建并激活 Python 虚拟环境
python3 -m venv .venv
source .venv/bin/activate

# 安装 Warnet
pip install warnet
```

#### 方式二：通过源码安装
```bash
# 克隆仓库并进入目录
git clone https://github.com/bitcoin-dev-project/warnet.git
cd warnet

# 创建并激活虚拟环境
python3 -m venv .venv
source .venv/bin/activate

# 本地安装（开发模式）
pip install -e .
```

### 步骤 2：安装依赖项

#### 必须工具
- **`kubectl`**: Kubernetes 命令行工具 ([安装指南](https://kubernetes.io/zh-cn/docs/tasks/tools/))  
- **`helm`**: Helm 包管理器 ([安装指南](https://helm.sh/zh/docs/intro/install/))  

可通过系统包管理器（如 `apt`、`brew`）或直接下载二进制文件安装。  
若需通过 Warnet 自动安装依赖，运行：
```bash
source .venv/bin/activate  # 确保虚拟环境已激活
warnet setup               # 跟随引导安装依赖
```
### 步骤 3：配置本地 Kubernetes 集群

#### 选项一：Docker Desktop
1. 安装 [Docker Desktop](https://www.docker.com/products/docker-desktop/)  
2. 在设置中启用 Kubernetes 功能并启动集群。

#### 选项二：Minikube
1. 先安装 [Docker](https://docs.docker.com/engine/install/)  
2. 安装并启动 Minikube：
```bash
minikube start
```
3. 验证运行状态：[Minikube 入门指南](https://kubernetes.io/zh-cn/docs/tutorials/hello-minikube/)

### 步骤 4：验证工具配置
运行以下命令确保 `kubectl` 和 `helm` 正常工作：
```bash
helm repo add examples https://helm.github.io/examples
helm install hello examples/hello-world
helm list
kubectl get pods    # 应看到 "hello-world" Pod 运行中
helm uninstall hello
```

---

### 步骤 5：启动 Warnet 网络

#### 初始化网络
```bash
# 在当前目录创建新网络
warnet init

# 或在指定目录创建
warnet new <目录路径>
```

#### 注意事项
- **虚拟环境激活**：每次新开终端需重新激活：
  ```bash
  source .venv/bin/activate
  ```
- **资源不足**：若节点数量较多（如超过 10 个），可能需调整资源分配，参考 [Scaling 指南](scaling.md)。
- **集群管理工具**：推荐使用 `k9s` 管理 Kubernetes 集群：[k9s 官网](https://k9scli.io/)

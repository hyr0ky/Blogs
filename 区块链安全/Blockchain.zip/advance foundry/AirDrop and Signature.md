**MerkleAirdrop** 是一种结合 **Merkle树（Merkle Tree）** 和 **空投（Airdrop）** 的代币分发机制，主要用于区块链项目中高效、安全地向特定用户群体分发代币。以下是其核心概念和用途的详细说明：
# **MerkleAirdrop 的核心原理**

1. **Merkle树的作用**：
    - Merkle树是一种密码学数据结构，通过将大量数据分层哈希，最终生成一个唯一的**根哈希（Root Hash）**。每个用户的资格信息（如地址、代币数量）会被哈希后作为树的叶子节点，逐层向上构建，最终形成根哈希。
    - 通过迭代证明数组，将每个元素与先前计算的哈希值进行哈希运算，然后将最终输出与预期的根哈希值进行比较。
    - 项目方只需将根哈希存储在区块链（如智能合约）中，无需公开完整的用户名单，既节省存储成本，又保护隐私。
2. **空投流程**：
    - **资格验证**：用户需提供自己的地址、代币分配量以及对应的**Merkle证明**（从叶子节点到根哈希的路径上的哈希值）。
    - **链上验证**：智能合约通过用户提供的证明与存储的根哈希进行匹配，验证其领取资格。若验证通过，则自动发放代币。
```ad-important
The **root** is typically stored _on-chain_, while the **proof** is generated _off-chain_.
```

# 创建一个代币
```c
import { ERC20 } from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";

contract BagelToken is ERC20, Ownable {
    constructor() ERC20("Bagel Token", "BT") Ownable(msg.sender) { //the deployer is the owner of the contract
    }

    function mint(address account, uint256 amount) external onlyOwner {
        _mint(account, amount);
    }
}
```
# Airdrop 合同
## 初始设置
```c
// SPDX-License-Identifier: MIT
import { MerkleProof } from "@openzeppelin/contracts/utils/cryptography/MerkleProof.sol";

pragma solidity ^0.8.24;

contract MerkleAirdrop {
	//空投认领者们
    address [] claimers;
	IERC20 private immutable i_airdropToken;
    bytes32 private immutable i_merkleRoot;

	constructor(bytes32 merkleRoot, IERC20 airdropToken) {
    i_merkleRoot = merkleRoot;
    i_airdropToken = airdropToken;
}
	function claim
	(address account, uint256 amount, bytes32[] calldata merkleProof) external 
	{
    bytes32 leaf = keccak256(
    bytes.concat(keccak256(abi.encode(account, amount)))
    );
    if (!MerkleProof.verify(merkleProof, i_merkleRoot, leaf)) {
        revert MerkleAirdrop__InvalidProof();
    }
	 i_airdropToken.transfer(account, amount);
}
}
```
```ad-tip
### **. 防御第二原像攻击（Second Preimage Attack）**

- **问题背景**  
    在 Merkle Tree 中，若叶子节点直接使用原始数据的哈希（如 `keccak256(abi.encode(account, amount))`），攻击者可能构造一个与叶子节点哈希值相同的数据，从而伪造 Merkle 证明。这种攻击称为 **第二原像攻击**。
```
## 跟踪领取者
防止有人一直不停领取空投
```c
//.. in MerkleAirdrop main code
mapping(address => bool) private s_hasClaimed;
//.. in function claim
if (s_hasClaimed[account]) {
    revert MerkleAirdrop__AlreadyClaimed();
}
//...
if (!MerkleProof.verify(merkleProof, i_merkleRoot, leaf)) {
    revert MerkleAirdrop__InvalidProof();
}
s_hasClaimed[account] = true;
emit Claimed(account, amount);
//..
```
## Merkle Tree Script
### Generate input json
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";
import {stdJson} from "forge-std/StdJson.sol";
import {console} from "forge-std/console.sol";

// Merkle tree input file generator script
contract GenerateInput is Script {
    uint256 private constant AMOUNT = 25 * 1e18;
    string[] types = new string[](2);
    uint256 count;
    string[] whitelist = new string[](4);
    string private constant  INPUT_PATH = "/script/target/input.json";

    function run() public {
        types[0] = "address";
        types[1] = "uint";
        whitelist[0] = "0x6CA6d1e2D5347Bfab1d91e883F1915560e09129D";
        whitelist[1] = "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266";
        whitelist[2] = "0x2ea3970Ed82D5b30be821FAAD4a731D35964F7dd";
        whitelist[3] = "0xf6dBa02C01AF48Cf926579F77C9f874Ca640D91D";
        count = whitelist.length;
        string memory input = _createJSON();
        // write to the output file the stringified output json tree dump
        vm.writeFile(string.concat(vm.projectRoot(), INPUT_PATH), input);

        console.log("DONE: The output is found at %s", INPUT_PATH);
    }

    function _createJSON() internal view returns (string memory) {
        string memory countString = vm.toString(count); // convert count to string
        string memory amountString = vm.toString(AMOUNT); // convert amount to string
        string memory json = string.concat('{ "types": ["address", "uint"], "count":', countString, ',"values": {');
        for (uint256 i = 0; i < whitelist.length; i++) {
            if (i == whitelist.length - 1) {
                json = string.concat(json, '"', vm.toString(i), '"', ': { "0":', '"',whitelist[i],'"',', "1":', '"',amountString,'"', ' }');
            } else {
            json = string.concat(json, '"', vm.toString(i), '"', ': { "0":', '"',whitelist[i],'"',', "1":', '"',amountString,'"', ' },');
            }
        }
        json = string.concat(json, '} }');

        return json;
    }
}
```
![[Pasted image 20250502210927.png]]
### Merkle calculate (outjson)
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";
import {stdJson} from "forge-std/StdJson.sol";
import {console} from "forge-std/console.sol";
import {Merkle} from "murky/src/Merkle.sol";
import {ScriptHelper} from "murky/script/common/ScriptHelper.sol";

// Merkle proof generator script
// To use:
// 1. Run `forge script script/GenerateInput.s.sol` to generate the input file
// 2. Run `forge script script/Merkle.s.sol`
// 3. The output file will be generated in /script/target/output.json

/**
 * @title MakeMerkle
 * @author Ciara Nightingale
 * @author Cyfrin
 *
 * Original Work by:
 * @author kootsZhin
 * @notice https://github.com/dmfxyz/murky
 */

contract MakeMerkle is Script, ScriptHelper {
    using stdJson for string; // enables us to use the json cheatcodes for strings

    Merkle private m = new Merkle(); // instance of the merkle contract from Murky to do shit

    string private inputPath = "/script/target/input.json";
    string private outputPath = "/script/target/output.json";

    string private elements = vm.readFile(string.concat(vm.projectRoot(), inputPath)); // get the absolute path 
    string[] private types = elements.readStringArray(".types"); // gets the merkle tree leaf types from json using forge standard lib cheatcode 
    uint256 private count = elements.readUint(".count"); // get the number of leaf nodes

    // make three arrays the same size as the number of leaf nodes
    bytes32[] private leafs = new bytes32[](count);

    string[] private inputs = new string[](count);
    string[] private outputs = new string[](count);

    string private output;

    /// @dev Returns the JSON path of the input file
    // output file output ".values.some-address.some-amount"
    function getValuesByIndex(uint256 i, uint256 j) internal pure returns (string memory) {
        return string.concat(".values.", vm.toString(i), ".", vm.toString(j));
    } 

    /// @dev Generate the JSON entries for the output file
    function generateJsonEntries(string memory _inputs, string memory _proof, string memory _root, string memory _leaf)
        internal
        pure
        returns (string memory)
    {
        string memory result = string.concat(
            "{",
            "\"inputs\":",
            _inputs,
            ",",
            "\"proof\":",
            _proof,
            ",",
            "\"root\":\"",
            _root,
            "\",",
            "\"leaf\":\"",
            _leaf,
            "\"",
            "}"
        );

        return result;
    }

    /// @dev Read the input file and generate the Merkle proof, then write the output file
    function run() public {
        console.log("Generating Merkle Proof for %s", inputPath);

        for (uint256 i = 0; i < count; ++i) {
            string[] memory input = new string[](types.length); // stringified data (address and string both as strings)
            bytes32[] memory data = new bytes32[](types.length); // actual data as a bytes32

            for (uint256 j = 0; j < types.length; ++j) {
                if (compareStrings(types[j], "address")) {
                    address value = elements.readAddress(getValuesByIndex(i, j));
                    // you can't immediately cast straight to 32 bytes as an address is 20 bytes so first cast to uint160 (20 bytes) cast up to uint256 which is 32 bytes and finally to bytes32
                    data[j] = bytes32(uint256(uint160(value))); 
                    input[j] = vm.toString(value);
                } else if (compareStrings(types[j], "uint")) {
                    uint256 value = vm.parseUint(elements.readString(getValuesByIndex(i, j)));
                    data[j] = bytes32(value);
                    input[j] = vm.toString(value);
                }
            }
            // Create the hash for the merkle tree leaf node
            // abi encode the data array (each element is a bytes32 representation for the address and the amount)
            // Helper from Murky (ltrim64) Returns the bytes with the first 64 bytes removed 
            // ltrim64 removes the offset and length from the encoded bytes. There is an offset because the array
            // is declared in memory
            // hash the encoded address and amount
            // bytes.concat turns from bytes32 to bytes
            // hash again because preimage attack
            leafs[i] = keccak256(bytes.concat(keccak256(ltrim64(abi.encode(data)))));
            // Converts a string array into a JSON array string.
            // store the corresponding values/inputs for each leaf node
            inputs[i] = stringArrayToString(input);
        }

        for (uint256 i = 0; i < count; ++i) {
            // get proof gets the nodes needed for the proof & stringify (from helper lib)
            string memory proof = bytes32ArrayToString(m.getProof(leafs, i));
            // get the root hash and stringify
            string memory root = vm.toString(m.getRoot(leafs));
            // get the specific leaf working on
            string memory leaf = vm.toString(leafs[i]);
            // get the singified input (address, amount)
            string memory input = inputs[i];

            // generate the Json output file (tree dump)
            outputs[i] = generateJsonEntries(input, proof, root, leaf);
        }

        // stringify the array of strings to a single string
        output = stringArrayToArrayString(outputs);
        // write to the output file the stringified output json (tree dump)
        vm.writeFile(string.concat(vm.projectRoot(), outputPath), output);

        console.log("DONE: The output is found at %s", outputPath);
    }
}
```
![[Pasted image 20250502210948.png]]
## Deploy 
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import { MerkleAirdrop, IERC20 } from "../src/MerkleAirdrop.sol";
import { Script } from "forge-std/Script.sol";
import { BagelToken } from "../src/BagelToken.sol";
import { console } from "forge-std/console.sol";

contract DeployMerkleAirdrop is Script {
    bytes32 public ROOT = 0xaa5d581231e596618465a56aa0f5870ba6e20785fe436d5bfb82b08662ccc7c4;
    // 4 users, 25 Bagel tokens each
    uint256 public AMOUNT_TO_TRANSFER = 4 * (25 * 1e18);

    // Deploy the airdrop contract and bagel token contract
    function deployMerkleAirdrop() public returns (MerkleAirdrop, BagelToken) {
        vm.startBroadcast();
        BagelToken bagelToken = new BagelToken();
        MerkleAirdrop airdrop = new MerkleAirdrop(ROOT, IERC20(bagelToken));
        // Send Bagel tokens -> Merkle Air Drop contract
        bagelToken.mint(bagelToken.owner(), AMOUNT_TO_TRANSFER);
        IERC20(bagelToken).transfer(address(airdrop), AMOUNT_TO_TRANSFER);
        vm.stopBroadcast();
        return (airdrop, bagelToken);
    }

    function run() external returns (MerkleAirdrop, BagelToken) {
        return deployMerkleAirdrop();
    }
}
```
## Test Merkle
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {MerkleAirdrop} from "../../src/MerkleAirdrop.sol";
import {BagelToken} from "../../src/BagelToken.sol";
import {Test} from "forge-std/Test.sol";
import {console} from "forge-std/console.sol";
import {DeployMerkleAirdrop} from "../../script/DeployMerkleAirdrop.s.sol";
import {ZkSyncChainChecker} from "foundry-devops/src/ZkSyncChainChecker.sol";

contract MerkleAirdropTest is ZkSyncChainChecker, Test {
    MerkleAirdrop airdrop;
    BagelToken token;
    address user;
    uint256 userPrivKey;
    uint256 AMOUNT = 25 *1e18
	// in outputjson
    bytes32 merkleRoot = 0xaa5d581231e596618465a56aa0f5870ba6e20785fe436d5bfb82b08662ccc7c4;


    bytes32 proofOne = 0x0fd7c981d39bece61f7499702bf59b3114a90e66b51ba2c53abdf7b62986c00a;
    bytes32 proofTwo = 0xe5ebd1e1b5a5478a944ecab36a9a954ac3b6b8216875f6524caa7a1d87096576;
    bytes32[] proof = [proofOne, proofTwo];

function setUp() public {
    if (!isZkSyncChain()) { //chain verification
        DeployMerkleAirdrop deployer = new DeployMerkleAirdrop();
        (airdrop, token) = deployer.deployMerkleAirdrop();
    } else {
        token = new BagelToken();
        airdrop = new MerkleAirdrop(merkleRoot, token);
        token.mint(token.owner(), amountToSend);
        token.transfer(address(airdrop), amountToSend);
    }
    (user, userPrivKey) = makeAddrAndKey("user");
}

    function testUsersCanClaim() public {
        uint256 startingBalance = token.balanceOf(user);
        vm.prank(gasPayer);
        airdrop.claim(user, AMOUNT, proof);
        uint256 endingBalance = token.balanceOf(user);
        console.log("Ending balance: %d", endingBalance);
        assertEq(endingBalance - startingBalance, amountToCollect);
    }
}
```
# 数字签名
## **EIP 191 与 EIP 712 详解**

#### **1. EIP 191：标准化签名格式**
**核心目标**：为签名数据提供统一格式，避免不同应用间的签名冲突。
##### **签名结构**
```text
0x19 <1字节版本号> <版本特定数据> <原始消息>
```
- **0x19 前缀**：标识这是一个符合 EIP 191 的签名，防止与其他签名格式混淆。
- **版本号**：定义签名数据的类型：
  - `0x00`：带验证器的数据（如特定合约地址）。
  - `0x01`：结构化数据（EIP 712 专用）。
  - `0x45`：个人签名消息（如以太坊的 `personal_sign`）。
- **版本特定数据**：根据版本号动态填充（如验证器地址）。
- **原始消息**：需要签名的实际数据。
##### **代码示例解析**
```c
function getSigner191(uint256 message, uint8 _v, bytes32 _r, bytes32 _s) public view returns (address) {
    bytes1 prefix = 0x19;
    bytes1 version = 0x00;
    address validator = address(this); // 当前合约为验证器
    bytes32 data = bytes32(message);
    
    // 构造 EIP 191 格式的哈希
    bytes32 hashedMessage = keccak256(abi.encodePacked(prefix, version, validator, data));
    return ecrecover(hashedMessage, _v, _r, _s);
}
```
```ad-note
**ecrecover** 是以太坊区块链中的一个 **内置函数**，用于从数字签名中恢复出签名者的以太坊地址。它是基于 **椭圆曲线加密算法（ECDSA）** 实现的，主要作用是通过签名数据（`v`, `r`, `s`）和原始消息的哈希值，验证签名是否合法并确定签名者的身份。

### **核心功能**

1. **输入参数**：
    
    - `bytes32 hash`：被签名消息的哈希值。
        
    - `uint8 v`：恢复标识符（Recovery Identifier），用于确定椭圆曲线上的一个解。
        
    - `bytes32 r`：ECDSA 签名的第一部分。
        
    - `bytes32 s`：ECDSA 签名的第二部分。
        
2. **输出**：
    
    - `address`：恢复出的签名者地址。如果签名无效，可能返回 `address(0)`。
        
3. **代码示例**：
       
    address signer = ecrecover(
        keccak256(abi.encodePacked("Hello, Ethereum!")), // 消息哈希
        v, // 恢复标识符
        r, // 签名第一部分
        s  // 签名第二部分
    );
    
```


#### **2. EIP 712：结构化数据与防重放攻击**
**核心目标**：增强签名数据的可读性，并通过域分隔符（Domain Separator）防止跨域重放攻击。
##### **域分隔符（Domain Separator）**
定义签名生效的“作用域”，包含以下关键信息：
```c
struct EIP712Domain {
    string name;         // 应用名称（如 "MyDApp"）
    string version;      // 应用版本（如 "1.0"）
    uint256 chainId;     // 链ID（如以太坊主网为1）
    address verifyingContract; // 验证合约地址
}
```
- **生成方式**：
  ```c
  bytes32 domainSeparator = keccak256(
      abi.encode(
          EIP712DOMAIN_TYPEHASH, // "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
          keccak256(bytes(name)),
          keccak256(bytes(version)),
          chainId,
          verifyingContract
      )
  );
  ```
- **作用**：将签名绑定到特定合约、链和版本，防止跨链或跨合约的重放攻击。

##### **结构化消息哈希**
1. **定义消息结构**：
   ```c
   struct Message {
       uint256 number;
   }
   bytes32 MESSAGE_TYPEHASH = keccak256("Message(uint256 number)");
   ```
2. **生成消息哈希**：
   ```c
   bytes32 hashedMessage = keccak256(
       abi.encode(
           MESSAGE_TYPEHASH, 
           Message({number: message})
       )
   );
   ```
3. **最终摘要（Digest）**：
   ```c
   bytes32 digest = keccak256(
       abi.encodePacked(
           "\x19\x01",          // EIP 191 前缀 + 版本号
           domainSeparator,     // 域分隔符
           hashedMessage        // 结构化消息哈希
       )
   );
   ```
- **作用**：确保签名仅对特定结构、域和消息有效。

##### **代码示例解析**
```c
function getSignerEIP712(uint256 message, uint8 _v, bytes32 _r, bytes32 _s) public view returns (address) {
    bytes32 digest = keccak256(
        abi.encodePacked(
            "\x19\x01", 
            domainSeparator, 
            keccak256(abi.encode(MESSAGE_TYPEHASH, Message({number: message})))
        )
    );
    return ecrecover(digest, _v, _r, _s);
}
```
- **安全机制**：
  1. 签名绑定到特定合约（`verifyingContract`）和链（`chainId`）。
  2. 结构化数据确保消息格式明确，避免歧义。

#### **4. OpenZeppelin 的最佳实践**
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";

contract EIP712Demo is EIP712 {
    bytes32 public constant MESSAGE_TYPEHASH = 
    keccak256("Message(uint256 message)");

    constructor() EIP712("MyDApp", "1") {} // 初始化域分隔符
	// 自动加入constructor的信息和chainid等
    function getMessageHash(uint256 _message) public view returns (bytes32) {
        return _hashTypedDataV4(keccak256(abi.encode(MESSAGE_TYPEHASH, _message)));
    }

    function verifySigner(
        uint256 message,
        bytes memory signature,
        address expectedSigner
    ) public view returns (bool) {
        bytes32 digest = getMessageHash(message);
        (address signer, ECDSA.RecoverError error, ) 
        = ECDSA.tryRecover(digest, signature);
        require(error == ECDSA.RecoverError.NoError, "Invalid signature");
        return signer == expectedSigner;
    }
}
```
## ECDSA
#### 一、ECDSA 基础原理

**1. 椭圆曲线密码学（ECC）的核心特性**  
ECDSA 基于椭圆曲线的数学性质实现安全签名，关键特性包括：
- **无奇异点**：曲线上不存在不可导的点，保证数学运算的稳定性。
- **对称性**：对于点 `(x, y)`，其对称点 `(x, -y)` 也在曲线上，简化点的运算。
- **点加法规则**：两点相加时，连接它们的直线会与曲线交于第三点，形成群结构。

**2. 密钥对生成**  
- **私钥**：随机生成的整数（范围：`1 ≤ 私钥 < n`，`n` 是 secp256k1 曲线的固定素数）。
- **公钥**：通过 `公钥 = 私钥 × G` 计算得出，其中 `G` 是曲线的生成元点。

**3. 以太坊地址生成**  
- **步骤**：  
  1. 对公钥应用 `keccak256` 哈希算法，得到 32 字节哈希值。  
  2. 取哈希值的最后 20 字节（40 个十六进制字符）作为地址。  
- **目的**：缩短长度、隐藏公钥细节、增强隐私性。

#### 二、ECDSA 签名生成与验证

**1. 签名生成（Signing）**  
输入：消息哈希 `H(m)`、私钥 `d`、随机数 `k`（临时私钥）。  
输出：签名 `(r, s, v)`。  
- **计算步骤**：  
  1. 计算点 `R = k × G`，取 `r` 为 `R` 的 x 坐标。  
  2. 计算 `s = k⁻¹ × (H(m) + d × r) mod n`。  
  3. 确定 `v`（恢复标识符），表示 `R` 的 y 坐标奇偶性（以太坊中通常为 27 或 28）。  

**2. 签名验证（Verification）**  
输入：消息哈希 `H(m)`、签名 `(r, s, v)`、公钥 `Q`。  
- **验证逻辑**：  
  1. 通过 `v` 恢复点 `R` 的完整坐标。  
  2. 计算中间值：  
     - `u1 = H(m) × s⁻¹ mod n`  
     - `u2 = r × s⁻¹ mod n`  
  3. 验证等式：`u1 × G + u2 × Q` 的 x 坐标是否等于 `r`。  

---

#### 三、SECP256k1 曲线与签名可锻性

**1. 曲线参数**  
- **生成元 `G`**：曲线上的固定起点，用于生成公钥。  
- **素数 `n`**：私钥的取值范围上限（`n ≈ 2²⁵⁶`），确保密钥空间足够大。  

**2. 签名可锻性（Malleability）**  
- **问题**：对于同一消息，存在两个有效签名 `(r, s)` 和 `(r, n - s)`，可能导致重放攻击。  
- **解决方案**：  
  - **限制 `s` 的范围**：强制 `s ≤ n/2`，消除重复可能性。  
  - **OpenZeppelin 实现**：在 `ECDSA.tryRecover` 中自动检查 `s` 的有效范围。  
## 将签名添加到我们的Airdrop
### Claim 修改
```c
function claim(
    address account,
    uint256 amount,
    bytes32[] calldata merkleProof,
    uint8 v,
    bytes32 r,
    bytes32 s
) external {
    if (s_hasClaimed[account]) {
        revert MerkleAirdrop__AlreadyClaimed();
    }

    // Verify the signature
    if (!_isValidSignature(account, message, v, r, s)) {
        revert MerkleAirdrop__InvalidSignature();
    }
    //...
}
```
### getMessageHash
```c
    struct AirdropClaim {
        address account;
        uint256 amount;
    }
//.....
    function getMessageHash(address account, uint256 amount) public view returns (bytes32) {
        return _hashTypedDataV4(
            keccak256(abi.encode(MESSAGE_TYPEHASH, AirdropClaim({ account: account, amount: amount })))
        );
    }

```
### isValidSignature
```c
  function _isValidSignature(
        address signer,
        bytes32 digest,
        uint8 _v,
        bytes32 _r,
        bytes32 _s
    )
        internal
        pure
        returns (bool)
    {
        (
            address actualSigner,
            /*ECDSA.RecoverError recoverError*/
            ,
            /*bytes32 signatureLength*/
        ) = ECDSA.tryRecover(digest, _v, _r, _s);
        return (actualSigner == signer);
    }
```
```ad-tip
多了 v r s
```
## 修改Test 包含签名
### Setup
```c
gasPayer = makeAddr("gasPayer");
```
###  signMessage(New)
```c
    function signMessage(uint256 privKey, address account) public view returns (uint8 v, bytes32 r, bytes32 s) {
        bytes32 hashedMessage = airdrop.getMessageHash(account, amountToCollect);
        (v, r, s) = vm.sign(privKey, hashedMessage);
    }


```
### TestClaim
```c
  function testUsersCanClaim() public {
        uint256 startingBalance = token.balanceOf(user);

        // get the signature
        vm.startPrank(user);
        (uint8 v, bytes32 r, bytes32 s) = signMessage(userPrivKey, user);
        vm.stopPrank();

        // gasPayer claims the airdrop for the user
        vm.prank(gasPayer);
        airdrop.claim(user, amountToCollect, proof, v, r, s);
        uint256 endingBalance = token.balanceOf(user);
        console.log("Ending balance: %d", endingBalance);
        assertEq(endingBalance - startingBalance, amountToCollect);
    }
```
```ad-note
在提供的智能合约测试代码中，`gasPayer` 是**代为支付交易手续费（Gas）并执行操作的账户**，而 `user` 是实际接收空投代币的受益人。二者的关系如下：



### **1. `gasPayer` 的作用**
- **支付 Gas 费用**：当 `gasPayer` 调用 `airdrop.claim()` 方法时，交易的手续费（Gas）由 `gasPayer` 支付，而非 `user`。这使得用户无需自行支付 Gas 即可领取空投。
- **执行操作**：`gasPayer` 作为中继者（Relayer），代替 `user` 发起交易，但实际受益人是 `user`。


### **2. `user` 的作用**
- **签名授权**：`user` 使用私钥对消息（如空投参数）进行签名（生成 `v, r, s`），证明自己同意该操作。
- **接收代币**：空投的代币会直接转入 `user` 的地址，而非 `gasPayer` 的地址。



### **3. `gasPayer` 与 `user` 的关系**
- **授权与执行分离**：
  - `user` 通过签名授权操作，但不亲自发送交易。
  - `gasPayer` 利用 `user` 的签名，代为执行交易并支付 Gas。
- **典型应用场景**：
  - **元交易（Meta-Transaction）**：用户无需持有原生代币（如 ETH）即可与合约交互。
  - **批量操作**：项目方统一为用户支付 Gas，简化用户体验。
   ```
  
# Interaction with Airdrop
```c
// SPDX-Licence-Indentifier: MIT
pragma solidity ^0.8.24;

import { Script, console } from "forge-std/Script.sol";
import { DevOpsTools } from "foundry-devops/src/DevOpsTools.sol";
import { MerkleAirdrop } from "../src/MerkleAirdrop.sol";

contract ClaimAirdrop is Script {
    address private constant CLAIMING_ADDRESS = //your account address;
    uint256 private constant AMOUNT_TO_COLLECT = (25 * 1e18); // 25.000000
	// put your account address in generate script to generate outjson
	//then you get the proof
    bytes32 private constant PROOF_ONE = ;
    bytes32 private constant PROOF_TWO = ;
    bytes32[] private proof = [PROOF_ONE, PROOF_TWO];

    // the signature will change every time you redeploy the airdrop contract!
    bytes private SIGNATURE = hex"your signature";

    error ClaimAirdropScript__InvalidSignatureLength();

    function claimAirdrop(address airdrop) public {
        vm.startBroadcast();
        
        (uint8 v, bytes32 r, bytes32 s) = splitSignature(SIGNATURE);
		MerkleAirdrop(airdrop)
        .claim(CLAIMING_ADDRESS, AMOUNT_TO_COLLECT, proof, v, r, s);
	    
	    vm.stopBroadcast();
     
    }

    function splitSignature(bytes memory sig) public pure returns (uint8 v, bytes32 r, bytes32 s) {
        if (sig.length != 65) {
            revert ClaimAirdropScript__InvalidSignatureLength();
        }
        assembly {
            r := mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
        }
    }

    function run() external {
        address mostRecentlyDeployed = DevOpsTools.get_most_recent_deployment("MerkleAirdrop", block.chainid);
        claimAirdrop(mostRecentlyDeployed);
    }
}

```
```ad-tip
获得`your signature`
首先部署Airdrop
1. getMessageHash
`cast call [Airdrop contract address]"getMessageHash(address,uint256)" [account_address] [amount]`
2. sign
`cast wallet sign [messagehash] --private-key [key]`
`cast wallet sign [messagehash] --account [account]`
3.输出
0x
[r（32字节）] [s（32字节）] [v（1字节）]
```
# 交易类型
### 以太坊与 ZKsync 交易类型解析

#### **一、通用交易类型（以太坊 & ZKsync 均支持）**

##### **1. Type 0（Legacy Transactions）**
- **编号**: `0x00`  
- **背景**: 以太坊最初的交易格式，未引入 EIP 改进前的标准类型。  
- **关键字段**:  
  - `gasPrice`（固定 gas 价格）  
  - `nonce`（交易序号）  
  - `value`（转账金额）  
- **用途**: 基础转账和合约交互，现逐渐被新类型取代。  
- **注意**: 使用 `--legacy` 标志可强制生成此类交易。

---

##### **2. Type 1（Access List Transactions）**
- **编号**: `0x01`  
- **引入原因**: 配合 EIP-2930，解决 EIP-2929 引入的 Gas 成本变化导致的合约兼容性问题。  
- **核心改进**:  
  - **Access List（访问列表）**: 预声明交易将访问的地址和存储槽，降低跨合约调用的 Gas 开销。  
- **适用场景**: 复杂合约交互（如 DeFi 协议），减少 Gas 消耗。

---

##### **3. Type 2（EIP-1559 动态费用交易）**
- **编号**: `0x02`  
- **核心机制**:  
  - **Base Fee（基础费用）**: 每个区块动态调整，由网络拥堵程度决定，费用被销毁。  
  - **Max Priority Fee（优先费）**: 用户支付给矿工/验证者的额外激励。  
  - **Max Fee（最大费用）**: 用户愿意支付的最高总费用（`Base Fee + Priority Fee`）。  
- **ZKsync 差异**:  
  - 虽然支持 Type 2，但 ZKsync 的 Gas 机制不依赖 `Max Fee` 参数（因其 Rollup 架构 Gas 计算更稳定）。  

---

##### **4. Type 3（Blob 数据交易，EIP-4844）**
- **编号**: `0x03`  
- **目标**: 为 Rollup（如 ZKsync）提供低成本数据存储方案。  
- **关键参数**:  
  - **Blob Gas**: 专用于存储大规模数据（如 Rollup 的批量交易数据），与普通 Gas 隔离，费用更低。  
  - **Blob Versioned Hashes**: 关联交易中 Blob 数据的版本化哈希，确保数据完整性。  
- **费用规则**:  
  - Blob Gas 费用在交易执行前扣除并销毁，即使交易失败也不退还。  

---

#### **二、ZKsync 特有交易类型**

##### **1. Type 113（EIP-712 结构化交易）**
- **编号**: `0x71`  
- **核心特性**:  
  - **账户抽象（AA）**: 允许智能合约钱包作为交易发起者（非 EOA 地址）。  
  - **Paymaster 支持**: 第三方代付 Gas 费用（如用 ERC20 代币支付）。  
- **关键字段**:  
  - **Gas per Pub Data**: 每字节 L2→L1 状态数据的 Gas 上限。  
  - **Custom Signature**: 支持非 ECDSA 签名（如多重签名、生物识别）。  
  - **Factory Depths**: 包含部署合约的字节码（用于工厂模式部署）。  
- **强制要求**:  
  - **所有 ZKsync 智能合约必须通过 Type 113 交易部署**。  

##### **2. Type 5（L1→L2 优先交易）**
- **编号**: `0xFF`  
- **功能**: 允许用户直接从以太坊 L1 发送交易到 ZKsync L2。  
- **优势**:  
  - **跨层原子性**: 确保 L1 操作与 L2 交易同时成功或失败。  
  - **低延迟**: 绕过常规跨链桥的等待时间。  
- **典型用例**:  
  - L1 合约触发 L2 资产铸造。  
  - 跨链治理投票（如 DAO 提案直接在 L2 执行）。  

#### **三、对比总结**

| **类型** | **适用链** | **核心功能**                     | **典型场景**               |  
|----------|------------|----------------------------------|---------------------------|  
| Type 0   | 以太坊     | 旧版基础交易                     | 兼容老版本 DApp           |  
| Type 2   | 以太坊     | 动态 Gas 费用优化                | 高网络拥堵时节省费用       |  
| Type 3   | 以太坊     | Rollup 数据低成本存储            | ZKsync 批量交易提交       |  
| Type 113 | ZKsync     | 账户抽象 & 灵活 Gas 支付         | 智能合约钱包、代付 Gas    |  
| Type 5   | ZKsync     | L1→L2 直连交易                   | 跨链资产同步、快速交互     |  
## Blob带来的思考——区块链无需全量数据的信任逻辑
### **一、数据删除的背景与挑战**
- **Blob 交易的特性**：  
  通过 EIP-4844 引入的 Blob 交易数据仅临时存储约 18 天，之后被删除，以降低存储成本。  
- **关键问题**：  
  若交易数据被删除，如何验证历史状态（如用户余额）的正确性？
### **二、状态验证的核心机制**

#### **1. 状态根（State Root）的链上锚定**
- **状态根**：  
  所有链上账户的余额和合约状态通过 Merkle 树（如以太坊的 Patricia Merkle Trie）压缩为一个哈希值（状态根）。  
- **链上存储**：  
  每次区块生成时，最新的状态根会被写入以太坊主网区块头，永久保存。  
- **验证逻辑**：  
  即使交易数据被删除，只要状态根存在，即可通过 Merkle 证明验证某账户在特定区块高度的余额。  

**示例**：  
假设 Alice 在区块高度 `N` 的余额为 10 ETH，系统会生成一个 Merkle 路径证明，从她的账户叶子节点逐级哈希到状态根。验证者只需检查该路径的哈希是否与链上记录的状态根匹配。

#### **2. Rollup 的状态承诺（以 ZKsync 为例）**
- **ZK-Rollup 的工作流程**：  
  1. **批量交易**：将多笔 L2 交易打包成一个批次。  
  2. **生成证明**：通过零知识证明（如 zk-SNARK）验证批次内所有交易的有效性。  
  3. **提交到 L1**：将批次交易数据（Blob）和状态根提交到以太坊主网。  
- **数据删除后的验证**：  
  - 即使 Blob 数据被删除，主网上的 **状态根** 和 **有效性证明** 仍可证明 L2 状态的正确性。  
  - 用户可通过零知识证明直接验证余额，无需依赖原始交易数据。

#### **3. 数据可用性保障（Data Availability）**
- **临时存储窗口期**：  
  Blob 数据在删除前保留 18 天，确保在此期间任何人可下载并验证数据。  
- **纠删码（Erasure Coding）**：  
  数据被编码为多个片段，即使部分节点丢失数据，仍可通过剩余片段恢复完整内容。  
- **去中心化存储备份**：  
  社区或第三方（如 Arweave、IPFS）可能主动存储 Blob 数据，提供长期可访问性。
### **三、用户余额验证的具体方法**

#### **1. 轻节点验证（Merkle Proof）**
- **适用场景**：  
  用户仅需验证自身余额，无需同步全链数据。  
- **步骤**：  
  1. 从区块链浏览器或节点获取目标区块高度的状态根。  
  2. 请求该账户的 Merkle 路径证明（如通过 `eth_getProof` RPC）。  
  3. 验证 Merkle 路径哈希是否与状态根匹配。  

#### **2. 零知识证明（ZK Proof）**
- **适用场景**：  
  ZK-Rollup 链（如 ZKsync）上的余额验证。  
- **步骤**：  
  1. 用户向 Rollup 节点请求账户状态的零知识证明。  
  2. 验证证明的有效性（证明过程无需透露交易细节）。  
  3. 确认证明结果与主网锚定的状态根一致。  

#### **3. 历史状态快照**
- **定期快照**：  
  部分链会定期将完整状态树快照存储至去中心化网络（如 IPFS），供未来验证。  
- **示例**：  
  Polygon 每月发布一次状态快照，用户可通过快照哈希验证历史余额。

### **四、对数据删除的应对策略**

#### **1. 关键数据冗余存储**
- **Rollup 运营商**：  
  需在 Blob 数据删除前，将其备份至去中心化存储（如 Arweave 或 DAC 网络）。  
- **用户**：  
  可自行保存与自身相关的交易凭证（如交易哈希、收据）。  

#### **2. 状态证明市场**
- **第三方服务**：  
  如 Chainlink 或 The Graph 可提供按需生成历史状态证明的服务。  
- **经济激励**：  
  存储节点通过质押和手续费获得奖励，确保数据长期可用。  

#### **3. 链上争议解决**
- **欺诈证明（Optimistic Rollup）**：  
  在 Optimistic Rollup 中，任何人在挑战期（如 7 天）内可提交欺诈证明，触发状态回滚。  
- **ZK 证明（ZK-Rollup）**：  
  通过数学保证消除争议，无需依赖数据可用性窗口期。  
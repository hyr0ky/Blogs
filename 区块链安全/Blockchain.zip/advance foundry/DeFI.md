# 稳定币
购买力保持稳定的
`外生币` 由外部抵押资金确保 ，如1 usd = 1 usdt
`内生币` 由算法确定的
## 稳定币合约
```c
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.18;

import {ERC20Burnable, ERC20} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";

contract DecentralizedStableCoin is ERC20Burnable {
    constructor() ERC20("DecentralizedStableCoin", "DSC"){}
}
```
```ad-tip
使用的是 **ERC20Burnable**
```
### Burn
```c
function burn(uint256 _amount) external override onlyOwner{
    uint256 balance = balanceOf(msg.sender);
    if(_amount <= 0){
        revert DecentralizedStableCoin__MustBeMoreThanZero();
    }
    if(balance < _amount){
        revert DecentralizedStableCoin__BurnAmountExceedsBalance();
    }
    //继承ERC20burn的燃烧方法
    super.burn(_amount);
}
```
```ad-tip
burn 是**override** 而且使用**super**继承
```
### Mint
```c
    function mint(address _to, uint256 _amount) external onlyOwner returns(bool){
        if(_to == address(0)){
            revert DecentralizedStableCoin__NotZeroAddress();
        }
        if(_amount <= 0){
            revert DecentralizedStableCoin__MustBeMoreThanZero();
        }
        _mint(_to, amount)
        return true;
    }
}
```
```ad-tip 
没有覆盖，且用_mint 去挖矿，而不是继承
```
## Engine（维持稳定币的合约）
我们需要实现以下功能：

• **存入抵押品并铸造 `DSC` 代币**
  • 这是用户获取稳定币的方式，他们需要存入价值高于所铸造 `DSC` 的抵押品。
• **用 `DSC` 赎回抵押品**
  • 用户需要能够将 `DSC` 返还给协议，以换取其底层抵押品。
• **销毁 `DSC`**
  • 如果用户的抵押品价值迅速下跌，用户需要一种快速修复其 `DSC` 抵押率的方式。
• **清算账户的能力**
  • 由于我们的协议必须始终保持超额抵押（存入的抵押品价值必须高于所铸造的 `DSC`），如果用户的抵押品价值低于支持其铸造的 `DSC` 所需的最低要求，他们的账户可能会被清算。清算允许其他用户关闭抵押不足的仓位。
• **查看账户的 `healthFactor`（健康因子）**
	 `healthFactor` 将定义为用户为其铸造的 `DSC` 所持有的抵押品比率。随着用户抵押品价值的下降，如果用户持有的 `DSC` 没有变化，其 `healthFactor` 也会下降。如果用户的 `healthFactor` 低于设定的阈值，用户将面临被清算的风险。
    例如，如果清算的阈值是 150% 的抵押率，那么持有 $75 ETH 的账户可以支持 $50 的 `DSC`。如果 ETH 的价值下降到 $74，`healthFactor` 将被打破，账户可能会被清算。
```c
contract DSCEngine {

///////////////////
//   Functions   //
///////////////////

///////////////////////////
//   External Functions  //
///////////////////////////
    function depositCollateralAndMintDsc() external {}

    function depositCollateral() external {}

    function redeemCollateralForDsc() external {}

    function redeemCollateral() external {}

    function mintDsc() external {}

    function burnDsc() external {}

    function liquidate() external {}

    function getHealthFactor() external view {}
}
```
### 构造函数
```c
import {DecentralizedStableCoin} from "DecentralizedStableCoin.sol";

// 定义代币地址到价格源（Price Feed）地址的映射
mapping(address token => address priceFeed) private s_priceFeeds;

// 定义不可变的稳定币合约实例
DecentralizedStableCoin private immutable i_dsc;
//用户token地址和数量映射
mapping(address user => mapping(address token => uint256 amount)) private s_collateralDeposited;
//用户和对应稳定币数量
mapping(address user => uint256 amountDscMinted) private s_DSCMinted;
//保存抵押物地址
address[] private s_collateralTokens;

constructor(
 // 支持的抵押品代币地址列表（如 ETH、WBTC）
    address[] memory tokenAddresses, 
    // 对应抵押品代币的价格源地址列表
    address[] memory priceFeedAddresses, 
    address dscAddress // 稳定币合约的部署地址
) {
    // 检查代币地址和价格源地址数量是否一致，保证一一对应
    if (tokenAddresses.length != priceFeedAddresses.length) {
        revert DSCEngine__TokenAddressesAndPriceFeedAddressesMustBeSameLength();
    }

    // 遍历代币地址列表，建立代币到价格源的映射
    for (uint256 i = 0; i < tokenAddresses.length; i++) {
        s_priceFeeds[tokenAddresses[i]] = priceFeedAddresses[i];
        s_collateralTokens.push(tokenAddresses[i]);
    }

    // 初始化稳定币合约实例
    i_dsc = DecentralizedStableCoin(dscAddress);
}
```
```ad-note
1. **`tokenAddresses`**
    
    - 类型：`address[]`（动态数组）
        
    - 作用：声明系统支持的抵押品代币列表（如 `[ETH_ADDRESS, WBTC_ADDRESS]`），用户可用这些代币抵押生成稳定币。
        
2. **`priceFeedAddresses`**
    
    - 类型：`address[]`
        
    - 作用：与 `tokenAddresses` 一一对应的价格源合约地址（如 `[CHAINLINK_ETH_USD_ADDRESS, CHAINLINK_BTC_USD_ADDRESS]`），用于查询代币的实时价格。
3. **`s_priceFeeds`**
    
    - 类型：`mapping(address => address)`
        
    - 作用：存储每个抵押品代币（如 ETH、BTC）对应的链上价格源合约地址（如 Chainlink 预言机）。
        
    - 示例：
        
        - `s_priceFeeds[ETH_ADDRESS] = CHAINLINK_ETH_USD_ADDRESS`
            
        - `s_priceFeeds[WBTC_ADDRESS] = CHAINLINK_BTC_USD_ADDRESS`
            
    - 用途：通过代币地址查找其价格源，用于实时查询抵押物的美元价值。
```
### 存抵押
1. 抵押必须大于0
```c
    error DSCEngine__NeedsMoreThanZero();
    
    modifier moreThanZero(uint256 amount){
        if(amount <=0){
            revert DSCEngine__NeedsMoreThanZero();
        }
        _;
    }

```
2. 可支持的抵押物
```c
   modifier isAllowedToken(address token) {
   //抵押物是空地址
        if (s_priceFeeds[token] == address(0)) {
            revert DSCEngine__TokenNotAllowed(token);
        }
        _;
    }
```
 3. 函数主体
 ```c
 //防止重入攻击
 import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
// 抵押事件
event CollateralDeposited(address indexed user, address indexed token, uint256 indexed amount);


function depositCollateral(address tokenCollateralAddress, uint256 amountCollateral) 
external 
moreThanZero(amountCollateral) 
isAllowedToken(tokenCollateralAddress) 
nonReentrant{
    s_collateralDeposited[msg.sender][tokenCollateralAddress] += amountCollateral;
     emit CollateralDeposited(msg.sender, tokenCollateralAddress, amountCollateral);


bool success = IERC20(tokenCollateralAddress).transferFrom(msg.sender, address(this), amountCollateral);
        if (!success) {
            revert DSCEngine__TransferFailed();
        }
}

```
```ad-note
对应代币的代币地址执行交易
IERC20(tokenCollateralAddress).
从抵押的用户把一定数量钱转到本稳定币Engine合同，
transferFrom(msg.sender, address(this), amountCollateral);

```
### Mint
1. 函数主体
```c
/*
    * @param amountDscToMint: The amount of DSC you want to mint
    * You can only mint DSC if you hav enough collateral
    */
function mintDsc(uint256 amountDscToMint) 
external 
moreThanZero(amountDscToMint) nonReentrant 
{
    s_DSCMinted[msg.sender] += amountDscToMint;
    _revertIfHealthFactorIsBroken(msg.sender);
    bool minted = i_dsc.mint(msg.sender, amountDscToMint);

    if(!minted){
        revert DSCEngine__MintFailed();
    }
}
```
### 用户健康因子
健康因子不够，用户会被清算，常常发生在某一抵押物大幅贬值情况下
![[Pasted image 20250320164540.png]]


**公式**：  
$H_f = \frac{\sum (\text{抵押品}_i \text{ 的 ETH 价值} \times \text{清算阈值}_i)}{\text{总借款的 ETH 价值}}$

**关键参数**：  
1. **清算阈值（Liquidation Threshold）**  
   • 每种抵押品（如 ETH、WBTC）有不同的清算阈值（例如 75%），代表抵押品价值中可用于覆盖借款的最高比例。  
   • 例如：抵押 100 ETH（单价 $1,000），清算阈值 75% → 最多可借$75,000 。  
```ad-tip
对于我们合约即是
 抵押物总价格
 稳定币价格
```

```c
//清算参数
uint256 private constant PRECISION = 1e18;
uint256 private constant LIQUIDATION_THRESHOLD = 50;
uint256 private constant LIQUIDATION_PRECISION = 100;
uint256 private constant MIN_HEALTH_FACTOR = 1e18;

//清算
function _revertIfHealthFactorIsBroken(address user) internal view {
    uint256 userHealthFactor = _healthFactor(user);
    if(userHealthFactor < MIN_HEALTH_FACTOR){
        revert DSCEngine__BreaksHealthFactor(userHealthFactor);
    }
}
//获取健康因子
function _healthFactor(address user) private view returns(uint256){
    (uint256 totalDscMinted, uint256 collateralValueInUsd) = _getAccountInformation(user);
    // xxx* LIQUIDATION_THRESHOLD / LIQUIDATION_PRECISIO
    // xxx* 50/100 即是清算因子0.5
    uint256 collateralAdjustedForThreshold = (collateralValueInUsd * LIQUIDATION_THRESHOLD) / LIQUIDATION_PRECISION;
	// 乘以精度，1e18 除以稳定币价格（可以看作借的钱）
    return (collateralAdjustedForThreshold * PRECISION) / totalDscMinted;

}
//获取稳定币总价格和抵押物总价格
function _getAccountInformation(address user) private view returns(uint256 totalDscMinted,uint256 collateralValueInUsd){
    totalDscMinted = s_DSCMinted[user];
    collateralValueInUsd = getAccountCollateralValue(user);
}
//计算抵押物总价格
function getAccountCollateralValue(address user) public view returns (uint256 totalCollateralValueInUsd) {
    for(uint256 i = 0; i < s_collateralTokens.length; i++){
        address token = s_collateralTokens[i];
        uint256 amount = s_collateralDeposited[user][token];
        totalCollateralValueInUsd += getUsdValue(token, amount);
    }
    return totalCollateralValueInUsd;
}

//获得对应抵押物usd价格
import { AggregatorV3Interface } from "@chainlink/contracts/src/v0.8/shared/interfaces/AggregatorV3Interface.sol";
function getUsdValue(address token, uint256 amount) 
public view 
returns(uint256){
    AggregatorV3Interface priceFeed = AggregatorV3Interface(s_priceFeeds[token]);
    (,int256 price,,,) = priceFeed.latestRoundData();
     return ((uint256(price * 1e10) * amount) / 1e18);
}
```
### 合并抵押和Mint
```c

function depositCollateralAndMintDsc(address tokenCollateralAddress, uint256 amountCollateral, uint256 amountDscToMint) external {
    depositCollateral(tokenCollateralAddress, amountCollateral);
    mintDsc(amountDscToMint);
}
```
### 赎回
```c
function redeemCollateralForDsc(address tokenCollateralAddress, uint256 amountCollateral, uint256 amountDscToBurn) external {
//销毁稳定币
    burnDsc(amountDscToBurn);
//转回资金
    redeemCollateral(tokenCollateralAddress, amountCollateral);
}

function burnDsc(uint256 amount) public moreThanZero(amount){
    s_DSCMinted[msg.sender] -= amount;
    bool success = i_dsc.transferFrom(msg.sender, address(this), amount);
    if(!success){
        revert DSCEngine__TransferFailed();
    }
    i_dsc.burn(amount);
    _revertIfHealthFactorIsBroken(msg.sender);
}

function redeemCollateral(address tokenCollateralAddress, uint256 amountCollateral) public moreThanZero(amountCollateral) nonReentrant{
    s_collateralDeposited[msg.sender][tokenCollateralAddress] -= amountCollateral;
    emit CollateralRedeemed(msg.sender, tokenCollateralAddress, amountCollateral);

    bool success = IERC20(tokenCollateralAddress).transfer(msg.sender, amountCollateral);
    if(!success){
        revert DSCEngine__TransferFailed();
    }

    _revertIfHealthFactorIsBroken(msg.sender);
}
```
 ```ad-tip
 `IERC20(tokenCollateralAddress).transfer(msg.sender, amountCollateral);`
 **资金默认是从合约地址 `address(this)` 转回用户地址 `msg.sender`**。以下是具体逻辑和关键点的分步解释：
```
###  清算
#### ​例子
1. ​**初始状态**
    
    - 用户抵押 ​$100（如 ETH），借出 ​$50稳定币（如 `DSC`）。
    - 协议要求**抵押率（Collateral Ratio）为 200%​**，即每借 $1 需抵押 $2。
    - ​**健康因子（Health Factor）​** 计算公式：
    -$H_f = \frac{ \text{抵押品价值}}{\text{债务}\times抵押率}$
    - 初始健康子：Hf​=50×2/100​=1.0(临界安全值)
2. 清算过程
- 用户存入100美元的抵押品，铸造了50美元的DSC。
- 抵押品价值下降到75美元，导致健康因子降到0.75，触发清算。
- 清算人销毁50美元的DSC来平仓。
- 清算人获得75美元的抵押品作为奖励，获利25美元。
#### 清算函数
```c
uint256 LIQUIDATION_BONUS = 10
function liquidate(
    address collateral, //抵押物地址
    address user,       //被清算对象
    uint256 debtToCover //清算人愿意还的债务数量
)
    external
    isAllowedToken(collateral)  // 抵押品必须为白名单代币
    moreThanZero(debtToCover)   // 债务必须 >0
    nonReentrant                // 防止重入攻击
{
    // 检查用户（被清算）当前健康因子是否已低于阈值
    uint256 startingUserHealthFactor = _healthFactor(user);
    if (startingUserHealthFactor >= MIN_HEALTH_FACTOR) {
        revert DSCEngine__HealthFactorOk();
    }

    // 计算债务对应的抵押品数量（按当前价格）
    uint256 tokenAmountFromDebtCovered = getTokenAmountFromUsd(collateral, debtToCover);
    
    // 计算清算奖励（如 10%）
    uint256 bonusCollateral = (tokenAmountFromDebtCovered * LIQUIDATION_BONUS) / LIQUIDATION_PRECISION;

    // 转移抵押品（本金 + 奖励）给清算人
    _redeemCollateral(collateral, tokenAmountFromDebtCovered + bonusCollateral, user, msg.sender);
    
    // 销毁清算人提供的 DSC，减少用户债务
    // 根据后面的函数解释一下
    // 首先减少user被清算用户稳定币
    // 并且由清算人，去还稳定币，即清算人销毁自己借给被清算用户的稳定币
    _burnDsc(debtToCover, user, msg.sender);

    // 验证用户（被清算）健康因子是否改善
    uint256 endingUserHealthFactor = _healthFactor(user);
    if (endingUserHealthFactor <= startingUserHealthFactor) {
        revert DSCEngine__HealthFactorNotImproved();
    }

    // 确保清算人自身健康因子安全
    revertIfHealthFactorIsBroken(msg.sender);
}
```
#### 重构赎回
```c
function _redeemCollateral(address tokenCollateralAddress, uint256 amountCollateral, address from, address to) 
private {
    s_collateralDeposited[from][tokenCollateralAddress] -= amountCollateral;
    emit CollateralRedeemed(msg.sender, tokenCollateralAddress, amountCollateral);

    bool success = IERC20(tokenCollateralAddress).transfer(to, amountCollateral);
    if(!success){
        revert DSCEngine__TransferFailed();
    }
}

function redeemCollateral(address tokenCollateralAddress, uint256 amountCollateral) public moreThanZero(amountCollateral) nonReentrant{
    _redeemCollateral(tokenCollateralAddress, amountCollateral, msg.sender, msg.sender);
    _revertIfHealthFactorIsBroken(msg.sender);
}
```
```ad-note
|参数名|类型|作用|
|---|---|---|
|`tokenCollateralAddress`|`address`|抵押品代币的合约地址（如 ETH、WBTC）|
|`amountCollateral`|`uint256`|赎回的抵押品数量|
|`from`|`address`|抵押品来源地址（赎回者）|
|`to`|`address`|抵押品接收地址|
```
#### 重构燃烧
```c
function burnDsc(uint256 amount) public moreThanZero(amount){
    _burnDsc(amount, msg.sender, msg.sender);
    _revertIfHealthFactorIsBroken(msg.sender);
}

function _burnDsc(uint256 amountDscToBurn, address onBehalfOf, address dscFrom) private {
    s_DSCMinted[onBehalfOf] -= amountDscToBurn;

    bool success = i_dsc.transferFrom(dscFrom, address(this), amountDscToBurn);
    // This conditional is hypothetically unreachable
    if (!success) {
        revert DSCEngine__TransferFailed();
    }
    i_dsc.burn(amountDscToBurn);
}
```
## 部署Deploy
### config
```c
contract HelperConfig is Script {

    struct NetworkConfig{
        address wethUsdPriceFeed;
        address wbtcUsdPriceFeed;
        address weth;
        address wbtc;
        uint256 deployerKey;
    }

    NetworkConfig public activeNetworkConfig;

    constructor() {
    if(block.chainid == 11155111){
        activeNetworkConfig = getSepoliaEthConfig();
    } else{
        activeNetworkConfig = getOfCreateAnvilEthConfig();
    }
}
}
function getSepoliaEthConfig() public view returns (NetworkConfig memory sepoliaNetworkConfig) {
    sepoliaNetworkConfig = NetworkConfig({
        wethUsdPriceFeed: 0x694AA1769357215DE4FAC081bf1f309aDC325306, // ETH / USD
        wbtcUsdPriceFeed: 0x1b44F3514812d835EB1BDB0acB33d3fA3351Ee43,
        weth: 0xdd13E55209Fd76AfE204dBda4007C227904f0a81,
        wbtc: 0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063,
        deployerKey: vm.envUint("PRIVATE_KEY")
    });
}

```
```ad-tip
weth 是一个代币合约地址
```
### 本地
```c
function getOrCreateAnvilEthConfig() public returns (NetworkConfig memory anvilNetworkConfig) {
    // Check to see if we set an active network config
    if (activeNetworkConfig.wethUsdPriceFeed != address(0)) {
        return activeNetworkConfig;
    }

    vm.startBroadcast();
    MockV3Aggregator ethUsdPriceFeed = new MockV3Aggregator(DECIMALS, ETH_USD_PRICE);
    ERC20Mock wethMock = new ERC20Mock("WETH", "WETH", msg.sender, 1000e8);

    MockV3Aggregator btcUsdPriceFeed = new MockV3Aggregator(DECIMALS, BTC_USD_PRICE);
    ERC20Mock wbtcMock = new ERC20Mock("WBTC", "WBTC", msg.sender, 1000e8);
    vm.stopBroadcast();
}
```
```c
//MockV3Aggregator.sol
pragma solidity ^0.8.0;

/**
 * @title MockV3Aggregator
 * @notice Based on the FluxAggregator contract
 * @notice Use this contract when you need to test
 * other contract's ability to read data from an
 * aggregator contract, but how the aggregator got
 * its answer is unimportant
 */
contract MockV3Aggregator {
    uint256 public constant version = 0;

    uint8 public decimals;
    int256 public latestAnswer;
    uint256 public latestTimestamp;
    uint256 public latestRound;

    mapping(uint256 => int256) public getAnswer;
    mapping(uint256 => uint256) public getTimestamp;
    mapping(uint256 => uint256) private getStartedAt;

    constructor(uint8 _decimals, int256 _initialAnswer) {
        decimals = _decimals;
        updateAnswer(_initialAnswer);
    }

    function updateAnswer(int256 _answer) public {
        latestAnswer = _answer;
        latestTimestamp = block.timestamp;
        latestRound++;
        getAnswer[latestRound] = _answer;
        getTimestamp[latestRound] = block.timestamp;
        getStartedAt[latestRound] = block.timestamp;
    }

    function updateRoundData(uint80 _roundId, int256 _answer, uint256 _timestamp, uint256 _startedAt) public {
        latestRound = _roundId;
        latestAnswer = _answer;
        latestTimestamp = _timestamp;
        getAnswer[latestRound] = _answer;
        getTimestamp[latestRound] = _timestamp;
        getStartedAt[latestRound] = _startedAt;
    }

    function getRoundData(uint80 _roundId)
        external
        view
        returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound)
    {
        return (_roundId, getAnswer[_roundId], getStartedAt[_roundId], getTimestamp[_roundId], _roundId);
    }

    function latestRoundData()
        external
        view
        returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound)
    {
        return (
            uint80(latestRound),
            getAnswer[latestRound],
            getStartedAt[latestRound],
            getTimestamp[latestRound],
            uint80(latestRound)
        );
    }

    function description() external pure returns (string memory) {
        return "v0.6/tests/MockV3Aggregator.sol";
    }
}
```
## fuzz Test
1. 找到不变量（断言）
2. 尝试打破不变量
3. `fail_on_revert` and `return_on_revert` same important
### 不变量（断言）
#### ​**1. 直接断言（Direct Assertions）​**

**定义**  
直接通过查询合约的公开状态或函数返回值，直接断言其是否符合预期。这是最基础的断言方法。

```c
// 验证协议的总资产必须 >= 总代币供应量（防止资不抵债）
assertGe(
    token.totalAssets(),  // 查询合约的实际资产
    token.totalSupply()   // 查询合约的代币总供应量
);
```
#### ​**2. 幽灵变量断言（Ghost Variable Assertions）​**

**定义**  
通过在测试环境中维护一个“幽灵变量”（手动跟踪的预期值），并与合约的实际状态进行对比，验证两者一致性。
```c
// 测试代币转账时，手动跟踪所有用户的余额总和
uint256 sumBalanceOf;  // 幽灵变量

// 每次转账后更新幽灵变量
sumBalanceOf += amount;
sumBalanceOf -= amount;

// 断言：代币总供应量 == 所有用户余额总和（确保无额外铸造或销毁）
assertEq(
    token.totalSupply(),  // 合约的实际总供应量
    sumBalanceOf          // 测试环境维护的总和
);
```
#### ​**3. 去优化断言（Naive Implementation Assertions）​**

**定义**  
通过对比合约的优化实现和一个简单但低效的“参考实现”（如暴力算法），验证两者结果的一致性。
```c
// 对比实际利息计算结果与暴力计算的预期值
assertEq(
    pool.outstandingInterest(),  // 合约中的优化实现
    testNaiveInterest()           // 测试环境中的简单实现（如遍历所有用户计算）
);
```
### source
```c
//SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract MyContract {
    uint256 public shouldAlwaysBeZero = 0;
    uint256 hiddenValue = 0;

    function doStuff(uint256 data) public {
        if (data == 2){
            shouldAlwaysBeZero = 1;
        }
        if (hiddenValue == 7) {
            shouldAlwaysBeZero = 1;
        }
    }
}
```
### 无状态测试
```c
function testIAlwaysGetZero(uint256 data) public {
    myContract.doStuff(data);
    assert(myContract.shouldAlwaysBeZero() == 0);
}
//foundry.toml
[fuzz]
runs = 1000
```
```ad-tip
他每次开一个新的测试然后穷举data，然鹅，并没有能通过hiddenValue去打破不变量
```
### 状态测试 Invariant testing(不变测试)
```c
//foundry.toml
run=1000
depth=128
//交易失败恢复但是不报错
fail_on_revert = false
```
```c
contract NFT721Test is StdInvariant, Test {
    CaughtWithTest myContract;

    function setUp() public {
        myContract = new CaughtWithTest();
        targetContract(address(myContract));
    }
}
function invariant_testAlwaysReturnsZero() public view {
    assert(myContract.shouldAlwaysBeZero() == 0);
}
```

| ​**目标类型**                      | ​**作用**                           | ​**适用场景**                                             |
| ------------------------------ | --------------------------------- | ----------------------------------------------------- |
| ​**Target Contracts**          | 指定待测试的合约地址集合（默认包含 `setUp` 中部署的合约） | 测试自定义部署的合约                                            |
| ​**Target Senders**            | 指定允许的 `msg.sender` 地址集合（默认随机生成）   | 测试权限控制（如仅允许特定角色调用）                                    |
| ​**Target Interfaces**         | 指定接口规范，用于测试代理合约或分叉环境中未部署的合约       | 分叉主网测试（如 Uniswap 的 Router 合约）或代理合约（如 OpenZeppelin 代理） |
| ​**Target Selectors**          | 指定目标合约中待测试的函数选择器（Selector）集合      | 仅测试关键函数（如 `deposit` 和 `withdraw`）                     |
| ​**Target Artifacts**          | 指定合约的 ABI（编译产物）用于解析接口             | 测试多版本合约或代理合约的不同实现                                     |
| ​**Target Artifact Selectors** | 指定某个 ABI 中待测试的函数选择器集合             | 测试代理合约的特定接口函数                                         |
1. 分叉测试 Uniswap V3 的 Swap 功能
```c
function setUp() public {
    vm.createSelectFork("mainnet");
    
    // 指定测试 Uniswap V3 Router 的 exactInput 函数
    targetInterface(
        FuzzInterface(
            address(0xE592427A0AEce92De3Edee1F18E0157C05861564), // Uniswap V3 Router
            ["exactInput"]
        )
    );
    
    // 排除不相关的合约（如 Factory）
    excludeContract(address(0x1F98431c8aD98523631AE4a59f267346ea31F984)); // Uniswap V3 Factory
}
```

2. 测试代理合约的升级逻辑
```c
contract ProxyTest is Test {
    Proxy proxy;
    LogicV1 logicV1;
    LogicV2 logicV2;

    function setUp() public {
        proxy = new Proxy();
        logicV1 = new LogicV1();
        logicV2 = new LogicV2();
        
        // 初始使用 V1 逻辑
        proxy.upgradeTo(address(logicV1));
        
        // 指定测试 Proxy 合约的 V2 接口
        targetArtifact("LogicV2"); // 加载 LogicV2 的 ABI
        targetArtifactSelector(
            FuzzArtifactSelector("LogicV2", "newFunction()")
        );
    }
}
```

3. 限制测试函数范围
```c
function setUp() public {
    pool = new LendingPool();
    
    // 仅测试 deposit 和 withdraw 函数
    targetSelector(
        FuzzSelector(
            address(pool),
            [
                bytes4(keccak256("deposit(uint256)")),
                bytes4(keccak256("withdraw(uint256)"))
            ]
        )
    );
    
    // 排除高风险函数（如管理员权限操作）
    excludeSelector(
        FuzzSelector(
            address(pool),
            [bytes4(keccak256("setAdmin(address)"))]
        )
    );
}
```
### Handler 模式测试
#### Handler 是什么？
**Handler（处理程序）** 就像一个 **智能测试机器人**，专门帮你完成两件事：
1. **自动准备测试环境**：比如在测试存款功能前，先给你的账户打钱。
2. **安全执行测试操作**：确保每次调用合约方法时参数合法，避免测试失败。

👉 **类比**：就像你去餐厅点菜，服务员（Handler）会先检查你是否有钱、菜单是否正确，再帮你下单，避免你直接点菜时出现“钱不够”或“菜不存在”的问题。

#### 为什么需要 Handler？

##### 无 Handler测试的问题
假设有一个存款合约：
```c
function deposit(uint256 amount) public {
    require(amount > 0, "Amount must > 0");
    require(balance[msg.sender] >= amount, "Insufficient balance");
    // 存款逻辑...
}
```

直接测试会这样调用：
```c
function testDeposit() public {
    deposit(100); // 直接调用存款 100
}
```
但问题：
1. 如果随机测试传入 `amount = 0` → 直接失败。
2. 用户账户没有钱 → 直接失败。

导致测试结果不可靠（大量无效回滚）。
##### 使用 Handler 后的测试
Handler 会帮你：
```c
function deposit(uint256 amount) public {
    // 1. 调整参数：确保 amount > 0
    amount = bound(amount, 1, 1000); 
    
    // 2. 自动给你打钱
    mint(msg.sender, amount);
    
    // 3. 执行存款
    vault.deposit(amount);
    
    // 4. 自动检查结果
    assertEq(vault.balance(msg.sender), amount);
}
```
这样测试时：
• 参数永远合法（如 amount 自动调整到 1-1000）。
• 账户永远有钱。
• 每次调用都有效！
#### 四大核心功能

##### 1. **参数约束**
```c
function deposit(uint256 amount) public {
    amount = bound(amount, 1, 1000); // 强制 amount 在 1-1000 之间
    // ...
}
```

##### 2. **状态准备**
```c
function deposit(uint256 amount) public {
    mint(msg.sender, amount); // 先给你的账户打钱
    approve(vault, amount);   // 授权合约使用你的钱
    // ...
}
```

##### 3. **多角色管理**
```c
address[] users = [Alice, Bob, Charlie];

function deposit(uint256 userIndex, uint256 amount) public {
    userIndex = bound(userIndex, 0, 2); // 随机选一个用户
    vm.prank(users[userIndex]);         // 切换操作者
    vault.deposit(amount);
}
```

##### 4. **幽灵记账**
```c
uint256 totalDeposits; // 记录总存款量（测试环境单独记账）

function deposit(uint256 amount) public {
    vault.deposit(amount);
    totalDeposits += amount; // 更新幽灵变量
    
    // 断言：合约内的总存款 = 幽灵变量
    assertEq(vault.totalDeposits(), totalDeposits);
}
```
```ad-tip
不断变化幽灵变量的位置，可以找到bug
尤其是测试某个函数，不应该有大多恢复，
或者设置一个幽灵变量，测试成功调用加一，如果为0，即没有被调用，显然不正常
```

#### 四、完整示例：ERC-4626 存款测试

##### 1. 合约代码（简化版）
```c
contract Vault {
    mapping(address => uint256) public balance;
    
    function deposit(uint256 amount) public {
        require(amount > 0, "Amount must > 0");
        balance[msg.sender] += amount;
    }
}
```

##### 2. Handler 实现
```c
contract VaultHandler is Test {
    Vault vault;
    uint256 public totalDeposits; // 幽灵变量

    constructor(Vault _vault) {
        vault = _vault;
    }

    // 存款方法（带参数约束和状态准备）
    function deposit(uint256 amount) public {
        // 参数约束
        amount = bound(amount, 1, 1000); 
        
        // 状态准备：给用户打钱
        deal(address(this), amount); 
        
        // 执行存款
        vault.deposit(amount);
        
        // 更新幽灵变量
        totalDeposits += amount;
        
        // 断言：合约内的余额正确
        assertEq(vault.balance(address(this)), totalDeposits);
    }
}
```

##### 3. 不变量测试
```c
contract VaultTest is Test {
    Vault vault;
    VaultHandler handler;

    function setUp() public {
        vault = new Vault();
        handler = new VaultHandler(vault);
        targetContract(address(handler)); // 告诉测试器调用 Handler 的方法
    }

    // 不变量：总存款量必须等于所有用户余额之和
    function invariant_totalDeposits() public {
        assertEq(handler.totalDeposits(), vault.totalDeposits());
    }
}
```

| **场景**               | **无 Handler**                | **有 Handler**                |
|-------------------------|-------------------------------|-------------------------------|
| **参数有效性**          | 可能传入无效参数（如 amount=0） | 自动约束参数范围              |
| **状态准备**            | 需手动初始化（如打钱、授权）     | 自动完成所有准备工作          |
| **多用户模拟**          | 难以模拟多用户并发操作           | 轻松切换不同用户              |
| **结果跟踪**            | 需手动记录预期结果               | 幽灵变量自动同步状态          |
```ad-tip
bound(x,min,max)
对于如下函数maxCollateralToRedeem可能为0，
报错 max must less than min
`amountCollateral = bound(amountCollateral, 1, maxCollateralToRedeem);`
you can
`amountCollateral = bound(amountCollateral, 0, maxCollateralToRedeem);`
`if(amountCollateral == 0) return;`

```
## Oracle Test
```c
...
import {AggregatorV3Interface} from "@chainlink/contracts/src/v0.8/interfaces/AggregatorV3Interface.sol";
...
library OracleLib {

    error OracleLib__StalePrice();
    uint256 private constant TIMEOUT = 3 hours;

    function staleCheckLatestRoundData(AggregatorV3Interface pricefeed) public view returns (uint80, int256, uint256, uint256, uint80) {
        (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound) = pricefeed.latestRoundData();

        uint256 secondsSince = block.timestamp - updatedAt;
        if (secondsSince > TIMEOUT) revert OracleLib__StalePrice();

        return (roundId, answer, startedAt, updatedAt, answeredInRound);
    }
}
```

以下是使用 `forge test --debug` 调试 Solidity 合约时最**核心实用的技巧总结**，适用于快速定位错误、理解失败栈、修改逻辑：


## 🔧 Forge 调试核心技巧（debug 精华）

### 🛠️ 1. 启动调试器（推荐格式）

```bash
forge test --debug <测试函数名> -vvv
```

- `--debug`：启用调试模式。
    
- `<测试函数名>`：只调试指定的测试函数。
    
- `-vvv`：启用最高日志详细等级，方便查看日志与事件。
    


### 🎯 2. 常用快捷键（调试器内）

|快捷键|功能|
|---|---|
|`Shift + G`|直接跳转到 **revert（错误）发生的位置** ✅|
|`J` / `K`|向后 / 向前 单步执行 Solidity 源码|
|`n`|下一步（next）|
|`s`|进入函数（step into）|
|`c`|跳出当前函数（continue）|
|`q`|退出调试器（quit）|
|`b <函数名>`|设置断点（breakpoint）|
|`l`|显示当前执行位置的 Solidity 代码（list）|


### 🧠 3. 常见使用策略

#### ✅ 快速定位 bug

```bash
forge test --debug testXYZ -vvv
```

调试器打开后，**按 `Shift+G`** → 直接跳到失败行，看是哪一行导致了 revert。

#### ✅ 回退查看上下文

按 `J` 多次后退，找到出错函数的调用链（比如是哪个 `require` 或 `revert` 触发）。

#### ✅ 确认调用者 & 参数

调试时常见错误是传了错误的合约地址或参数。通过 `J` 往上走几步，**定位是哪个值出错**，是不是我们误传了 `config.account` 而不是 `minimalAccount`。

#### ✅ 验证内部调用流程

用 `s`（step into）进入函数体，可以检查内部逻辑，配合 `J` 查看变量传递是否正确。


### 🔍 4. debug 常见配合命令

|命令|用途|
|---|---|
|`forge snapshot`|快速记录当前测试状态|
|`forge test -vvvv`|无需进入调试器，显示详细 Trace|
|`forge test --match-test testXXX`|精确运行一个测试（不调试）|
|`forge inspect <Contract> <Selector>`|查看 ABI、函数选择器等辅助信息|


## 🧩 使用场景举例

### 示例：调试 MinimalAccount 的验证失败

```bash
forge test --debug testEntryPointCanExecuteCommands -vvv
```

- 按 `Shift+G`：跳转到 `validateUserOp` 的 revert；
    
- 按 `J` 多次：看到 sender 是错误地址；
    
- 修改源码，传入正确的 `minimalAccount` 地址；
    
- 重试测试通过。
    


## ✅ 总结口诀（方便记忆）

```
调试启动用 debug，Shift+G 快速找 bug；
J/K 上下走栈线，s/c 切换函数圈；
q 退出别乱点，vvv 日志真关键。
```

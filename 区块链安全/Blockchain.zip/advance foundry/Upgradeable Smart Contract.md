# Introduction of Upgrades
## 可升级智能合约的核心矛盾
#### **1. 不可变性的意义**
- **信任基石**：传统智能合约的不可变性是区块链信任的核心，确保逻辑透明且无法篡改。
- **开发者困境**：漏洞修复、功能迭代需求与不可变性直接冲突，迫使开发者寻找中间方案。

#### **2. 升级需求的驱动**
- **安全补丁**：如The DAO事件后硬分叉的争议，体现紧急修复的必要性。
- **业务扩展**：DeFi协议需支持新资产类型或治理模型升级（如Uniswap V2到V3的迁移）。

## 主流升级方案
### **1. 参数化控制（非真正升级）**
- **实现方式**：
  ```c
  contract Parameterized {
      uint256 public rewardRate;
      address public owner;

      function setRewardRate(uint256 _rate) external {
          require(msg.sender == owner);
          rewardRate = _rate;
      }
  }
  ```
- **缺陷**：
  - **功能局限**：仅能调整预设参数，无法修改核心逻辑。
  - **中心化风险**：单一控制权违背去中心化原则，需结合时间锁或多签钱包。
### 2. 社交迁移
- **典型案例**：
  - **ERC20代币迁移**：新合约部署后，要求用户主动将旧代币转入新合约销毁并铸造新代币。
  - **Compound治理迁移**：通过社区投票决定是否采用新合约版本。
- **技术挑战**：
  - **状态迁移**：需设计快照机制（如SushiSwap的迁移工具）。
  - **生态适配**：交易所、钱包需更新合约地址，存在协调成本。

### 3. 代理模式

#### 透明代理（Transparent Proxy）
 **1. 核心原理：秘书代劳**
- **比喻**：你是一家公司的老板（用户），需要处理文件（调用合约）。但你不直接处理，而是交给秘书（代理合约）。秘书手里有两本手册：
  - **逻辑手册（逻辑合约）**：写满处理文件的具体步骤（业务逻辑）。
  - **管理员手册（Admin权限）**：记录如何更换逻辑手册（升级合约）。
- **工作流程**：
  1. 你让秘书处理文件，秘书翻看**当前逻辑手册**，按步骤执行。
  2. 老板（Admin）可以偷偷换掉逻辑手册，但你作为普通员工不知道。

```c
// 代理合约：秘书
contract TransparentProxy {
    address public logicContract; // 当前逻辑手册地址
    address public admin;         // 老板（有权换手册）

    // 普通员工提交文件请求
    fallback() external {
        // 秘书按当前手册处理
        (bool success, ) = logicContract.delegatecall(msg.data);
        require(success);
    }

    // 老板更换手册
    function upgrade(address newLogic) external {
        require(msg.sender == admin);
        logicContract = newLogic;
    }
}
```


#### 通用可升级代理（UUPS）
1. 核心原理：手册自带更新页
- **比喻**：秘书的逻辑手册里**自带更新页**（升级函数），老板无需额外权限。每次升级时，秘书直接在手册末尾贴上新章节（新逻辑合约地址）。
```c
// 逻辑合约：自带升级功能的手册
contract UUPSLogic {
    address public logicContract; // 当前手册地址
    address public owner;         // 老板

    // 普通功能：处理文件
    function doWork() external { /* ... */ }

    // 手册自带升级页
    function upgrade(address newLogic) external {
        require(msg.sender == owner);
        logicContract = newLogic;
    }
}

// 代理合约：秘书（更简单）
contract UUPSProxy {
    address public logicContract;

    fallback() external {
        (bool success, ) = logicContract.delegatecall(msg.data);
        require(success);
    }
}
```
```ad-tip
- **优点**：
  - **Gas费更低**：代理合约更简单。
  - **升级灵活**：升级逻辑写在手册里，可定制规则。
- **缺点**：
  - **必须保留升级页**：如果新手册忘记写升级页，再也无法升级（需严格测试）。
```


#### 钻石模式（Diamond）
 1. 核心原理：乐高积木手册
- **比喻**：秘书有一本**总目录（路由表）**和多个**分册（Facet合约）**。每个分册处理不同任务（如转账、查询、治理）。老板可以随时添加、替换分册，而总目录记录哪个分册负责哪项工作。

```c
// 钻石代理合约：总目录
contract Diamond {
    mapping(bytes4 => address) public facets; // 记录功能对应的分册地址

    // 添加分册（由老板控制）
    function addFacet(bytes4 funcSelector, address facet) external {
        facets[funcSelector] = facet;
    }

    // 处理请求：查目录找分册
    fallback() external {
        address facet = facets[msg.sig]; // 根据功能选择分册
        (bool success, ) = facet.delegatecall(msg.data);
        require(success);
    }
}

// 分册1：转账功能
contract TransferFacet {
    function transfer(address to, uint amount) external { /* ... */ }
}

// 分册2：查询功能
contract QueryFacet {
    function getBalance() external view returns (uint) { /* ... */ }
}
```

### 选型决策树
1. **是否需要修改核心逻辑？**
   - 否 → **参数化控制**
   - 是 → 进入下一步

2. **能否接受地址变更？**
   - 能 → **社交迁移**
   - 否 → **代理模式**

3. **业务复杂度级别？**
   - 简单 → **透明代理**
   - 中等 → **UUPS**
   - 超高 → **钻石模式**
# Delegatecall
## example
contract B
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// NOTE: Deploy this contract first
contract B {
    // NOTE: storage layout must be the same as contract A
    uint256 public num;
    address public sender;
    uint256 public value;

    function setVars(uint256 _num) public payable {
        num = _num;
        sender = msg.sender;
        value = msg.value;
    }
}
```
contract A
```c
contract A {
    uint256 public num;
    address public sender;
    uint256 public value;

    function setVars(address _contract, uint256 _num) public payable {
        // A's storage is set, B is not modified.
        (bool success, bytes memory data) = _contract.delegatecall(
            abi.encodeWithSignature("setVars(uint256)", _num)
        );
    }
}
```
![[Pasted image 20250503144316.png]]
```ad-important
### **`delegatecall` 的本质**

- **功能**：允许 **合约A** 调用 **合约B** 的逻辑代码，但执行时使用的是 **合约A的存储环境**（变量、状态）。
    
- **类比**：就像你（合约A）借用了朋友（合约B）的菜谱（代码逻辑）来做饭，但所有食材和厨具（存储数据）都是你自己的。
```
# EIP-1967
```c
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.19;

import "@openzeppelin/contracts/proxy/Proxy.sol";

contract SmallProxy is Proxy {
    // This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1
    bytes32 private constant _IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;

    function setImplementation(address newImplementation) public {
        assembly {
            sstore(_IMPLEMENTATION_SLOT, newImplementation)
        }
    }

    function _implementation() internal view override returns (address implementationAddress) {
        assembly {
            implementationAddress := sload(_IMPLEMENTATION_SLOT)
        }
    }
```
```ad-note
`bytes32 private constant _IMPLEMENTATION_SLOT = 
    0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;`
 - **EIP-1967 标准槽位**：此值通过计算 `keccak256("eip1967.proxy.implementation") - 1` 得到，用于安全存储逻辑合约地址，避免与其他存储冲突。
    
- **作用**：代理合约通过此槽位记录当前逻辑合约的地址。
```

```c
function setImplementation(address newImplementation) public {
    assembly {
        sstore(_IMPLEMENTATION_SLOT, newImplementation)
    }
}
```
```ad-note
 - 使用内联汇编 `sstore` 将 `newImplementation` 写入 `_IMPLEMENTATION_SLOT` 存储槽。
```
```c
function _implementation() internal view override returns (address implementationAddress) {
    assembly {
        implementationAddress := sload(_IMPLEMENTATION_SLOT)
    }
}
```
```ad-note
- 通过内联汇编 `sload` 从 `_IMPLEMENTATION_SLOT` 读取存储的逻辑合约地址。
```
```ad-tip
内联汇编[Yul](https://docs.soliditylang.org/en/latest/yul.html)
```
# UUPS
## 需要升级的合同
```c
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.18;

import {UUPSUpgradeable} from "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";

contract BoxV1 is UUPSUpgradeable {
    uint256 internal number;

    function getNumber() external view returns (uint256) {
        return number;
    }

    function version() external pure returns (uint256) {
        return 1;
    }

    function _authorizeUpgrade(address newImplementation) internal override{}
}
```
```ad-note
` function _authorizeUpgrade(address newImplementation) internal override{}`
是必要的，否则在继承后会显示抽象类
```
```ad-tip
`uint256[50] private __gap;`
提供额外的储存槽，为以后升级
```
## 需要一个initializable
### 问题
代理模式存储架构的核心矛盾——存储位置分离
- **代理合约（Proxy）**：负责维护协议状态（所有存储变量）
- **逻辑合约（Implementation）**：仅包含业务逻辑，无持久化存储
    
#### **构造函数（Constructor）的局限性**
```c
contract LogicV1 {
    address public admin;  // 假设需要在部署时初始化

    // 构造函数仅在逻辑合约部署时执行
    constructor(address initialAdmin) {
        admin = initialAdmin;  // 写入 LogicV1 的存储空间
    }
}
```
- **致命问题**：当代理合约通过 `delegatecall` 调用逻辑合约时，实际存储访问的是代理合约的存储空间，而构造函数的写入发生在逻辑合约自身存储中，二者完全隔离。
    

### 攻击场景演示
#### **未受控的初始化**

假设代理合约直接使用逻辑合约的构造函数：

```c
// 攻击者部署恶意逻辑合约
contract MaliciousLogic {
    address public admin;

    constructor() {
        admin = msg.sender;  // 攻击者成为管理员
    }
}
// 代理合约使用该逻辑
SmallProxy proxy = new SmallProxy();
proxy.setImplementation(address(new MaliciousLogic()));
```

- **后果**：代理合约的 `admin` 字段未被修改，但攻击者控制逻辑合约的存储，可能通过其他途径劫持系统。

#### **存储布局不匹配灾难**

```c
// 逻辑合约 V1
contract LogicV1 {
    uint256 public valueA;  // Slot 0
}

// 逻辑合约 V2
contract LogicV2 {
    address public owner;   // Slot 0（覆盖原 valueA）
    uint256 public valueB;  // Slot 1
}
```
- 升级到 V2 后，Slot 0 的数据被解释为 `address` 类型，导致数据损坏。
### 解决
```c
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.18;

import {UUPSUpgradeable} from "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import {Initializable} from "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import {OwnableUpgradeable} from "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";

contract BoxV1 is Initializable, UUPSUpgradeable, OwnableUpgradeable {
    uint256 internal number;

    /// @custom:oz-upgrades-unsafe-allow constructor
    // forbid constructor
    constructor() {
        _disableInitializers();
    }
	// use initialize instead
    function initialize() public initializer {
        __Ownable_init(msg.sender);
        __UUPSUpgradeable_init();
    }

	 //.....
}
```
## 部署
```c
//SPDX-License-Identifier: MIT

pragma solidity ^0.8.18;

import {Script} from "forge-std/Script.sol";
import {BoxV1} from "../src/BoxV1.sol";
import {ERC1967Proxy} from "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";

contract DeployBox is Script {
    function run() external returns(address) {
        address proxy = deployBox();
        return proxy;
    }

    function deployBox() public returns(address) {
        vm.startBroadcast();
        BoxV1 box = new BoxV1(); // Implementation
        ERC1967Proxy proxy = new ERC1967Proxy(address(box), "");
        BoxV1(address(proxy)).initialize();
        vm.stopBroadcast();
        return address(proxy);
    }
}
```
## 开始第一次升级
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import {Script} from "forge-std/Script.sol";
import {BoxV1} from "../src/BoxV1.sol";
import {BoxV2} from "../src/BoxV2.sol";
import {ERC1967Proxy} from "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";
import {DevOpsTools} from "lib/foundry-devops/src/DevOpsTools.sol";

contract UpgradeBox is Script {
    function run() external returns (address) {
        address mostRecentlyDeployedProxy = DevOpsTools.get_most_recent_deployment("ERC1967Proxy", block.chainid);

        vm.startBroadcast();
        BoxV2 newBox = new BoxV2();
        vm.stopBroadcast();
        address proxy = upgradeBox(mostRecentlyDeployedProxy, address(newBox));
        return proxy;
    }

    function upgradeBox(address proxyAddress, address newBox) public returns (address) {
        vm.startBroadcast();
        BoxV1 proxy = BoxV1(payable(proxyAddress));
        proxy.upgradeTo(address(newBox));
        vm.stopBroadcast();
        return address(proxy);
    }
}
```
```ad-info


**UUPS 代理最终可能会被删除其可升级性。**


1. **核心区别**  
   - **UUPS 模式**：将升级逻辑放在**逻辑合约**中，而非代理合约。  
   - **透明代理模式**：将升级逻辑放在**代理合约**中，通过权限分离（管理员与普通用户）避免函数冲突。

2. **关键优势**  
   - **可终结性**：UUPS 允许在逻辑合约中完全移除升级功能（例如通过删除 `upgradeTo()` 方法），使合约最终不可变。这对项目成熟后增强信任至关重要。  
   - **Gas 优化**：由于代理合约不处理升级逻辑，每次调用的 Gas 消耗更低（无需检查调用者身份）。

**结论：**  
选择 UUPS 的核心原因是其允许合约通过移除升级逻辑实现最终不可变性，这对安全性和用户信任至关重要。
```


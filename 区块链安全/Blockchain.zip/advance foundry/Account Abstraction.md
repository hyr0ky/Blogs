# Introduction
## ✅ 什么是账户抽象（Account Abstraction，AA）？

账户抽象是指将账户控制权和交易验证的逻辑从以太坊协议层“抽象”出来，交由 **智能合约账户** 自定义控制逻辑。这样用户不必再依赖传统的 EOA（Externally Owned Account，外部账户）及私钥体系，可以使用更灵活、安全的机制来控制账户和交易。

## 💡 它解决了哪些问题？

|问题|账户抽象的解决方案|
|---|---|
|私钥丢失或被盗风险高|支持使用 Google、手机、指纹、多签等更友好的认证方式代替传统私钥签名|
|交易验证机制单一|支持用户自定义交易验证逻辑，如多签、社交恢复|
|Gas 支付必须自己出|通过 Paymaster 实现“别人帮你付 Gas”（如 DApp 支付）|
|EOA 账户不可扩展|所有账户可以变为智能合约钱包，灵活扩展功能|


## 🛠 两个主流实现方式（Entry Points）

### 1. **Ethereum

- **UserOperation（用户操作）**：一类结构体交易，不是原生交易。
    
- **Bundler**：从 alt-mempool 收集 UserOperation，并提交给链上的 `EntryPoint.sol`。
    
- **EntryPoint 合约**：调用用户的合约钱包执行交易。
    
- **可选组件**：
    
    - `Paymaster`：为用户代付 gas。
        
    - `Signature Aggregator`：聚合多个签名（支持社交恢复、多签验证）。
        
### ⛓️ 执行流程：

1. 用户使用 AA 钱包生成 UserOperation。
    
2. 发送到 Bundler（监听 alt-mempool 的节点）。
    
3. Bundler 将打包操作提交到链上的 `EntryPoint.sol`。
    
4. EntryPoint 验证签名、调用用户合约。
    
5. 交易被执行。

> 用户流程：本地签名 → 发送到 Bundler（alt-mempool 节点） → EntryPoint.sol → 链上执行

![[Pasted image 20250503170016.png]]
### 2. **ZKsync — 原生集成 AA**

#### 🌟 主要特点：

- 每个钱包默认是智能合约（对接 `DefaultAccount.sol`）
- zkSync 节点本身就扮演 Bundler/EntryPoint 的角色    
- 不需要 alt-mempool，直接接收用户操作
- 支持 Paymaster 合约作为插件使用
#### 🚀 执行流程：
1. 用户通过 zkSync AA 钱包发起交易。
    
2. 交易进入 zkSync 节点（Sequencer）内部 mempool。
    
3. Sequencer 调用 zkSync Bootloader 验证与执行逻辑。
    
4. 若使用 Paymaster，可在执行阶段代付 gas。
    
5. 最终调用用户合约账户完成交易。
    

> 用户流程：直接使用智能账户 → ZKsync 验证 → 链上执行（无需中转 EntryPoint.sol）

![[ChatGPT Image May 3, 2025, 05_06_29 PM.png]]

## 📂 Alt-Mempool 是什么？

传统 mempool 是以太坊节点用于接收普通交易的队列，而 alt-mempool 是 **用于接收账户抽象中的 UserOperation 的专用通道**，一般由专门的 Bundler 节点（如 StackUp、Alchemy）托管。


## 🔧 EntryPoint.sol 的两个可选插件

|插件名|功能|
|---|---|
|**Signature Aggregator**|多签名聚合与验证，支持群体签名、社交恢复等|
|**Paymaster**|帮用户支付 gas，可设置 DApp 帮用户出钱，提升用户体验|

# ETH Account Abstraction
## UserOperation
```c
// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
//UserOperation core interface
import { IAccount } from "lib/account-abstraction/contracts/interfaces/IAccount.sol";
import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";

contract MinimalAccount is IAccount, Ownable {
    constructor() Ownable(msg.sender) {}

    function validateUserOp(
        PackedUserOperation calldata userOp,
        bytes32 userOpHash,
        uint256 missingAccountFunds
    ) external returns (uint256 validationData) {}	
}

```
### PackedUserOperation
我们先整体看看这个结构：

```c
struct PackedUserOperation {
    address sender;
    uint256 nonce;
    bytes initCode;
    bytes callData;
    bytes32 accountGasLimits;
    uint256 preVerificationGas;
    bytes32 gasFees;
    bytes paymasterAndData;
    bytes signature;
}
```

|字段名|含义|
|---|---|
|`address sender`|操作发起账户的地址，也就是我们“最小账户钱包”的地址。|
|`uint256 nonce`|防止重放攻击的随机数。每笔交易都有唯一编号，确保不被重复执行。|
|`bytes callData`|调用数据，是交易的“核心内容”。比如你要授权花费 50 个 USDC，就会在这里填入对应的调用指令和参数。|
|`bytes paymasterAndData`|可选字段。如果有人帮你付 Gas（比如 DApp），这里会包含付款账户的信息和相关数据。|
|`bytes signature`|签名信息，证明这笔操作确实是由 `sender` 发起，保障交易的合法性。|
### validateUserOp
```c
    function validateUserOp(
        PackedUserOperation calldata userOp,
        bytes32 userOpHash,
        uint256 missingAccountFunds
    ) external returns (uint256 validationData) {
    // 1. validateSignature
	validationData = _validateSignature(userOp, userOpHash);
	// 2.  负责向 EntryPoint 合约支付账户欠付的 Gas 费用 
	_payPrefund(missingAccountFunds)
    
    }
```
```ad-tip
- **`_payPrefund`**：账户自身 Gas 费用的应急补款机制，**不涉及 Paymaster**。
    
- **Paymaster**：第三方支付策略合约，提供灵活 Gas 付费方式。  
    两者在 ERC-4337 中协同工作，前者是安全兜底，后者是体验升级。
```
#### validateSignature
```c
function _validateSignature
(PackedUserOperation calldata userOp, bytes32 userOpHash)
        internal
        view
        returns (uint256 validationData)
    {
		bytes32 ethSignedMessageHash = \
		MessageHashUtils.toEthSignedMessageHash(userOpHash);
        address signer = ECDSA.recover(ethSignedMessageHash, userOp.signature);
        if (signer != owner()) {
            return SIG_VALIDATION_FAILED;
        }
        return SIG_VALIDATION_SUCCESS;
    }

    function toEthSignedMessageHash(bytes32 messageHash) 
    internal pure returns (bytes32 digest) {
        /// @solidity memory-safe-assembly
        assembly {
            mstore(0x00, "\x19Ethereum Signed Message:\n32") 
            mstore(0x1c, messageHash) // 
            digest := keccak256(0x00, 0x3c) 
        }
    }
```
## EntryPoint
### maincode
```c
import { IEntryPoint } from "lib/account-abstraction/contracts/interfaces/IEntryPoint.sol";

IEntryPoint private immutable i_entryPoint;

constructor(address entryPoint) 
	Ownable(msg.sender) {
     i_entryPoint = IEntryPoint(entryPoint)
}

function getEntryPoint() external view returns (address) {
        return address(i_entryPoint);
    }
```
### requireFromEntryPoint
```c
modifier requireFromEntryPoint() {
        if (msg.sender != address(i_entryPoint)) {
            revert MinimalAccount__NotFromEntryPoint();
        }
        _;
    }
```
修改validateUserOp
```c
function validateUserOp(PackedUserOperation calldata userOp, bytes32 userOpHash, uint256 missingAccountFunds)
        external
        requireFromEntryPoint
        returns (uint256 validationData)
    {
        validationData = _validateSignature(userOp, userOpHash);
        // _validateNonce()
        _payPrefund(missingAccountFunds);
    }
```
## Connecting to Other dapps
> 我们现在可以验证用户的行为，但无法和其他Dapp沟通，也就是只拿了身份证，还没完成买票或者办房产证等其他事情
![[Pasted image 20250503190519.png]]
### Execute (EXTERNAL FUNCTIONS)
```c
    function execute(address dest, uint256 value, bytes calldata functionData) 
    external 
    requireFromEntryPointOrOwner {
        (bool success, bytes memory result) = 
        dest.call{value: value}(functionData);
        
        if (!success) {
            revert MinimalAccount__CallFailed(result);
        }
    }


	 modifier requireFromEntryPointOrOwner() {
        if (msg.sender != address(i_entryPoint) && msg.sender != owner()) {
            revert MinimalAccount__NotFromEntryPointOrOwner();
        }
        _;
    }
```
### Accept Payment(modifier constructor)
```c
constructor(address entryPoint) Ownable(msg.sender) {
        i_entryPoint = IEntryPoint(entryPoint);
    }

    receive() external payable {}
```
## Deploy
```c
// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Script} from "forge-std/Script.sol";
import {MinimalAccount} from "src/ethereum/MinimalAccount.sol";
import {HelperConfig} from "script/HelperConfig.s.sol";

contract DeployMinimal is Script {
    function run() public {
        deployMinimalAccount();
    }

    function deployMinimalAccount() 
    public returns (HelperConfig, MinimalAccount) {
        HelperConfig helperConfig = new HelperConfig();
        HelperConfig.NetworkConfig memory config = helperConfig.getConfig();

        vm.startBroadcast(config.account);
        MinimalAccount minimalAccount = new MinimalAccount(config.entryPoint);
        minimalAccount.transferOwnership(config.account);
        vm.stopBroadcast();
        return (helperConfig, minimalAccount);
    }
}
```
### helperconfig
```c
// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Script, console2} from "forge-std/Script.sol";
import {EntryPoint} from "lib/account-abstraction/contracts/core/EntryPoint.sol";
import {ERC20Mock} from "@openzeppelin/contracts/mocks/token/ERC20Mock.sol";

contract HelperConfig is Script {

    error HelperConfig__InvalidChainId();

    struct NetworkConfig {
        address entryPoint;
        address usdc;
        address account;
    }

    uint256 constant ETH_MAINNET_CHAIN_ID = 1;
    uint256 constant ETH_SEPOLIA_CHAIN_ID = 11155111;
    uint256 constant ZKSYNC_SEPOLIA_CHAIN_ID = 300;
    uint256 constant LOCAL_CHAIN_ID = 31337;
    // Update the BURNER_WALLET to your burner wallet!(metamask)
    address constant BURNER_WALLET = 0x643315C9Be056cDEA171F4e7b2222a4ddaB9F88D;
    uint256 constant ARBITRUM_MAINNET_CHAIN_ID = 42_161;
    uint256 constant ZKSYNC_MAINNET_CHAIN_ID = 324;
    // address constant FOUNDRY_DEFAULT_WALLET = 0x1804c8AB1F12E6bbf3894d4083f33e07309d1f38;
    address constant ANVIL_DEFAULT_ACCOUNT = 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266;

    NetworkConfig public localNetworkConfig;
    mapping(uint256 chainId => NetworkConfig) public networkConfigs;

    /*//////////////////////////////////////////////////////////////
                               FUNCTIONS
    //////////////////////////////////////////////////////////////*/
    constructor() {
        networkConfigs[ETH_SEPOLIA_CHAIN_ID] = getEthSepoliaConfig();
        networkConfigs[ETH_MAINNET_CHAIN_ID] = getEthMainnetConfig();
        networkConfigs[ZKSYNC_MAINNET_CHAIN_ID] = getZkSyncConfig();
        networkConfigs[ARBITRUM_MAINNET_CHAIN_ID] = getArbMainnetConfig();
    }

    function getConfig() public returns (NetworkConfig memory) {
        return getConfigByChainId(block.chainid);
    }

    function getConfigByChainId(uint256 chainId) public returns (NetworkConfig memory) {
        if (chainId == LOCAL_CHAIN_ID) {
            return getOrCreateAnvilEthConfig();
        } else if (networkConfigs[chainId].account != address(0)) {
            return networkConfigs[chainId];
        } else {
            revert HelperConfig__InvalidChainId();
        }
    }

    /*//////////////////////////////////////////////////////////////
                                CONFIGS
    //////////////////////////////////////////////////////////////*/
    function getEthMainnetConfig() public pure returns (NetworkConfig memory) {
        // This is v7
        return NetworkConfig({
            entryPoint: 0x0000000071727De22E5E9d8BAf0edAc6f37da032,
            usdc: 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48,
            account: BURNER_WALLET
        });
        
    }

    function getEthSepoliaConfig() public pure returns (NetworkConfig memory) {
        return NetworkConfig({
            entryPoint: 0x5FF137D4b0FDCD49DcA30c7CF57E578a026d2789,
            usdc:  //Update with your own mock token,
            account: BURNER_WALLET
        });
    }

    function getArbMainnetConfig() public pure returns (NetworkConfig memory) {
        return NetworkConfig({
            entryPoint: 0x0000000071727De22E5E9d8BAf0edAc6f37da032,
            usdc: 0xaf88d065e77c8cC2239327C5EDb3A432268e5831,
            account: BURNER_WALLET
        });
    }

    function getZkSyncSepoliaConfig() public pure returns (NetworkConfig memory) {
        return NetworkConfig({
            entryPoint: address(0), 
            usdc: 0x5A7d6b2F92C77FAD6CCaBd7EE0624E64907Eaf3E,
            account: BURNER_WALLET
        });
    }

    function getZkSyncConfig() public pure returns (NetworkConfig memory) {
        return NetworkConfig({
            entryPoint: address(0),
            usdc: 0x1d17CBcF0D6D143135aE902365D2E5e2A16538D4,
            account: BURNER_WALLET
        });
    }

    function getOrCreateAnvilEthConfig() public returns (NetworkConfig memory) {
        if (localNetworkConfig.account != address(0)) {
            return localNetworkConfig;
        }

        // deploy mocks
        console2.log("Deploying mocks...");
        vm.startBroadcast(ANVIL_DEFAULT_ACCOUNT);
        EntryPoint entryPoint = new EntryPoint();
        ERC20Mock erc20Mock = new ERC20Mock();
        vm.stopBroadcast();
        console2.log("Mocks deployed!");

        localNetworkConfig =
            NetworkConfig({
            entryPoint: address(entryPoint), 
            usdc: address(erc20Mock), 
            account: ANVIL_DEFAULT_ACCOUNT
            });
        return localNetworkConfig;
    }
}
```
```ad-tip
**Entrypoint**
ETH 
`https://blockscan.com/address/0x0000000071727De22E5E9d8BAf0edAc6f37da032`
ETH Sepolia
`https://sepolia.etherscan.io/address/0x5ff137d4b0fdcd49dca30c7cf57e578a026d2789`
```
```ad-important
简而言之，**usdc 是用来验证 MinimalAccount 合约是否能够成功调用其他合约函数的测试工具合约（mock 合约）**
ETH
`https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`

```
## Test
### SendPackedUserOp
```c
// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Script} from "forge-std/Script.sol";
import {PackedUserOperation} from "lib/account-abstraction/contracts/interfaces/PackedUserOperation.sol";

contract SendPackedUserOp is Script {
    function run() public {}

    function generateSignedUserOperation(bytes memory callData)
    public view returns 
    (PackedUserOperation memory) {
        // Step 1. Generate the unsigned data
        uint256 nonce = vm.getNonce(sender);
        PackedUserOperation memory unsignedUserOp = 
        _generateUnsignedUserOperation(callData, sender, nonce);
        // Step 2. Sign and return it
    }
}
```
#### Step 1. Generate the unsigned data
```c
function _generateUnsignedUserOperation(bytes memory callData)
    internal pure returns (PackedUserOperation memory) {

    uint128 verificationGasLimit = 16777216;
    uint128 callGasLimit = verificationGasLimit;
    uint128 maxPriorityFeePerGas = 256;
    uint128 maxFeePerGas = maxPriorityFeePerGas;

        return PackedUserOperation({
        sender: sender,
        nonce: nonce,
        initCode: hex"",
        callData: callData,
        accountGasLimits: bytes32(uint256(verificationGasLimit) << 128 | callGasLimit),
        preVerificationGas: verificationGasLimit,
        gasFees: bytes32(uint256(maxPriorityFeePerGas) << 128 | maxFeePerGas),
        paymasterAndData: hex"",
        signature: hex""
    });
}
```
####  Step 2. Sign and return it
```c
function generateSignedUserOperation
//add NetworkConfig where has EntryPoint
(bytes memory callData, HelperConfig.NetworkConfig)
    public view returns (PackedUserOperation memory) {
    // Step 1. Generate the unsigned data
    //modifier sender to actual config.account
    uint256 nonce = vm.getNonce(config.account);
    PackedUserOperation memory unsignedUserOp = 
    _generateUnsignedUserOperation(callData, config.account, nonce);
}
```
##### getMessageHash
```c
import {IEntryPoint} from "lib/account-abstraction/contracts/interfaces/IEntryPoint.sol";
import {MessageHashUtils} from "@openzeppelin/contracts/utils/cryptography/MessageHashUtils.sol";

contract SendPackedUserOp is Script {
 using MessageHashUtils for bytes32;
    function run() public {}
	//......
	// Step 2. Sign and return it
    bytes32 userOpHash = IEntryPoint(config.entryPoint).getUserOpHash(userOp);
    bytes32 digest = userOpHash.toEthSignedMessageHash();
    (uint8 v, bytes32 r, bytes32 s) = vm.sign(config.account, digest);
	userOp.signature = abi.encodePacked(r, s, v); // Note the order
	return userOp;
```
```ad-important
`vm.sign(config.account, digest)` must be sure you enbale `--account`
or `vm.sign(your_private_key, digest)`
但是在 anvil config.account 不会让foundry自动寻找private key
```

###  1. `testOwnerCanExecuteCommands`
#### 🎯 测试目标
验证 **MinimalAccount 拥有者可以调用 `execute()` 方法** 并成功执行目标合约函数。
#### 🧩 测试逻辑
1. 合约初始无 USDC 余额。
2. 构造一个 `mint(minimalAccount, AMOUNT)` 的函数调用数据。
3. 用 `vm.prank(minimalAccount.owner())` 模拟拥有者身份。
4. 调用 `minimalAccount.execute(...)`。
5. 验证 MinimalAccount 的 USDC 余额是否变为 `AMOUNT`。
#### ✅ 预期结果
- 成功执行 `mint`。
- MinimalAccount 中的 USDC 余额 = 1e18。

###  2. `testNonOwnerCannotExecuteCommands`
#### 🎯 测试目标：
验证 **非 EntryPoint 和非拥有者的地址不能调用 `execute()` 方法**，合约应回退。
#### 🧩 测试逻辑：
1. 构造相同的 `mint(...)` 函数调用。
2. 使用非拥有者的 `randomuser` 调用 `minimalAccount.execute(...)`。 
3. 使用 `expectRevert` 预期抛出 `MinimalAccount__NotFromEntryPointOrOwner` 错误。
#### ✅ 预期结果：
- revert 成功，测试通过。
- 非授权地址无法执行任意命令。

###  3. `testRecoverSignedOp`
#### 🎯 测试目标：
验证通过签名的 `UserOperation`，能成功 **恢复出 MinimalAccount 拥有者的地址**。
#### 🧩 测试逻辑：
1. 构造一个 mint 操作。
2. 打包为 `execute(...)` 的 callData。
3. 调用 `generateSignedUserOperation(...)` 获取签名后的 UserOp。
4. 使用 EntryPoint 的 `getUserOpHash()` 得到操作哈希。    
5. 用 `ECDSA.recover()` 从签名中恢复 signer。  
6. 检查 signer 是否等于 `minimalAccount.owner()`。
#### ✅ 预期结果：
- 签名可验证。
- 恢复出的地址 = MinimalAccount 拥有者

###  4. `testValidationOfUserOps`
#### 🎯 测试目标：
验证 `MinimalAccount.validateUserOp()` 的返回值正确，表明签名有效、资金检查通过。
#### 🧩 测试逻辑：
1. 构造一个打包的 `UserOperation`，包含 mint 调用。  
2. 获取其 userOpHash。
3. 使用 `EntryPoint` 地址模拟调用者身份（`vm.prank(entryPoint)`）。    
4. 传入 `missingAccountFunds = 1e18`。    
5. 调用 `validateUserOp(...)`。   
6. 检查返回的 `validationData == 0`。
#### ✅ 预期结果：
- 验证通过，返回值为 0。

### 5. `testEntryPointCanExecuteCommands`
#### 🎯 测试目标：
验证 `EntryPoint.handleOps()` 可以成功 **调用 MinimalAccount 的 execute() 方法** 执行 mint 操作。
#### 🧩 测试逻辑：
1. 构造包含 mint 调用的打包 UserOperation。    
2. 给 MinimalAccount 一定的 ETH（满足账户资金需求）。 
3. 构造 ops 数组并放入 UserOperation。  
4. 用 `randomuser` 发起 `handleOps()`（模拟 bundler）。
5. 执行后检查 MinimalAccount 中 USDC 余额是否为 `AMOUNT`。
#### ✅ 预期结果：
- `handleOps()` 执行成功。
- MinimalAccount 被 mint 到 USDC。

# ZKSync Account Abstraction
![[Pasted image 20250503205758.png]]
## ZK Minimal Account
- `validateTransaction`
- `executeTransaction`
- `executeTransactionFromOutside`
- `prepareForPaymaster`

```c
// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {IAccount} from "lib/foundry-era-contracts/src/system-contracts/contracts/interfaces/IAccount.sol";
import {Transaction} from "lib/foundry-era-contracts/src/system-contracts/contracts/libraries/MemoryTransactionHelper.sol";

contract ZkMinimalAccount is IAccount {

	constructor() Ownable(msg.sender) {}
	
    function validateTransaction
    (bytes32 _txHash,
     bytes32 _suggestedSignedHash, 
     Transaction calldata _transaction)
        external
        payable
        returns (bytes4 magic)
    {}

    function executeTransaction
    (bytes32 _txHash, 
    bytes32 _suggestedSignedHash, 
    Transaction calldata _transaction)
        external
        payable
    {}

    function executeTransactionFromOutside
    (Transaction calldata _transaction) external payable;

    function payForTransaction
    (bytes32 _txHash,
	bytes32 _suggestedSignedHash, 
	Transaction calldata _transaction)
        external
        payable
    {}

    function prepareForPaymaster
    (bytes32 _txHash, 
    bytes32 _possibleSignedHash, 
    Transaction calldata _transaction)
        external
        payable
    {}
}
```
## System Contract
### 什么是系统合约？

**系统合约**是区块链平台中的特殊合约，它们通常由平台自身管理和维护，不像普通合约那样由用户创建和控制。这些合约通常具备管理和操作其他合约、存储平台状态等关键功能，是区块链平台运行和功能扩展的核心组成部分。

在 **ZKsync** 中，系统合约发挥着重要作用，帮助实现账户抽象、交易验证和智能合约部署等功能。

### ZKsync 系统合约的核心功能：

1. **智能合约的部署**：  
    系统合约像 **ContractDeployer** 就负责在 ZKsync 上部署其他智能合约。它提供了一个接口，使得用户可以通过调用该合约的特定函数来部署新的智能合约，而不是直接将合约代码发送到网络。
2. **生成已部署合约的地址**：  
    系统合约负责跟踪和生成新部署智能合约的地址，确保在平台内合约的唯一性和可追踪性。
3. **增加部署随机数**：  
    部署新合约时，系统合约负责维护一个随机数，确保每次合约部署的唯一性，并避免重复部署。
4. **防止构造函数被调用多次**：  
    在智能合约的生命周期中，系统合约会确保每个合约的构造函数只会被调用一次，避免潜在的重入攻击或合约状态混乱。

### ZKsync 与 Ethereum 部署合约的不同点：

- **Ethereum**：部署智能合约时，用户只需将编译后的合约代码打包到一个交易中，并通过发送交易来部署合约。
    
- **ZKsync**：与之不同，ZKsync 需要用户调用一个系统合约（如 [ContractDeploye](https://sepolia.explorer.zksync.io/address/0x0000000000000000000000000000000000008006)）上的特定函数来创建一个新的智能合约。这个过程中，平台会处理合约部署相关的更多细节，比如生成合约地址和管理部署的随机数。
## Tx 113
### **具体流程：从 MetaMask 发起交易到 ZKsync**
1. **MetaMask 发起交易**
    - 用户通过 **MetaMask** 插件在前端应用程序中发起一笔交易。例如，用户选择发送一些 **ETH** 或其他代币，或者调用某个智能合约的函数。
    - 用户填写交易细节，指定目标地址、金额等，并确认交易。此时，MetaMask 会生成交易的 **nonce**。MetaMask 会从用户本地的账户信息中读取当前的 nonce 值（表示用户已发送的交易数）。
2. **交易数据打包**
    - MetaMask 会将交易的详细信息打包成一个交易对象，包括：        
        - `to`: 目标地址        
        - `from`: 用户的账户地址        
        - `value`: 交易金额        
        - `nonce`: 当前账户的 nonce 值（确保交易的唯一性）        
        - `data`: 如果是合约调用，包含调用数据          
    - 此时，MetaMask 会使用用户的私钥签名这笔交易，确保交易的合法性。        
3. **发送交易到 ZKsync 网络**
    - 一旦交易在 MetaMask 中签名，它会被发送到 **ZKsync API 客户端**，这个客户端充当“轻节点”的角色，负责与 ZKsync 主网交互。
    - ZKsync 会收到这个交易并开始处理。
        
### **ZKsync 交易生命周期**

#### **阶段 1：验证**

1. **交易到达 ZKsync API 客户端**
    
    - ZKsync API 客户端接收到交易后，开始处理。首先，它会从交易中提取 nonce 和其他参数，并与 **`NonceHolder.sol`** 系统合约交互，确保交易中的 nonce 是唯一的。
        
2. **检查 nonce 的唯一性**
    
    - `NonceHolder.sol` 合约会查询当前用户的账户，验证其上次使用的 nonce 是否与这次交易的 nonce 相匹配。如果不匹配，说明该交易的 nonce 不合法，交易将被拒绝。
        
    - 如果交易中的 nonce 是合法且唯一的，系统会继续执行验证。
        
3. **验证交易并更新 nonce**
    
    - 接着，ZKsync 会调用 **`validateTransaction`** 函数，开始验证交易的有效性。此时，`validateTransaction` 会更新该账户的 nonce 值，防止下一次交易重复使用这个 nonce。
        
    - 在此过程中，ZKsync API 客户端检查 nonce 是否被正确更新。如果没有更新，交易将失败；如果更新成功，交易会继续进入支付阶段。
        
4. **支付交易费用**
    
    - 如果交易需要支付费用，ZKsync 会调用 **`payForTransaction`** 或者 **`prepareForPaymaster`** 函数，来确保交易的费用已经支付。这通常涉及到 ZKsync 网络的 **bootloader** 合约，确保所有费用都已支付，交易可以继续处理。
        

#### **阶段 2：执行**

5. **传递交易到主节点**
    
    - 一旦交易通过了验证阶段，它会被传递到 ZKsync 的主节点，或者是当前作为主节点和排序器合并的节点。
        
    - 主节点会执行交易的真正操作，比如执行智能合约、转账代币等。执行的函数是 **`executeTransaction`**。
        
6. **执行交易**
    
    - **`executeTransaction`** 会根据交易的类型进行相应的操作，比如转账代币，或者执行合约调用。如果交易涉及到 **Paymaster**（支付代理人），ZKsync 会在交易执行完毕后调用 **`postTransaction`**。
        
7. **交易成功**
    
    - 一旦交易在主节点上成功执行，交易就被正式确认并添加到 ZKsync 区块链中。此时，交易结果会返回给 MetaMask，MetaMask 会显示交易成功。
        

```ad-info
在 ZKsync 中，**nonce** 的作用与传统区块链（如以太坊）中的 **nonce** 类似，它是用来标识每笔交易的唯一性以及防止重放攻击的重要机制。对于 ZKsync 的交易生命周期来说，**nonce 更新的原因**和工作原理与以太坊有一些相似之处，但又有特定的设计和优化。

### 为什么在 ZKsync 中进行交易时要更新 nonce？

ZKsync 的账户抽象（Account Abstraction）模型使得交易的验证和执行流程更加灵活。在 ZKsync 中，当交易进入网络时，需要验证其有效性，这就是需要更新 nonce 的原因：

1. **非对称交易流程**：
    
    - 在传统的区块链中，如以太坊，交易的 nonce 由账户的内部状态直接控制，每次交易执行时都会被自动增加。
        
    - 在 ZKsync 中，由于采用了账户抽象机制，交易的验证流程可能由多个系统合约进行交互。**`validateTransaction`** 是一个关键函数，用于验证交易，并确保其合法性，包括检查 nonce 的唯一性。
        
2. **`NonceHolder` 系统合约的作用**：
    
    - 在 ZKsync 中，**`NonceHolder.sol`** 系统合约负责维护账户的 nonce。交易开始时，ZKsync API 客户端会通过查询 `NonceHolder` 合约，确保交易的 nonce 是唯一的。这就要求在交易验证阶段，系统必须**更新 nonce**，以确保后续交易的顺序和唯一性。
        
    - 在 `validateTransaction` 被调用后，`NonceHolder` 合约会更新该账户的 nonce 值。这是为了避免不同交易重复使用相同的 nonce。
        

### 交易前为什么需要 nonce？

在 ZKsync 中，**nonce 在交易开始时就已经存在**，并且需要验证。这个设计是为了保证交易的唯一性和顺序性。每笔交易都必须包含一个 nonce（表示账户已提交的交易数），并且该 nonce 会在验证时被检查是否被使用过。

- **交易的验证阶段**：ZKsync 的 API 客户端会检查账户的当前 nonce 是否与交易中的 nonce 匹配。如果 nonce 没有更新，表示这个交易的 nonce 已经被使用过，那么交易就会失败。
    
- **nonce 必须唯一**：一旦交易验证通过，ZKsync 会更新该账户的 nonce 值，以确保后续交易的 nonce 不会重复使用。
    

### ZKsync 是否需要矿工计算两次 nonce？

- **不需要**。在 ZKsync 的架构中，nonce 的计算和更新是在交易验证的阶段完成的，并且是由 ZKsync 的系统合约（如 `NonceHolder.sol`）处理的。在发送交易时，用户的客户端会检查 nonce 的唯一性，然后进行交易验证和执行。矿工的工作更多的是对已验证的交易进行执行，并将其包含在区块中，确保交易按顺序完成。
    
```
```ad-important


### **比特币中的 Nonce**

在比特币中，**nonce** 是由矿工计算的，并且它是一个不同的概念，主要用于**工作量证明（Proof of Work, PoW）**的过程。

1. **工作量证明**：比特币网络通过矿工使用 **nonce** 来进行哈希计算。矿工尝试找到一个适合的 **nonce** 值，使得交易区块的哈希值满足网络设定的难度要求（即哈希值的前几位是零）。这是一个与 **交易顺序** 或 **账户** 直接无关的过程。
    
2. **区块的 Nonce**：在比特币中，每个区块都包含一个 **nonce**，这个 **nonce** 是矿工通过不断修改并计算区块哈希值的过程中的一个值。矿工在找出合适的 nonce 后，才会发布一个新区块。
    
3. **交易的 Nonce（序列号）**：在比特币中，**交易的 nonce** 实际上被称为 **输入的序列号（sequence number）**。这个序列号是与交易的输入相关的，它被用于标识交易输入的顺序，防止交易重放。
    

#### 比特币中的 nonce 总结：

- **矿工计算**：矿工通过调整区块的 nonce 值来进行工作量证明，找到合适的哈希值。
    
- **交易序列号**：每个比特币交易的输入都有一个序列号，用于防止交易重放。
    

### **以太坊中的 Nonce**

在以太坊中，**nonce** 的概念更接近 **账户的交易计数器**。它与账户有关，确保每个账户的交易按顺序执行，防止重复交易。

1. **账户 Nonce**：以太坊中的 nonce 是每个账户的交易计数器。每次从一个账户发起交易时，nonce 就会递增。这个 nonce 作为交易的一部分被包含在交易数据中，确保交易的唯一性和顺序性。
    
2. **交易处理**：每个以太坊账户都维护一个独立的 nonce，网络在验证交易时会检查交易的 nonce 是否与账户的当前计数匹配。只有当交易的 nonce 与账户的当前 nonce 匹配时，交易才会被认为是有效的并被处理。
    
3. **防止重放攻击**：通过为每个账户分配递增的 nonce，网络可以防止同一交易被重复广播和执行（重放攻击）。
    

#### 以太坊中的 nonce 总结：

- **账户交易计数器**：nonce 用来跟踪账户已发出的交易数量，确保交易顺序正确。
    
- **防止重放攻击**：通过每次递增 nonce，保证每个账户的交易唯一且顺序正确。
    

### **ZKsync 中的 Nonce**

在 **ZKsync** 中，**nonce** 也是与账户相关联的，用来确保每个账户的交易顺序唯一。ZKsync 继承了以太坊的概念，并增加了它的一些特性。具体来说，ZKsync 的 **nonce** 是通过 **`NonceHolder.sol`** 系统合约来管理的。

1. **ZKsync API 客户端** 会首先查询 **`NonceHolder`** 合约来获取当前账户的 nonce。然后，交易的 nonce 会与账户的 nonce 对比，确保没有重复的交易。
    
2. 交易验证过程包括 **nonce 更新**，这确保了每次交易都使用一个唯一的 nonce，防止重放攻击。

```
```ad-note
### **重点合约：`NonceHolder` 合约**

在验证阶段的第 2 步中，`NonceHolder` 合约发挥着重要作用。它用于跟踪和管理所有交易的 nonce，确保每个交易的 nonce 是唯一的，从而避免交易被重放。通过查询 `NonceHolder` 合约，ZKsync 可以确定交易的有效性。
### **引导加载程序（Bootloader）的作用**

在验证阶段，`validateTransaction` 被调用时，`msg.sender` 始终是 **引导加载程序**（bootloader）系统合约。引导加载程序是 ZKsync 系统中的超级管理员，负责验证和执行交易、更新 nonce、支付交易费用等操作。它的作用类似于以太坊中的 **EntryPoint**。

<font color="#ff0000">这样使验证过程以Bootloader 合约运行，而不是随便的其他人</font>
```
## validateTransaction
### imports
```c

// zkSync Era Imports
import {
    IAccount,
    ACCOUNT_VALIDATION_SUCCESS_MAGIC
} from "lib/foundry-era-contracts/src/system-contracts/contracts/interfaces/IAccount.sol";
import {
    Transaction,
    MemoryTransactionHelper
} from "lib/foundry-era-contracts/src/system-contracts/contracts/libraries/MemoryTransactionHelper.sol";
import {SystemContractsCaller} from
    "lib/foundry-era-contracts/src/system-contracts/contracts/libraries/SystemContractsCaller.sol";
import {
    NONCE_HOLDER_SYSTEM_CONTRACT,
    BOOTLOADER_FORMAL_ADDRESS,
    DEPLOYER_SYSTEM_CONTRACT
} from "lib/foundry-era-contracts/src/system-contracts/contracts/Constants.sol";
import {INonceHolder} from "lib/foundry-era-contracts/src/system-contracts/contracts/interfaces/INonceHolder.sol";
import {Utils} from "lib/foundry-era-contracts/src/system-contracts/contracts/libraries/Utils.sol";

// OZ Imports
import {MessageHashUtils} from "@openzeppelin/contracts/utils/cryptography/MessageHashUtils.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

```
```c
     */
    function validateTransaction(bytes32, /*_txHash*/ bytes32, 
    /*_suggestedSignedHash*/ Transaction memory _transaction)
        external
        payable
        requireFromBootLoader
        returns (bytes4 magic)
    {
        return _validateTransaction(_transaction);
    }
```
### Call nonceholder 
```c
//_validateTransaction
 SystemContractsCaller.systemCallWithPropagatedRevert(
            uint32(gasleft()),
            address(NONCE_HOLDER_SYSTEM_CONTRACT),
            0,
            abi.encodeCall(INonceHolder.incrementMinNonceIfEquals, 
            (_transaction.nonce))
        );
```
###  Check for fee to pay
```c
//_validateTransaction
        uint256 totalRequiredBalance = _transaction.totalRequiredBalance();
        if (totalRequiredBalance > address(this).balance) {
            revert ZkMinimalAccount__NotEnoughBalance();
        }
```
### Check the Signature
```c
//_validateTransaction
	bytes32 txHash = _transaction.encodeHash();
	bytes32 convertedHash = MessageHashUtils.toEthSignedMessageHash(txHash);
    address signer = ECDSA.recover(txHash, _transaction.signature);
    bool isValidSigner = signer == owner();
    if (isValidSigner) {
        magic = ACCOUNT_VALIDATION_SUCCESS_MAGIC;
    } else {
        magic = bytes4(0);
    }
    return magic;
```
```ad-tip
use systemcall you must 
1. install 
`foundry install Cyfrin/foundry-era-contracts --no-commit`
2. set this in foundry.toml
`is-system = true`
3.  import systemcall
`import {SystemContractsCaller} from
    "lib/foundry-era-contracts/src/system-contracts/contracts/libraries/SystemContractsCaller.sol";`
```
### modifier
```c
    modifier requireFromBootLoader() {
        if (msg.sender != BOOTLOADER_FORMAL_ADDRESS) {
            revert ZkMinimalAccount__NotFromBootLoader();
        }
        _;
    }

    modifier requireFromBootLoaderOrOwner() {
        if (msg.sender != BOOTLOADER_FORMAL_ADDRESS && msg.sender != owner()) {
            revert ZkMinimalAccount__NotFromBootLoaderOrOwner();
        }
        _;
    }
```
## executeTransaction
```c

    function executeTransaction(bytes32, /*_txHash*/ bytes32, 
    /*_suggestedSignedHash*/ Transaction memory _transaction)
        external
        payable
        requireFromBootLoaderOrOwner
    {
        _executeTransaction(_transaction);
    }
```
### base Var
```c
 function _executeTransaction(Transaction memory _transaction) internal {
        address to = address(uint160(_transaction.to));
        uint128 value = Utils.safeCastToU128(_transaction.value);
        bytes memory data = _transaction.data;
}
```
```ad-note

🔹 `address to = address(uint160(_transaction.to));`

- `to` 在 `Transaction` 结构体中是 `uint256` 类型，通常是为了 ABI 编码/哈希统一性。
    
- 但是 Solidity 要调用某个合约地址，必须是 `address` 类型。
    
- 所以这里进行两步转换：
    
    1. `uint160(_transaction.to)`：截取 `uint256` 的低 160 位（也就是一个地址大小）。    
    2. `address(...)`：转换成实际的 Solidity 地址类型。    

✅ **目的**：得到一个能用于调用的实际地址。

🔹 `uint128 value = Utils.safeCastToU128(_transaction.value);`

- `Transaction.value` 是 `uint256`，但系统调用（systemCall）要求 `value` 是 `uint128`。
- 所以这里用 `safeCastToU128()` 函数做安全类型转换，确保：    
    - 不能无声截断数值      
    - 超过 `uint128` 范围就 revert，防止意外损失资金     

✅ **目的**：确保发送 ETH 的金额在系统允许的范围内，且兼容系统合约的参数类型。

---
🔹 `bytes memory data = _transaction.data;`

- `data` 是这笔交易要调用的 calldata（函数选择器 + 参数）。
    
- 它是 `bytes` 类型，直接赋值到 memory 中方便后续用 `call` 调用。
    
✅ **目的**：准备合约调用的数据载荷。
```
### Execute
```c
// _executeTransaction
 if (to == address(DEPLOYER_SYSTEM_CONTRACT))
{
    uint32 gas = Utils.safeCastToU32(gasleft());
    SystemContractsCaller.systemCallWithPropagatedRevert(gas, to, value, data);
} 
else {
    bool success;
    assembly {
        success := call(gas(), to, value, add(data, 0x20), mload(data), 0, 0)
             }
    if (!success) {
            revert ZkMinimalAccount__ExecutionFailed();
				  }
    }   
```
```ad-note
### ✅ **问题 ：assembly 中的 `call` 操作是做什么的？**
`assembly {     success := call(gas(), to, value, add(data, 0x20), mload(data), 0, 0) }`

#### ✅ 解答：

这段 `assembly` 是为了**节省 gas 并直接进行底层函数调用**。它做了以下几件事：

|操作|说明|
|---|---|
|`call(...)`|执行对外部地址的低级调用|
|`gas()`|使用当前剩余的全部 gas|
|`to`|要调用的合约或地址|
|`value`|发送的 ETH 数量|
|`add(data, 0x20)`|指向 `bytes` 数据的真实内容（跳过头部）|
|`mload(data)`|读取 `bytes` 数据的长度|
|`0, 0`|不关心返回值位置与大小|

- 如果调用失败（`success == false`），就会触发 `ExecutionFailed` 的错误，回滚交易。
```
## payForTransaction
```c
    }

    function payForTransaction(bytes32, /*_txHash*/ bytes32, 
    /*_suggestedSignedHash*/ Transaction memory _transaction)
        external
        payable
    {
        bool success = _transaction.payToTheBootloader();
        if (!success) {
            revert ZkMinimalAccount__FailedToPay();
        }
    }
```
## executeTransactionFromOutside
```c
  function executeTransactionFromOutside
  (Transaction memory _transaction) external payable {
        bytes4 magic = _validateTransaction(_transaction);
        if (magic != ACCOUNT_VALIDATION_SUCCESS_MAGIC) {
            revert ZkMinimalAccount__InvalidSignature();
        }
        _executeTransaction(_transaction);
    }
```
## Test

### 🔧 准备函数：`setUp`

```c
function setUp() public {
    minimalAccount = new ZkMinimalAccount();
    minimalAccount.transferOwnership(ANVIL_DEFAULT_ACCOUNT);
    usdc = new ERC20Mock();
    vm.deal(address(minimalAccount), AMOUNT);
}
```

### ✅ 测试函数：`testZkOwnerCanExecuteCommands`

```c
    function testZkOwnerCanExecuteCommands() public {
        // Arrange
        address dest = address(usdc);
        uint256 value = 0;
        bytes memory functionData = 
        abi.encodeWithSelector(
		        ERC20Mock.mint.selector, 
		        address(minimalAccount),
		        AMOUNT);

        Transaction memory transaction =
            _createUnsignedTransaction(
	            minimalAccount.owner(), 
	            113,
	            dest,
	            value,
	            functionData);

        // Act
        vm.prank(minimalAccount.owner());
        minimalAccount.executeTransaction(
		        EMPTY_BYTES32,
			    EMPTY_BYTES32,
				transaction);

        // Assert
        assertEq(usdc.balanceOf(address(minimalAccount)), AMOUNT);
    }
```

验证**账户所有者是否可以执行一笔有效交易**。
#### 步骤说明：
1. 构造一个 `ERC20Mock.mint(...)` 的 calldata，目标是给 `minimalAccount` 自己铸造 `1e18` 代币。
2. 使用 `_createUnsignedTransaction()` 构建一个符合 ZkSync 格式的交易（txType 为 113，即用户自定义类型）。
3. 使用 `vm.prank()` 模拟所有者的调用环境。
4. 调用 `executeTransaction()` 执行这笔交易。
5. 验证 `usdc.balanceOf(address(minimalAccount)) == AMOUNT` 成功。
    

### ✅ 测试函数：`testZkValidateTransaction`

```c
    function testZkValidateTransaction() public onlyZkSync {
        // Arrange
        address dest = address(usdc);
        uint256 value = 0;
        
        bytes memory functionData = 
        abi.encodeWithSelector(
        ERC20Mock.mint.selector, 
        address(minimalAccount), 
        AMOUNT);
        
        Transaction memory transaction =
            _createUnsignedTransaction(
            minimalAccount.owner(), 
            113, 
            dest, 
            value, 
            functionData);
            
        transaction = _signTransaction(transaction);

        // Act
        vm.prank(BOOTLOADER_FORMAL_ADDRESS);
        bytes4 magic = minimalAccount.validateTransaction(
					 EMPTY_BYTES32, 
				     EMPTY_BYTES32,
			         transaction);

        // Assert
        assertEq(magic, ACCOUNT_VALIDATION_SUCCESS_MAGIC);
    }

```

验证 `ZkMinimalAccount.validateTransaction(...)` 返回是否为 ZkSync 要求的 `ACCOUNT_VALIDATION_SUCCESS_MAGIC`。

#### 步骤说明：

1. 构造交易数据与上一个函数类似。
    
2. 使用 `_signTransaction()` 对交易结构体签名。
    
    - 使用 `MemoryTransactionHelper.encodeHash()` 得到哈希。
        
    - 使用 Foundry 的 `vm.sign()` 方法用私钥签名，得到 `(r, s, v)`。
        
    - 组装签名并写入 `transaction.signature` 字段。
        
3. 模拟 `BOOTLOADER_FORMAL_ADDRESS`（ZkSync 系统合约）调用 `validateTransaction`。
    
4. 判断返回值是否为 `ACCOUNT_VALIDATION_SUCCESS_MAGIC`。
    

### 🛠 Helper 函数：`_createUnsignedTransaction(...)`
```c
    function _signTransaction(Transaction memory transaction) 
    internal view returns (Transaction memory) {
        bytes32 unsignedTransactionHash = 
        MemoryTransactionHelper.encodeHash(transaction);
        // bytes32 digest = unsignedTransactionHash.toEthSignedMessageHash();
        uint8 v;
        bytes32 r;
        bytes32 s;
        uint256 ANVIL_DEFAULT_KEY = 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80;
        (v, r, s) = vm.sign(ANVIL_DEFAULT_KEY, unsignedTransactionHash);
        Transaction memory signedTransaction = transaction;
        signedTransaction.signature = abi.encodePacked(r, s, v);
        return signedTransaction;
    }

```

### 🛠 Helper 函数：`_signTransaction(...)`
```c
  function _createUnsignedTransaction(
        address from,
        uint8 transactionType,
        address to,
        uint256 value,
        bytes memory data
    ) internal view returns (Transaction memory) {
        uint256 nonce = vm.getNonce(address(minimalAccount));
        bytes32[] memory factoryDeps = new bytes32[](0);
        return Transaction({
            txType: transactionType, // type 113 (0x71).
            from: uint256(uint160(from)),
            to: uint256(uint160(to)),
            gasLimit: 16777216,
            gasPerPubdataByteLimit: 16777216,
            maxFeePerGas: 16777216,
            maxPriorityFeePerGas: 16777216,
            paymaster: 0,
            nonce: nonce,
            value: value,
            reserved: [uint256(0), uint256(0), uint256(0), uint256(0)],
            data: data,
            signature: hex"",
            factoryDeps: factoryDeps,
            paymasterInput: hex"",
            reservedDynamic: hex""
        });
    }
}
```


DAO（去中心化自治组织）是 Decentralized Autonomous Organization 的缩写，是一种基于区块链技术的新型组织形式，其核心特点是去**中心化、自治化、透明化**。
# 图形化创建
1. login Aragon[Aragon](https://app.aragon.org/)
![[Pasted image 20250504100209.png]]

![[Pasted image 20250504100217.png]]
2. write some describetion
![[Pasted image 20250504100229.png]]
3. 定义人员资格和治理分配人员的方式 ![[Pasted image 20250504100418.png]]
4. 提案细节（谁可以投票，门槛，投票时间）
![[Pasted image 20250504100505.png]]
5. 部署配置 ![[Pasted image 20250504100531.png]]

# 一个列子 富豪统治（代币统治）
## Box
```c
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.18;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

contract Box is Ownable {
    uint256 private s_number;

    event NumberChanged(uint256 number);

    function store(uint256 newNumber) public onlyOwner {
        s_number = newNumber;
        emit NumberChanged(newNumber);
    }

    function getNumber() external view returns (uint256) {
        return s_number;
    }
}
```
## 创建治理代币
让openzeppelin帮我们创建[openzeppelin合约向导](https://wizard.openzeppelin.com/)
![[Pasted image 20250504101000.png]]
## 创建治理合约
OK openzeppelin can help us again[openzeppelin合约向导](https://wizard.openzeppelin.com/)![[Pasted image 20250504101116.png]]
##  Timelock
```c
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.18;

import {TimelockController} from "@openzeppelin/contracts/governance/TimelockController.sol";

contract Timelock is TimelockController {
    /**
     * @notice Create a new Timelock controller
     * @param minDelay Minimum delay for timelock executions
     * @param proposers List of addresses that can propose new transactions
     * @param executors List of addresses that can execute transactions
     */
    constructor(uint256 minDelay, address[] memory proposers, address[] memory executors)
        TimelockController(minDelay, proposers, executors, msg.sender)
    {}
}
```
# ​**简介**
## ​**1. 什么是弹性代币（Rebase Tokens）？**

弹性代币（又称“供应弹性代币”）是一种通过动态调整流通供应量以维持目标价格（如 1 美元）的加密货币。与传统固定供应量的代币不同，弹性代币会根据市场价格波动自动**增发**​（增加供应量）或**销毁**​（减少供应量）。

- ​**核心机制**：
    - ​**目标价格**：协议定期监测代币的市场价格。若价格高于目标，则增发代币以降低价格；若低于目标，则销毁代币以抬高价格。
    - ​**用户影响**：用户的代币余额会按比例变化，但其占总供应量的所有权比例保持不变。
    - ​**典型案例**：Ampleforth（AMPL）、Olympus DAO（OHM）、Base Protocol（BASE）。

## ​**2. 跨链功能如何实现？**

弹性代币可通过**跨链桥**​（如 Chainlink CCIP）在多个区块链网络（如 Ethereum、Base、Polygon）之间流通，从而无缝对接不同链上的去中心化应用（DApp）和流动性池。

- ​**关键技术组件**：
    - ​**跨链桥合约**：在源链锁定代币，并在目标链铸造等量的包装代币（如将 ETH 转换为 Polygon 上的 WETH）。
    - ​**销毁-铸造机制**：在源链销毁代币，同时在目标链铸造等量代币，确保总供应量一致。
# RebaseToken
## 构造函数
```c
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

contract RebaseToken is ERC20, Ownable, AccessControl {
constructor() Ownable(msg.sender) ERC20("RebaseToken", "RBT") {}
}
```
## 利息
### 设置利率
```c
 function setInterestRate(uint256 _newInterestRate) external onlyOwner {
        // Set the interest rate
        //interest rate decrease by time
        if (_newInterestRate >= s_interestRate) {
            revert RebaseToken__InterestRateCanOnlyDecrease(s_interestRate, _newInterestRate);
        }
        s_interestRate = _newInterestRate;
        emit InterestRateSet(_newInterestRate);
    }

```
### 计算利息
```c
	function balanceOf(address _user) public view override returns (uint256) {
        //current principal balance of the user
        uint256 currentPrincipalBalance = super.balanceOf(_user);
        if (currentPrincipalBalance == 0) {
            return 0;
        }
        // shares * current accumulated interest for that user since their interest was last minted to them.
        return (currentPrincipalBalance * _calculateUserAccumulatedInterestSinceLastUpdate(_user)) / PRECISION_FACTOR;
    }
//随时间利率线性变化
	function _calculateUserAccumulatedInterestSinceLastUpdate(address _user)
        internal
        view
        returns (uint256 linearInterest)
    {
        uint256 timeDifference = block.timestamp - s_userLastUpdatedTimestamp[_user];
        // represents the linear growth over time = 1 + (interest rate * time)
        linearInterest = (s_userInterestRate[_user] * timeDifference) + PRECISION_FACTOR;
    }

```
### 生成利息
```c

    function _mintAccruedInterest(address _user) internal {
        // Get the user's previous principal balance. use ERC20 func
        uint256 previousPrincipalBalance = super.balanceOf(_user);
        
        uint256 currentBalance = balanceOf(_user);
        uint256 balanceIncrease = currentBalance - previousPrincipalBalance;

        // Mint an amount of tokens equivalent to the interest accrued
        _mint(_user, balanceIncrease);
        // Update the user's last updated timestamp to reflect this most recent time their interest was minted to them.
        s_userLastUpdatedTimestamp[_user] = block.timestamp;
    }
```
## Mint
```c
  function mint(address _to, uint256 _value, uint256 _userInterestRate) public onlyRole(MINT_AND_BURN_ROLE) {
        // 先计算利息，挖利息币
        _mintAccruedInterest(_to);
        // 挖新的
        s_userInterestRate[_to] = _userInterestRate;
        _mint(_to, _value);
    }
```
## Burn
```c
 function burn(address _from, uint256 _value) public onlyRole(MINT_AND_BURN_ROLE) {
        // Mints any existing interest that has accrued since the last time the user's balance was updated.
        _mintAccruedInterest(_from);
        _burn(_from, _value);
    }
```
## Transfer
```c
function transfer(address _recipient, uint256 _amount) 
public override returns (bool) {
        // accumulates the balance of the user so it is up to date with any interest accumulated.
        if (_amount == type(uint256).max) {
            _amount = balanceOf(msg.sender);
        }
        _mintAccruedInterest(msg.sender);
        _mintAccruedInterest(_recipient);
        if (balanceOf(_recipient) == 0) {
            // Update the users interest rate only if they have not yet got one (or they tranferred/burned all their tokens). Otherwise people could force others to have lower interest.
            s_userInterestRate[_recipient] = s_userInterestRate[msg.sender];
        }
        return super.transfer(_recipient, _amount);
    }


    function transferFrom(address _sender, address _recipient, uint256 _amount) public override returns (bool) {
        if (_amount == type(uint256).max) {
            _amount = balanceOf(_sender);
        }
        // accumulates the balance of the user so it is up to date with any interest accumulated.
        _mintAccruedInterest(_sender);
        _mintAccruedInterest(_recipient);
        if (balanceOf(_recipient) == 0) {
            // Update the users interest rate only if they have not yet got one (or they tranferred/burned all their tokens). Otherwise people could force others to have lower interest.
            s_userInterestRate[_recipient] = s_userInterestRate[_sender];
        }
        return super.transferFrom(_sender, _recipient, _amount);
    }
```
```ad-note

1. **条件判断**：`if (_amount == type(uint256).max)`  
    检查 `_amount` 是否等于 `uint256` 类型的最大值（即 `2^256 - 1`，一个极大的数，通常不会在实际交易中使用）。
    
2. **自动替换逻辑**：  
    如果条件满足（即用户输入了最大值），则将 `_amount` 的值更新为调用者（`msg.sender`）当前持有的代币余额。这是通过调用 `balanceOf(msg.sender)` 实现的。
    
- **简化用户操作**：用户无需手动查询和输入精确的余额，只需传入最大值即可代表“全部转出”或“全部授权”。
    
- **常见于代币操作**：如转账（`transfer`）、授权（`approve`）等函数中，允许用户一键操作全部余额。
```
## 访问控制
### 访问控制的修饰符
```c
onlyRole(DEFAULT_ADMIN_ROLE) 
```
```c
bytes32 private constant MINT_AND_BURN_ROLE = keccak256("MINT_AND_BURN_ROLE");

```
```ad-tip
- **`_setupRole(DEFAULT_ADMIN_ROLE, msg.sender)`**  
    将 `DEFAULT_ADMIN_ROLE`（最高管理员权限）授予合约部署者，使其可以管理其他角色（如分配或撤销权限）。
    
- **`_grantRole(MINT_AND_BURN_ROLE, msg.sender)`**  
    将自定义角色 `MINT_AND_BURN_ROLE`（铸造和销毁权限）授予部署者，允许其调用代币增发或销毁函数。
```
### 管理员分配Mint和Burnquanxian
```c
function grantMintAndBurnRole(address account) 
  external 
  onlyRole(DEFAULT_ADMIN_ROLE) 
{
  _grantRole(MINT_AND_BURN_ROLE, account);
}
```
# 保险库（存抵押的ETH）
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./interfaces/IRebaseToken.sol";

contract Vault {
    IRebaseToken public immutable i_rebaseToken;

    event Deposit(address indexed user, uint256 amount);
    event Redeem(address indexed user, uint256 amount);

    error Vault__RedeemFailed();

    constructor(IRebaseToken _rebaseToken) {
        i_rebaseToken = _rebaseToken;
    }

    // allows the contract to receive rewards
    receive() external payable {}

    function deposit() external payable {
        i_rebaseToken.mint(msg.sender, msg.value, i_rebaseToken.getInterestRate());
        emit Deposit(msg.sender, msg.value);
    }

    /**
     * @dev redeems rebase token for the underlying asset
     * @param _amount the amount being redeemed
     *
     */
    function redeem(uint256 _amount) external {
        if (_amount == type(uint256).max) {
            _amount = i_rebaseToken.balanceOf(msg.sender);
        }
        i_rebaseToken.burn(msg.sender, _amount);
        // executes redeem of the underlying asset
        (bool success,) = payable(msg.sender).call{value: _amount}("");
        if (!success) {
            revert Vault__RedeemFailed();
        }
        emit Redeem(msg.sender, _amount);
    }
}
```
```ad-note
- **输入**：用户发送 ETH（通过 `msg.value`）。
    
- **操作**：调用 `RebaseToken` 的 `mint` 方法，铸造对应数量的代币给用户。
    
- **关键点**：存入的 ETH 会被保留在 `Vault` 合约中，而铸造的 `RebaseToken` 代表用户对这部分 ETH 的所有权。
```
```c
//./interfaces/IRebaseToken.sol
pragma solidity ^0.8.24;

interface IRebaseToken {
    function mint(address _to, uint256 _amount, uint256 _interestRate) external;
    function burn(address _from, uint256 _amount) external;
    function balanceOf(address _account) external view returns (uint256);
    function getUserInterestRate(address _account) external view returns (uint256);
    function getInterestRate() external view returns (uint256);
    function grantMintAndBurnRole(address _account) external;
}
```
```ad-tip
在 Solidity 中，`interface` 是一个用于**定义合约功能规范**的关键字，它类似于其他编程语言中的接口概念。以下是关于 `interface` 的详细解析：

### 核心特性

1. **纯抽象定义**
    
    - `interface` 中只能声明函数（函数签名），**不能包含函数实现**。
        
    - 无法定义状态变量、构造函数、或函数修饰器（如 `modifier`）。
        
    - 所有函数默认为 `external` 且没有实现体（无需显式写 `external`）。
        
2. **标准化交互**
    
    - 用于定义不同合约之间的交互规则（如代币标准 ERC20、ERC721 的接口）。
        
    - 其他合约通过接口调用目标合约，无需关心其内部实现。
        
3. **继承与组合**
    
    - 接口可以继承其他接口（通过 `interface IChild is IParent`）。
        
    - 一个合约可以实现多个接口。
```
# Bridge
## 关键术语：源链与目标链
- **源链（Source Chain）：** 资产转移的_起始_区块链网络。前例中以太坊L1即为源链。
- **目标链（Destination Chain）：** 资产转移的_接收_区块链网络。前例中zkSync L2即为目标链。
## 区块链桥接的工作原理：常见机制
1. **Burn-and-Mint**
    - **流程：** 转移代币时，源链上的代币被销毁，同时通过跨链消息触发在目标链铸造等量的同类型代币。
    - **核心特点：** 确保跨链代币总流通量恒定，维持代币稀缺性和经济属性。
2. **Lock-and-Unlock**
    - **流程：** 将待转移代币锁定在源链的智能合约（如资金池/保险库）中，通过跨链消息授权在目标链释放等量已存在代币。
    - **挑战：** 依赖第三方流动性提供者（LP）在目标链预备充足代币，流动性不足可能导致延迟或失败，易造成"流动性碎片化"。        
3. **Wrapped Assets**
    - **流程：** 当无法直接铸造原生代币（如转移以太坊原生USDC）时，将原始代币锁定在源链，跨链消息触发在目标链铸造_新的合成代币（包装代币）_。    
    - **示例：** 从以太坊桥接到Arbitrum/zkSync的USDC常显示为**USDC.e**，".e"后缀表示以太坊来源的包装代币。
    - **包装代币：** 本质是底层资产的**债权凭证（IOU）**，代表对源链锁定资产的所有权。        
4. **Burn-and-Unlock**
    - **流程：** 将包装代币在源链销毁，通过跨链消息确认后，在目标链（资产原始链）解锁对应的原生代币。
```ad-tip
**什么是包装代币？**

#### 1. **基本定义**

- **本质**：一种由智能合约生成的**合成资产**，代表对另一条链上原生资产的索取权。   
- **生成机制**：通过跨链桥锁定原生资产 → 在目标链铸造等量包装代币（1:1锚定）。  
- **目的**：解决区块链间资产无法直接流通的问题，实现跨链资产交互。
#### 2. **关键特征**
- **锚定价值**：与原生资产1:1挂钩（如1 WBTC = 1 BTC）    
- **可逆性**：包装代币可销毁并赎回原生资产（需通过跨链桥）。
- **链特异性**：仅在目标链有效（如Polygon上的WETH无法直接在以太坊使用）。
```
## 桥间通信
### Chainlink CCIP
![[Pasted image 20250502122614.png]]

#### 1. **启动阶段（源链）**
- **用户交互**：用户与源链上的智能合约进行交互。
- **触发交易**：该交互通过链上专用的**路由器合约（Router Contract）**触发CCIP交易。
- **数据准备**：需跨链传递的数据和/或代币在此阶段完成预处理。
#### 2. **路由与上链处理（源链）**
- **路径选择**：路由器合约识别目标链，并将指令转发至对应目标链的**上链处理合约（OnRamp）**。
- **链上绑定**：每个目标链拥有独立的OnRamp合约负责后续操作。
#### 3. **代币处理（源链）**
- **代币操作**：若涉及代币转移，OnRamp合约将与**代币池合约（Token Pool）**交互。
- **机制选择**：根据预设的转移模式（如"锁定/释放"或"销毁/铸造"）执行操作：
    - **锁定模式**：代币被存入源链代币池锁定。  
    - **销毁模式**：代币在源链被销毁。
#### 4. **链下网络处理**
交易细节（含消息与代币操作）由Chainlink去中心化预言机网络（DON）处理，包含三个独立组件：
##### a) **提交DON（Committing DON）**
- **职责**：去中心化预言机节点网络负责：
    - 监控源链事件        
    - 确认交易最终细节
    - 提交交易数据（通常以Merkle根形式存储）
##### b) **执行DON（Executing DON）**
- **职责**：另一组去中心化预言机节点网络负责：
    - 携带提交DON的签名        
    - 将交易提交至目标链执行        
##### c) **风险管理网络（RMN）**
- **独立性**：完全独立的节点网络
- **功能**：作为二级验证层持续监控跨链活动，识别异常行为
#### 5. **下链处理与代币操作（目标链）**
- **交易验证**：执行DON将已验证的交易包发送至目标链的**下链处理合约（OffRamp）**。
- **代币释放**：  
    - **锁定模式**：目标链代币池解锁等量代币        
    - **铸造模式**：在目标链铸造新代币
#### 6. **最终交付（目标链）**
- **路由传递**：OffRamp合约将消息和/或代币转交给目标链的**路由器合约**。
- **接收处理**：路由器将负载交付至指定**接收方（Receiver）**，可以是：
    - 目标链智能合约  
    - 外部账户（EOA，即用户钱包）
### CCIP 实际执行过程
#### 1. 源链部署(ETH Sepolia)
```ad-note
CCIP 文档的各种链信息的目录[CCIP Dir](https://docs.chain.link/ccip/directory/mainnet)
```
数据准备：
- 路由地址 
- Link Token![[Pasted image 20250502123741.png]]
#### 2.源链允许目标链
- 源链到目标链的chainselector
- True
![[Pasted image 20250502124335.png]]
#### 3. 目标链部署(Arbitrum Sepolia)
数据准备：
- 路由地址 
- Link Token
#### 4.目标链允许源链
allowlistSourceChain
- 查找Sepolia网络的`chainSelector`（目标到源）
- True
allowlistSender
- Sepolia address 刚刚我们部署在源链的合约地址
- True
#### 5. 从 Sepolia 发送消息
- 调用 `sendMessagePayLINK` 函数（如果你配置的是用原生代币支付费用，则调用 `sendMessagePayNative`）。
- 输入 Arbitrum Sepolia 的 `_destinationChainSelector`。
- 输入你部署在 **Arbitrum** 上的 `Messenger` 合约地址作为 `_receiver`。
- 输入字符串 `"Hey Arbitrum"` 作为 `_text` 参数。 
- 在 MetaMask 中确认交易，并记录交易哈希（Transaction Hash）。
#### 6. 追踪与验证
- 打开 CCIP Explorer（网址：[https://ccip.chain.link/explorer](https://ccip.chain.link/explorer)）。
- 将你在 Sepolia 发出 `sendMessagePayLINK` 调用时产生的交易哈希粘贴到搜索栏中。
- 观察状态更新。它将经历多个阶段，如“等待最终确定（Waiting for finality）”、“源已确定（Source Finalized）”、“已提交（Committed）”，最终变为“成功（Success）”，表示消息已在 Arbitrum Sepolia 成功接收。
- 记录显示的唯一 CCIP 消息 ID（Message ID）。
### CCT （CCIP Standard）
#### CCT 标准架构组件
1. **Token 合约：**  
    这是表示代币本身的核心合约，通常遵循 ERC20 或兼容的标准（如 ERC677）。已有的 ERC20 代币通常可以通过扩展或包装来支持 CCT 功能。  
2. **Token Pool 合约：**  
    在每个需要跨链功能的链上部署。此合约与主 Token 合约关联，负责跨链逻辑（在源链上锁定或销毁，在目标链上解锁或铸造）。  
    开发者需要继承 Chainlink 提供的基础 `TokenPool.sol` 合约。Chainlink 提供了标准实现，如 `BurnMintTokenPool.sol` 和 `LockReleaseTokenPool.sol`，以支持常见的使用场景。
3. **TokenAdminRegistry：**  
    这是 Chainlink 提供并在每条链上部署的合约。该合约是一个注册表，用于将代币地址映射到其授权管理员（通常是代币所有者或指定的管理合约）。  
    CCIP 使用此注册表来验证谁有权管理特定代币的 CCIP 设置（例如 Token Pool 地址、速率限制等）。
4. **CCIP Router：**  
    每条链上的核心 Chainlink 合约，应用程序通过它调用 `ccipSend` 函数来发起跨链消息或代币转移。Token Pool 合约在底层会与 Router 合约交互。
    以下是《实施 CCT 标准：开发者概览》的中文翻译：
#### 实施 CCT 标准：开发者概览
1. **环境准备与配置：**
 - 搭建开发环境（如 Foundry、Hardhat 或 Remix）。
 - 获取相关测试网或主网的 RPC URL。
 - 配置账户管理（例如使用 keystore 钱包）。
- 设置关键参数：代币信息（名称、符号）管理员地址配置初始铸造数量手续费偏好（使用 LINK 或原生 Gas）定义 `remoteChains`，包括目标链的 CCIP 选择器（Chain Selector）和目标地址。
2. **部署合约（每条链上都要部署）：
- 部署 Token 合约（例如 `BurnMintERC677WithCCIPAdmin`）。
- 部署 Token Pool 合约（例如 `BurnMintTokenPool`），并关联到刚部署的 Token 合约地址。 
- **关键步骤：** 从 Token 合约向 Token Pool 合约地址授予必要权限（如 `mint` 和 `burn` 权限）。
 3. **在 CCIP 中注册（每条链上）：**
- 在 `TokenAdminRegistry` 中注册代币管理员。  
    这涉及指定一个管理员地址（如代币拥有者），并要求该地址通过注册表接受管理员角色。
- 使用 `setPool` 函数，将 Token 合约与其对应的 Token Pool 合约进行关联。
4. **配置跨链通道（每条链上）：**
- 在本地链的 Token Pool 合约上调用 `applyChainUpdates`。  
    该函数接收远程链的相关信息，包括其 CCIP Chain Selector、远程 Token Pool 地址，以及从该远程链接收代币的速率限制配置。
 5. **执行跨链转账：**
- 确保源地址持有足够数量的代币（如需可铸造）。
- 授权 CCIP Router 合约可以转移要发送的代币数量。
- 授权 CCIP Router 合约可以支付所需的费用代币（LINK 或原生代币）。
- 准备 `EVM2AnyMessage` 结构体，指定接收地址、代币数量、附加数据（如有）及手续费支付方式。
- 在 CCIP Router 合约上调用 `ccipSend(destinationChainSelector, message)`。
### CCTP
#### 🔁 介绍 Circle 的 CCTP 协议
CCTP 是 Circle 推出的原生 USDC 跨链传输基础设施，安全高效。为更好理解，可将其与传统桥接方式进行对比：
- 传统桥：类似国际银行转账，资金多次中转、效率低、风险高，采用“锁定+铸造”模式（lock-and-mint）。
- CCTP：采用更安全的“销毁+再铸造”机制（burn-and-mint），**不再生成包装代币（Wrapped Token）**，也无需依赖中心化资产托管。
#### 🧯 Burn-and-Mint 机制：
1. **销毁（Burn）**：在源链上将 USDC 永久销毁。
2. **证明（Attestation）**：Circle 的鉴证服务生成链上烧毁证明。
3. **铸造（Mint）**：目标链上的 CCTP 合约验证该证明后，**铸造同等数量的原生 USDC**。

#### 🚀 CCTP 如何工作（以 Standard Transfer 为例）
##### 👣 步骤概览（标准 V1 转移）：
1. **用户发起跨链请求** → 选择目标链、地址、数量。
2. **ERC20 授权** → 调用 `approve` 授权 `TokenMessenger` 花费用户 USDC。
3. **销毁 USDC** → 调用 `depositForBurn` 销毁指定数量的 USDC。
4. **生成证明（Attestation）** → Circle 等待源链“硬确认”，然后发出签名证明。
5. **目标链铸币** → 将证明提交至 `MessageTransmitter`，成功验证后铸造新 USDC。
6. **转账完成** → 目标链用户收到原生 USDC。
##### ⚡ Fast Transfer（V2 新增，初期仅限测试网）
**为了提升转账速度，CCTP V2 引入快速转移模式：**
- 使用“软终局”（更快但有微小重组风险）
- Circle 提供 USDC 缓冲池（Fast Transfer Allowance）垫付目标链 USDC
- 等待后期硬终局达成，再结算缓冲池
```ad-note
## 📘 基本概念：终局（Finality）是什么？
**终局（Finality）** 是指区块链上一笔交易一旦被确认，就**永远不可回滚**、不可重组、不可修改。  
但不同区块链对“终局”的保障机制不同，因此我们区分为 **软终局** 和 **硬终局**。

## ⚙️ 硬终局（Hard Finality）

### ✅ 定义：

一旦某个区块被确认，就**数学上或协议层面不可逆转**，即“100% 确定最终状态”。

## 🌀 软终局（Soft Finality）

### 🟡 定义：

交易被打包进区块后，虽然被链接受了，但在未来有**可能被链重组（reorg）回滚**。

## 🧩 CCTP 为什么要等“硬终局”？

Circle 的 Standard Transfer 模式要等源链交易达到“硬终局”才去目标链铸造 USDC，原因是：

- 避免因为链重组造成“源链烧了但其实没成功”，目标链却铸了，导致 **双花风险（double mint）**。
    
- 对 Circle 来说是“不可逆的跨链责任”，所以要 **最安全的交易确认**。
## 🏎️ Fast Transfer 如何绕开硬终局？

Fast Transfer 不等“硬终局”，只要检测到交易已上链（即便只是软终局），就：
- 让 Circle 提前预支目标链资产
- 后续等源链确认再做清算

所以它**用 Circle 的信用和流动性保障，换来了速度**。

## 📌 总结对比表

|类型|硬终局|软终局|
|---|---|---|
|定义|区块一旦确认就不可逆|有概率被回滚|
|区块链类型|BFT（Cosmos、Avalanche）|PoW/PoS（Ethereum、Bitcoin）|
|安全性|非常高|取决于等待的确认数|
|CCTP 应用|Standard Transfer 必须等待|Fast Transfer 允许软终局|
```
    
#### 👨‍💻 如何用代码实现一次 CCTP 转账？
以 **Sepolia → Base Sepolia 的标准转账为例**（使用 Ethers.js）：
1. 初始化 provider、钱包和合约实例
2. 将目标地址编码为 `bytes32`    
3. 调用 USDC 的 `approve` 授权 TokenMessenger
4. 调用 `depositForBurn` 执行烧毁
5. 监听事件，提取 `messageBytes`，计算 `messageHash`  
6. 轮询 Circle Attestation API，直到 attestation “complete”
7. 调用 `receiveMessage(message, attestation)` 进行目标链铸造
## 代币池合约Pool
### 项目依赖
```ad-note
`forge install smartcontractkit/ccip@v2.17.0-ccip1.5.12 --no-commit`
foundry.toml or remappings.txt
@ccip/=lib/ccip/
```
### 定义代币和代币池
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import {Pool} from "@ccip/contracts/src/v0.8/ccip/libraries/Pool.sol";
import {TokenPool} from "@ccip/contracts/src/v0.8/ccip/pools/TokenPool.sol";
import {IERC20} from "@ccip/contracts/src/v0.8/vendor/openzeppelin-solidity/v4.8.3/contracts/token/ERC20/IERC20.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IRebaseToken} from "./interfaces/IRebaseToken.sol";

// Assume an interface for your custom Rebasing Token exists
interface IRebaseToken is IERC20 {
    function burn(address _from, uint256 _amount) external;
    function mint(address _to, uint256 _amount, uint256 _interestRate) external;
    function getUserInterestRate(address _account) external view returns (uint256);
}

contract RebaseTokenPool is TokenPool {
    // Constructor and functions follow
        constructor(
        address _token, // Use address type for flexibility, cast later
        address[] memory _allowlist,
        address _rmnProxy, // 安全组件的合约
        address _router
    )
        TokenPool(IERC20(_token), 18, _allowlist, _rmnProxy, _router)
    {
        // No additional custom initialization needed here for this example
    }
}
```
### Lock or Burn(Pool)
```c

    function lockOrBurn(Pool.LockOrBurnInV1 calldata lockOrBurnIn)
        external
        override // Explicitly mark as overriding the base function
        onlyRouter // Ensure only the CCIP Router can call this
        returns (Pool.LockOrBurnOutV1 memory lockOrBurnOut) // Named return variable
    {
        // 1. Perform essential security checks from the base contract
        _validateLockOrBurn(lockOrBurnIn);

        // 2. Decode the original sender's address
        address originalSender = abi.decode(lockOrBurnIn.originalSender, (address));

        // 3. Get the user's current interest rate from the Rebasing Token contract
        IRebaseToken rebaseToken = IRebaseToken(address(i_token));
        uint256 userInterestRate = rebaseToken.getUserInterestRate(originalSender);

        // 4. Burn the specified amount of tokens FROM THE POOL'S BALANCE
        rebaseToken.burn(address(this), lockOrBurnIn.amount);

        // 5. Prepare the output data for CCIP
        lockOrBurnOut = Pool.LockOrBurnOutV1({
            // Get the address of the corresponding token contract on the destination chain
            destTokenAddress: getRemoteToken(lockOrBurnIn.remoteChainSelector),
            // ABI encode the user's interest rate to send it cross-chain
            destPoolData: abi.encode(userInterestRate)
        });

        // Implicit return because `lockOrBurnOut` is assigned.
    }
```
### Release or Mint
```c
    function releaseOrMint(Pool.ReleaseOrMintInV1 calldata releaseOrMintIn)
        external
        override // Explicitly mark as overriding the base function
        onlyRouter // Ensure only the CCIP Router can call this
        returns (Pool.ReleaseOrMintOutV1 memory) // Return type specification
    {
        // 1. Perform essential security checks from the base contract
        _validateReleaseOrMint(releaseOrMintIn);

        // 2. Decode the user's interest rate from the incoming poolData
        uint256 userInterestRate = abi.decode(releaseOrMintIn.sourcePoolData, (uint256));

        // 3. Mint tokens to the final receiver using the custom mint function
        IRebaseToken rebaseToken = IRebaseToken(address(i_token));
        rebaseToken.mint(
            releaseOrMintIn.receiver,     // The final recipient address
            releaseOrMintIn.amount,       // The amount transferred
            userInterestRate              // The interest rate from the source chain
        );

        // 4. Return the amount that was successfully minted
        // In this simple case, it's the same as the input amount.
        return Pool.ReleaseOrMintOutV1({
            destinationAmount: releaseOrMintIn.amount
        });
    }

```
## Chainlink fork（分叉链测试）
### Setup
`forge install --no-commit chainlink/chainlink-local@<COMMIT_HASH>
[chainlink local](https://docs.chain.link/chainlink-local/build/ccip/foundry)
```c
[profile.default]
# ... other settings like src, out, libs ...

# Define RPC endpoint aliases
[rpc_endpoints]
sepolia-eth = "YOUR_SEPOLIA_RPC_URL"      # Replace with your actual Sepolia RPC URL
arb-sepolia = "YOUR_ARB_SEPOLIA_RPC_URL"  # Replace with your actual Arbitrum Sepolia RPC URL

# Add remapping for Chainlink Local after installation
[remappings]
# ... other remappings ...
'@chainlink-local/=lib/chainlink-local/'
```
### VM 方法

#### ✅ `vm.createFork(string calldata rpcUrlOrAlias[, uint256 blockNumber])`

> 创建一个新的 EVM fork，但 **不会切换到该 fork 上执行代码**。
```ad-note
参数：
- `rpcUrlOrAlias`: 可以是主网、测试网的 RPC URL，或者在 `foundry.toml` 里定义的别名，如 `"mainnet"`、`"goerli"`。
- `blockNumber`（可选）: 指定分叉的区块高度。若不填，则使用最新区块
返回：
- `uint256 forkId`: 创建的 fork 实例 ID，供后续使用。
```
```ad-important

虽然 fork 被创建了，但当前测试代码 **仍然运行在原始 fork（或主网）环境下**，你需要手动 `vm.selectFork(forkId)` 才能切换。
```
#### ✅ `vm.createSelectFork(string calldata rpcUrlOrAlias[, uint256 blockNumber])`

> 这个是 `createFork` 的增强版本：**创建 fork 的同时立即切换到该 fork 上执行**。

你可以理解为：

```solidity
uint256 forkId = vm.createFork(...);
vm.selectFork(forkId);
```
#### ✅ `vm.selectFork(uint256 forkId)`

> 显式切换当前测试环境上下文到某个已创建的 fork。

- 可用于多链测试：
    
    ```solidity
    uint256 mainnetFork = vm.createFork("mainnet");
    uint256 sepoliaFork = vm.createFork("sepolia");
    
    vm.selectFork(mainnetFork);
    // ...测试主网逻辑...
    
    vm.selectFork(sepoliaFork);
    // ...测试测试网逻辑...
    ```
    

---

#### 🔁 `vm.makePersistent(address account)`

> 将某个地址（合约或账户）**标记为“跨 fork 持久化”**，即使你频繁切换 fork，也不会丢失这个地址的部署和状态。
>比如
>     Chainlink 的本地模拟器（如 VRFCoordinatorMock），你在多个链上测试时希望复用这个合约逻辑。
>     自己写的中间合约，比如测试中的 `MockRouter`，需要跨多个 fork 保持部署和状态一致。

```c
address router = address(new MockRouter());
vm.makePersistent(router);

// 不论你如何 create/select fork，router 地址上的代码都还在，状态也一致。
```
### CrossChain.t.sol
#### Set variables
```c
pragma solidity ^0.8.24;

import {Test, console} from "forge-std/Test.sol";
import {RebaseToken} from "../src/RebaseToken.sol";

import {RebaseTokenPool} from "../src/RebaseTokenPool.sol";

import {Vault} from "../src/Vault.sol";
import {IRebaseToken} from "../src/interfaces/IRebaseToken.sol";

// Import the Chainlink Local Simulator for forked environments
import {CCIPLocalSimulatorFork} from "@chainlink-local/src/ccip/CCIPLocalSimulatorFork.sol";
import {Register} from "@chainlink-local/src/ccip/Register.sol"; // For NetworkDetails struct
import {RegistryModuleOwnerCustom} from "@ccip/contracts/src/v0.8/ccip/TokenAdminRegistry/RegistryModuleOwnerCustom.sol"; // Example path
```
```c
contract CrossChainForkTest is Test {
    // Fork IDs
    uint256 sepoliaForkId;
    uint256 arbSepoliaForkId;

    // Chainlink Local Simulator instance
    CCIPLocalSimulatorFork cciplocalSimulatorFork;

    // Chain Selectors (example values - use actual selectors)
    uint64 sepoliaChainSelector = 16015286601757825753; // Example Sepolia selector
    uint64 arbSepoliaChainSelector = 3478487238524512106; // Example Arb Sepolia selector
	// each Chain Token
	RebaseToken sepoliaToken;
	RebaseToken arbSepoliaToken;
	// Set Vault
	Vault vault;
	// Set Pool
	RebaseTokenPool sepoliaPool;
	RebaseTokenPool arbSepoliaPool;
	//Network Detail
	Register.NetworkDetails sepoliaNetworkDetails;
	Register.NetworkDetails arbSepoliaNetworkDetails;


```
#### Setup function
```c
    // Setup function executed before each test
function setUp() public {
    // 1. Create and select the first fork (Sepolia)
    sepoliaForkId = vm.createSelectFork("sepolia-eth");
    // 2. Create the second fork (Arbitrum Sepolia) but DO NOT select it yet
    arbSepoliaForkId = vm.createFork("arb-sepolia");
    // 3. Deploy the Chainlink Local Simulator ON the currently active fork (Sepolia)
    cciplocalSimulatorFork = new CCIPLocalSimulatorFork();

    // 4. Make the simulator contract address persistent across ALL forks
    vm.makePersistent(address(cciplocalSimulatorFork));

	//5. Source Chain deploy 
    vm.selectFork(sepoliaFork); 
	vm.startPrank(owner);
	sepoliaToken = new RebaseToken(); // Deploy the token contract
	vault = new Vault(IRebaseToken(address(sepoliaToken)));
	
	sepoliaNetworkDetails = ccipLocalSimulatorFork.getNetworkDetails(block.chainid);
	
	sepoliaPool = new RebaseTokenPool(
    IERC20(address(sepoliaToken)), // Cast token address to specific IERC20
    new address[](0),              // Empty allowlist
    sepoliaNetworkDetails.rmnProxyAddress,
    sepoliaNetworkDetails.routerAddress
);

	// Grant roles on Sepolia（Permission）
	sepoliaToken.grantMintAndBurnRole(address(vault));
	sepoliaToken.grantMintAndBurnRole(address(sepoliaPool));	
	// Call registerAdminViaOwner on Sepolia(owner)
	RegistryModuleOwnerCustom
	(sepoliaNetworkDetails.registryModuleOwnerCustomAddress)
    .registerAdminViaOwner(address(sepoliaToken));
    //Accept Admin(not owner)
    TokenAdminRegistry(sepoliaNetworkDetails.tokenAdminRegistryAddress)
    .acceptAdminRole(address(sepoliaToken));
    
	// Link the Sepolia token to the Sepolia pool
	TokenAdminRegistry(sepoliaNetworkDetails.tokenAdminRegistryAddress)
    .setPool(address(sepoliaToken), address(sepoliaPool));

	vm.stopPrank();
	
	//6. Dest Chain deploy
	vm.startPrank(owner);
	arbSepoliaToken = new RebaseToken(); // Deploy the token contract
	
	arbSepoliaNetworkDetails = ccipLocalSimulatorFork.getNetworkDetails(block.chainid);
	
	arbSepoliaPool = new RebaseTokenPool(
	    IERC20(address(arbSepoliaToken)),
	    new address[](0),
	    arbSepoliaNetworkDetails.rmnProxyAddress,
	    arbSepoliaNetworkDetails.routerAddress
		);
	// Grant roles on arbSepolia（Permission）	
	arbSepoliaToken.grantMintAndBurnRole(address(arbSepoliaPool));
	// Call registerAdminViaOwner on arbSepolia
	RegistryModuleOwnerCustom
	(arbSepoliaNetworkDetails.registryModuleOwnerCustomAddress)
    .registerAdminViaOwner(address(arbSepoliaToken));
    // Call acceptAdminRole on Arbitrum Sepolia
	TokenAdminRegistry
	(arbSepoliaNetworkDetails.tokenAdminRegistryAddress)
    .acceptAdminRole(address(arbSepoliaToken));
    
    // Link the arbSepolia token to the arbSepolia pool
	TokenAdminRegistry(arbSepoliaNetworkDetails.tokenAdminRegistryAddress)
    .setPool(address(arbSepoliaToken), address(arbSepoliaPool));
    
	vm.stopPrank();


}
```
```ad-note
接受admin权限时候，在合约上的用户可以不需要为owner
`TokenAdminRegistry
	(arbSepoliaNetworkDetails.tokenAdminRegistryAddress)
    .acceptAdminRole(address(arbSepoliaToken));`
```
```ad-tip
过程
- 部署 Token   
- 部署 Pool + Vault   
- 授权 mint/burn 权限  
- 注册 + 接受管理员身份   
- 设置 Token-Pool 映射
```
#### configureTokenPool
为什么要配置 TokenPool？
部署完每条链上的 Token 和对应的 TokenPool 合约后，它们本身**并不知道其他链上存在谁**。为了实现跨链转账功能（不管是 Burn & Mint 还是 Lock & Unlock 模式），必须**手动将“目标链”的 Pool 和 Token 地址配置到当前链的 Pool 中**，也就是链与链之间 Pool 的**互认绑定关系**。
##### `TokenPool.ChainUpdate`（目标链配置）
```c
struct ChainUpdate {
    uint64 remoteChainSelector;
    bytes remotePoolAddresses; // abi.encode(address)
    bytes remoteTokenAddress;  // abi.encode(address)
    RateLimiter.Config outboundRateLimiterConfig;
    RateLimiter.Config inboundRateLimiterConfig;
}
```
```ad-note
你需要提供目标链的：
- 链 ID（Chain Selector）
- TokenPool 地址（必须 abi.encode）    
- Token 地址（必须 abi.encode）   
- 速率限制（可以禁用）
```
```ad-tip
`RateLimiter.Config`

`
struct Config {
    bool isEnabled;
    uint128 capacity;
    uint128 rate;
}`
如果只是测试用，可以统一设置为：
`RateLimiter.Config({ isEnabled: false, capacity: 0, rate: 0 })`
```

##### ⚙️ 关键函数：`applyChainUpdates`

```solidity
function applyChainUpdates(
    uint64[] calldata remoteChainSelectorsToRemove,
    TokenPool.ChainUpdate[] calldata chainsToAdd
) external virtual onlyOwner;
```
```ad-note
- `remoteChainSelectorsToRemove`: 想移除的目标链 ID（初始化配置时通常是空的）。
    
- `chainsToAdd`: 一组结构体，每个结构体包含某一目标链的配置。
    
```
##### 主代码
```c
function configureTokenPool(
    uint256 fork,
    address localPool,
    uint64 remoteChainSelector,
    address remotePool,
    address remoteTokenAddress
) internal {
    // Switch to the context of the chain being configured
    vm.selectFork(fork);

    // Prepare the update data for the remote chain
    TokenPool.ChainUpdate[] memory chainsToAdd = new TokenPool.ChainUpdate[](1);
    chainsToAdd[0] = TokenPool.ChainUpdate({
        remoteChainSelector: remoteChainSelector,
        // ABI encode remote addresses
        remotePoolAddresses: abi.encode(remotePool),
        remoteTokenAddress: abi.encode(remoteTokenAddress),
        // Disable rate limiting for the test
        outboundRateLimiterConfig: RateLimiter.Config({isEnabled: false, capacity: 0, rate: 0}),
        inboundRateLimiterConfig: RateLimiter.Config({isEnabled: false, capacity: 0, rate: 0})
    });

    // Prepare an empty array for removals (initial config)
    uint64[] memory chainsToRemove = new uint64[](0);

    // Impersonate the owner for the next call only
    vm.prank(owner); // Assumes 'owner' variable holds the pool owner address

    // Call the configuration function on the local pool
    TokenPool(localPool).applyChainUpdates(chainsToRemove, chainsToAdd);
}
```
```ad-tip
- **fork**：你在测试中使用的某条链的 fork（比如 Sepolia 测试链的 fork）。
    
- **localPool**：当前链上你要配置的 TokenPool 合约地址。
    
- **remoteChainSelector**：目标链的唯一标识符（chain selector，来自 CCIP 注册表）。
    
- **remotePool**：目标链上的 TokenPool 合约地址。
    
- **remoteTokenAddress**：目标链上的 Token 合约地址。
```
##### 配置两个链：
```c
configureTokenPool(
    sepoliaFork,
    address(sepoliaPool),
    arbSepoliaNetworkDetails.chainSelector,
    address(arbSepoliaPool),
    address(arbSepoliaToken)
);

configureTokenPool(
    arbSepoliaFork,
    address(arbSepoliaPool),
    sepoliaNetworkDetails.chainSelector,
    address(sepoliaPool),
    address(sepoliaToken)
);
```

这两个调用确保：
- Sepolia Pool 知道 Arbitrum Sepolia Pool
- Arbitrum Sepolia Pool 也知道 Sepolia Pool
### Brigde Token
```c
function bridgeTokens(
        uint256 amountToBridge,
        uint256 localFork,
        uint256 remoteFork,
        Register.NetworkDetails memory localNetworkDetails,
        Register.NetworkDetails memory remoteNetworkDetails,
        RebaseToken localToken,
        RebaseToken remoteToken
    ) public {
        // Create the message to send tokens cross-chain
        vm.selectFork(localFork);
        vm.startPrank(alice);
        Client.EVMTokenAmount[] memory tokenToSendDetails = new Client.EVMTokenAmount[](1);
        Client.EVMTokenAmount memory tokenAmount =
            Client.EVMTokenAmount({token: address(localToken), amount: amountToBridge});
        tokenToSendDetails[0] = tokenAmount;
        // Approve the router to burn tokens on users behalf
        IERC20(address(localToken)).approve(localNetworkDetails.routerAddress, amountToBridge);

        Client.EVM2AnyMessage memory message = Client.EVM2AnyMessage({
            receiver: abi.encode(alice), // we need to encode the address to bytes
            data: "", // We don't need any data for this example
            tokenAmounts: tokenToSendDetails, // this needs to be of type EVMTokenAmount[] as you could send multiple tokens
            extraArgs: "", // We don't need any extra args for this example
            feeToken: localNetworkDetails.linkAddress // The token used to pay for the fee
        });
        // Get and approve the fees
        vm.stopPrank();
        // Give the user the fee amount of LINK
        ccipLocalSimulatorFork.requestLinkFromFaucet(
            alice, IRouterClient(localNetworkDetails.routerAddress).getFee(remoteNetworkDetails.chainSelector, message)
        );
        vm.startPrank(alice);
        IERC20(localNetworkDetails.linkAddress).approve(
            localNetworkDetails.routerAddress,
            IRouterClient(localNetworkDetails.routerAddress).getFee(remoteNetworkDetails.chainSelector, message)
        ); // Approve the fee
        // log the values before bridging
        uint256 balanceBeforeBridge = IERC20(address(localToken)).balanceOf(alice);
        console.log("Local balance before bridge: %d", balanceBeforeBridge);

        IRouterClient(localNetworkDetails.routerAddress).ccipSend(remoteNetworkDetails.chainSelector, message); // Send the message
        uint256 sourceBalanceAfterBridge = IERC20(address(localToken)).balanceOf(alice);
        console.log("Local balance after bridge: %d", sourceBalanceAfterBridge);
        assertEq(sourceBalanceAfterBridge, balanceBeforeBridge - amountToBridge);
        vm.stopPrank();

        vm.selectFork(remoteFork);
        // Pretend it takes 15 minutes to bridge the tokens
        vm.warp(block.timestamp + 900);
        // get initial balance on Arbitrum
        uint256 initialArbBalance = IERC20(address(remoteToken)).balanceOf(alice);
        console.log("Remote balance before bridge: %d", initialArbBalance);
        ccipLocalSimulatorFork.switchChainAndRouteMessage(remoteFork);

        console.log("Remote user interest rate: %d", remoteToken.getUserInterestRate(alice));
        uint256 destBalance = IERC20(address(remoteToken)).balanceOf(alice);
        console.log("Remote balance after bridge: %d", destBalance);
        assertEq(destBalance, initialArbBalance + amountToBridge);
    }
```
```ad-tip
`Client.EVM2AnyMessage` 是 Chainlink CCIP 用于发起跨链消息（包括代币转移）时的核心数据结构，它定义了 **你要发什么、给谁发、用什么支付手续费、附带哪些参数**。
## 🔹结构定义
```c
struct EVM2AnyMessage {
    bytes receiver;                   // 接收方地址（目标链上的地址，使用 abi.encode 编码）
    bytes data;                       // 可选的数据 payload（通常为空）
    EVMTokenAmount[] tokenAmounts;    // 要发送的 token 数组及数量
    address feeToken;                 // 支付手续费用的 token（通常是 LINK）
    bytes extraArgs;                  // 扩展参数，例如 gas 限制
}
```
```ad-tip
## 🔁EVMTokenAmount 是什么？

这是一个结构体，用来表示“发送哪种 token、多少数量”：

```solidity
struct EVMTokenAmount {
    address token;
    uint256 amount;
}
```
```ad-note
**流程**
[开始: bridgeTokens 函数调用] --> B[切换到 localFork 链]
[开始模拟 Alice 操作]
[构造 Client.EVMTokenAmount 数组]
[构造 Client.EVM2AnyMessage 消息体]
[批准 Router 合约花费代币]
[停止 prank，向 Alice 分发 LINK 费用]
[再次启动 prank，批准 LINK 给 Router]
[记录桥接前余额]
[调用 ccipSend 启动跨链转账]
[验证本地余额是否减少]

[切换到 remoteFork 链]
[模拟时间前进 15 分钟]
[记录目标链桥接前余额]
[模拟器调用 routeMessage 执行跨链消息]
[打印目标链用户利率信息]
[记录目标链桥接后余额]
[断言余额增加成功]
[结束]

```
### 部署Token Pool and Vault
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";

import {CCIPLocalSimulatorFork, Register} from "@chainlink-local/src/ccip/CCIPLocalSimulatorFork.sol";

import {IERC20} from "@ccip/contracts/src/v0.8/vendor/openzeppelin-solidity/v4.8.3/contracts/token/ERC20/IERC20.sol";
import {RegistryModuleOwnerCustom} from "@ccip/contracts/src/v0.8/ccip/tokenAdminRegistry/RegistryModuleOwnerCustom.sol";
import {TokenAdminRegistry} from "@ccip/contracts/src/v0.8/ccip/tokenAdminRegistry/TokenAdminRegistry.sol";

import {RebaseToken} from "../src/RebaseToken.sol";
import {RebaseTokenPool} from "../src/RebaseTokenPool.sol";
import {Vault} from "../src/Vault.sol";

import {IRebaseToken} from "../src/interfaces/IRebaseToken.sol";

contract TokenAndPoolDeployer is Script {
    function run() public returns (RebaseToken token, RebaseTokenPool pool) {
        CCIPLocalSimulatorFork ccipLocalSimulatorFork = new CCIPLocalSimulatorFork();
        Register.NetworkDetails memory networkDetails = ccipLocalSimulatorFork.getNetworkDetails(block.chainid);
        vm.startBroadcast();
        token = new RebaseToken();
        pool = new RebaseTokenPool(
            IERC20(address(token)), new address[](0), networkDetails.rmnProxyAddress, networkDetails.routerAddress
        );
        token.grantMintAndBurnRole(address(pool));
        RegistryModuleOwnerCustom(networkDetails.registryModuleOwnerCustomAddress).registerAdminViaOwner(address(token));
        TokenAdminRegistry(networkDetails.tokenAdminRegistryAddress).acceptAdminRole(address(token));
        TokenAdminRegistry(networkDetails.tokenAdminRegistryAddress).setPool(address(token), address(pool));
        vm.stopBroadcast();
    }
}

contract VaultDeployer is Script {
    function run(address _rebaseToken) public returns (Vault vault) {
        vm.startBroadcast();
        vault = new Vault(IRebaseToken(_rebaseToken));
        IRebaseToken(_rebaseToken).grantMintAndBurnRole(address(vault));
        vm.stopBroadcast();
    }
}
```
### Token Configure Script
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";
import {TokenPool} from "@ccip/contracts/src/v0.8/ccip/pools/TokenPool.sol";
import {RateLimiter} from "@ccip/contracts/src/v0.8/ccip/libraries/RateLimiter.sol";

contract ConfigurePoolScript is Script {
    function run(
        address localPool,
        uint64 remoteChainSelector,
        address remotePool,
        address remoteToken,
        bool outboundRateLimiterIsEnabled,
        uint128 outboundRateLimiterCapacity,
        uint128 outboundRateLimiterRate,
        bool inboundRateLimiterIsEnabled,
        uint128 inboundRateLimiterCapacity,
        uint128 inboundRateLimiterRate
    ) public {
        vm.startBroadcast();
        bytes[] memory remotePoolAddresses = new bytes[](1);
        remotePoolAddresses[0] = abi.encode(remotePool);
        TokenPool.ChainUpdate[] memory chainsToAdd = new TokenPool.ChainUpdate[](1);
        chainsToAdd[0] = TokenPool.ChainUpdate({
            remoteChainSelector: remoteChainSelector,
            remotePoolAddresses: remotePoolAddresses,
            remoteTokenAddress: abi.encode(remoteToken),
            outboundRateLimiterConfig: RateLimiter.Config({
                isEnabled: outboundRateLimiterIsEnabled,
                capacity: outboundRateLimiterCapacity,
                rate: outboundRateLimiterRate
            }),
            inboundRateLimiterConfig: RateLimiter.Config({
                isEnabled: inboundRateLimiterIsEnabled,
                capacity: inboundRateLimiterCapacity,
                rate: inboundRateLimiterRate
            })
        });
        TokenPool(localPool).applyChainUpdates(new uint64[](0), chainsToAdd);
    }
}
```
### Bridging Script
```c
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";
import {IRouterClient} from "@ccip/contracts/src/v0.8/ccip/interfaces/IRouterClient.sol";
import {Client} from "@ccip/contracts/src/v0.8/ccip/libraries/Client.sol";
import {IERC20} from "@ccip/contracts/src/v0.8/vendor/openzeppelin-solidity/v4.8.3/contracts/token/ERC20/IERC20.sol";

contract BridgeTokensScript is Script {
    function run(
        address receiverAddress,
        uint64 destinationChainSelector,
        address tokenToSendAddress,
        uint256 amountToSend,
        address linkTokenAddress,
        address routerAddress
    ) public {
        // struct EVM2AnyMessage {
        //     bytes receiver; // abi.encode(receiver address) for dest EVM chains
        //     bytes data; // Data payload
        //     EVMTokenAmount[] tokenAmounts; // Token transfers
        //     address feeToken; // Address of feeToken. address(0) means you will send msg.value.
        //     bytes extraArgs; // Populate this with _argsToBytes(EVMExtraArgsV2)
        // }
        Client.EVMTokenAmount[] memory tokenAmounts = new Client.EVMTokenAmount[](1);
        tokenAmounts[0] = Client.EVMTokenAmount({token: tokenToSendAddress, amount: amountToSend});
        vm.startBroadcast();
        Client.EVM2AnyMessage memory message = Client.EVM2AnyMessage({
            receiver: abi.encode(receiverAddress),
            data: "",
            tokenAmounts: tokenAmounts,
            feeToken: linkTokenAddress,
            extraArgs: Client._argsToBytes(Client.EVMExtraArgsV1({gasLimit: 0}))
        });
        // Caculate Fee and approve
        uint256 ccipFee = IRouterClient(routerAddress).getFee(destinationChainSelector, message);
        IERC20(linkTokenAddress).approve(routerAddress, ccipFee);
        IERC20(tokenToSendAddress).approve(routerAddress, amountToSend);
        // Send Message
        IRouterClient(routerAddress).ccipSend(destinationChainSelector, message);
        vm.stopBroadcast();
    }
}
```
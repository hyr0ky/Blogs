# 编辑器
[Remix](https://remix.ethereum.org/)
# 声明编译器版本
```c
// SPDX-License-Identifier: MIT
pragma solidity 0.8.19;
pragma solidity ^0.8.19;  // greater than or equal to 0.8.19
pragma solidity >=0.8.19 <0.9.0; 
```

# 变量
```c
contract SimpleStorage {//this is  so-called smart contract 
    // Basic types
    bool hasFavoriteNumber = true;
    uint256 favoriteNumber = 88; //often use 256
    string favoriteNumberInText = "eighty-eight";
    int256 favoriteInt = -88;
    address myAddress = 0xaB1B7206AA6840C795aB7A6AE8b15417b7E63a8d;
    bytes32 favoriteBytes32 = "cat";
 
 //array   
    uint256[] list_of_favorite_numbers;//可变长度 ，动态数组
    uint256[3] list_of_favorite_numbers;
    funds = new Array[](0);//重置数组
// struct    
    struct Person {
    uint256 my_favorite_number;
    string name;
	}
	Person public my_friend = new Person();
	Person public my_friend = Person(7, 'Pat');
	Person public my_friend = Person({favorite_number:7,name:'Pat'});
	my_friend.name = "hello";

	function add_person(string memory _name, uint256 _favorite_number) public {
    list_of_people.push(Person(_favorite_number, _name));
    list_of_people.pop();

}
// mapping

mapping (string => uint256) public nameToFavoriteNumber;
nameToFavoriteNumber[_name] = _favoriteNumber;

}
```
```ad-question
给定以下映射映射（地址 - > uint256），访问不存在的键时返回的默认值是多少？
answer: 0
```
```ad-important
memory 类型变量为临时储存，只在函数调用的时候存在 <font color="#ff0000">！！！可修改</font>
calldata  <font color="#ff0000">！！！不可修改的临时变量</font>
<font color="#ff0000">这些只能给数组，结构体，映射这些特殊变量，不能用于uint256 原始变量</font>
```
# 函数
选择 Remix VM
![[Pasted image 20250220205213.png]]
部署然后再 部署后的合同找对应函数功能
![[Pasted image 20250220210103.png]]
```c
contract SimpleStorage {

    uint256 favoriteNumber; //默认 internal

    function store(uint256 _favoriteNumber) public {
    
        favoriteNumber = _favoriteNumber;
    }
    function retrieve() public view returns(uint256) {
    return favoriteNumber;
}
	function retrieve() public pure returns(uint256) {
    return 7;
}
}
```
```ad-tip
每执行一次store相当完成一次交易，区块链会被更新
而view关键字，说明只查看，不对区块链更新（不修改变量什么的）
pure关键字禁止从状态或者变量读数
```
```ad-important

- 🌎 **`public`**: 允许外部和内部合同访问
    
- 🏠 **`private`**: 只允许当前合同访问
    
- 🌲 **`external`**: 用于 _functions_. 只显示在合同外部 _outside_ .
    
- 🏠🏠 **`internal`**: 允许本合同和子合同
```
# 循环
```c
uint256 funderIndex;
for (funderIndex = 0; funderIndex < funders.length; funderIndex++) {
    address funder = funders[funderIndex];
    addressToAmountFunded[funder] = 0;
}
```

# 部署
## 到真正的测试网Speolia
![[Pasted image 20250220215035.png]]
开始部署
![[Pasted image 20250220215117.png]]
在Etherscan去查看是否成功和真实信息
![[Pasted image 20250220215220.png]]
## 部署到Zksync Speolia
点击插件管理器，红色箭头，然后激活Zksync
![[Pasted image 20250221180901.png]]
```ad-note
!!! 1.sol 需放到contracts文件夹下面
环境选择 wallet 链接 metamask
```
# Factory
## Import
```c
import {SimpleStorage} from "./SimpleStorage.sol";
import {SimpleStorage,SimpleStorageb} from "./SimpleStorage.sol";
```
## full code
```c
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.19;

// import {SimpleStorage, SimpleStorage2} from "./SimpleStorage.sol";
import {SimpleStorage} from "./SimpleStorage.sol";

contract StorageFactory {
    SimpleStorage[] public listOfSimpleStorageContracts;

    function createSimpleStorageContract() public {
        SimpleStorage simpleStorageContractVariable = new SimpleStorage();
        // SimpleStorage simpleStorage = new SimpleStorage();
        listOfSimpleStorageContracts.push(simpleStorageContractVariable);
    }

    function sfStore(
        uint256 _simpleStorageIndex,
        uint256 _simpleStorageNumber
    ) public {      listOfSimpleStorageContracts[_simpleStorageIndex].store(_simpleStorageNumber);
//等于 SimpleStorage simple = listOfSimpleStorageContracts[_simpleStorageIndex];
//     simple.store(_simpleStorageNumber) store函数就是我们调用这个函数（导入文件里面有）
    }

    function sfGet(uint256 _simpleStorageIndex) public view returns (uint256) {
        // return SimpleStorage(address(simpleStorageArray[_simpleStorageIndex])).retrieve();
        return listOfSimpleStorageContracts[_simpleStorageIndex].retrieve();
    }
}
```
## 继承
```c
//AddFiveStorage 是SimpleStorage的子合同
contract AddFiveStorage is SimpleStorage {
    function store(uint256 _favoriteNumber) public override {
        myFavoriteNumber = _favoriteNumber + 5;
    }
}
```
```ad-tip
override 声明继承并覆盖父亲合同的函数
但是必须保证父亲合同有virtual关键字即
function store(uint256 _favoriteNumber) public **virtual** {
        myFavoriteNumber = _favoriteNumber + 5;
    }

```
# Foud Me
## 支付一点ETH到合同里面
```c
//payable 表示函数可以接受ETH货币
    function foud() public payable {
    //如果前面条件不满足，输出后面的
	require(msg.value > 1e18,"donnt have engouh money");} 
```
```ad-note
因为payable需要ETH交易，所以需要必须搭配public 或者external
msg.value 为本次交易的ETH 单位为Wei
1e18 Wei = 1e9 GWei = 1 ETH
```
```c 
contract FoudMe{
	uint256 public value = 1;
	function foud() public payable {
		value = value + 2;
		require(msg.value > 1e18,"donnt have engouh money");
    }
}
```
```ad-important
状态变化：当require函数成功的时候，才会执行value = value + 2;
即交易不成功，将退款，交易撤销，将撤销所有状态
```
## 我想知道ETH和usdt的实时汇率
我们需要利用和现实链接在一块的oracle，区块链没法直接调用http一类的
[标准文档](https://docs.chain.link/data-feeds/using-data-feeds)
### 获取聚合器
```c
import {AggregatorV3Interface} from "@chainlink/contracts/src/v0.8/shared/interfaces/AggregatorV3Interface.sol";
function getVersion() public view returns (uint256) {
    return
    // AggregatorV3Interface里面是需要我们访问到oracle 汇率聚合器的地址
    AggregatorV3Interface(0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419).version();
}
```
[汇率聚合地址的地址](https://docs.chain.link/data-feeds/price-feeds/addresses?network=ethereum&page=1)
### 获得汇率
```c
//原型函数
    function getChainlinkDataFeedLatestAnswer() public view returns (int) {
        // prettier-ignore
        (
            /* uint80 roundID */,
            int answer,
            /*uint startedAt*/,
            /*uint timeStamp*/,
            /*uint80 answeredInRound*/
        ) = dataFeed.latestRoundData();
        return answer;
    }
}
```
```c
function getLatestPrice() public view returns (uint256) {
//获得以Wei度量的USDT
AggregatorV3Interface priceFeed = AggregatorV3Interface(0x1b44F3514812d835EB1BDB0acB33d3fA3351Ee43);

(,int256 price,,,) = priceFeed.latestRoundData();

return uint256(price) * 1e10;
```
```ad-question
为什么乘以1e10
区块链里没有所谓的小数，用的Wei去代表小数，
ETH有18个小数和对于1e18Wei
而USDT对应8个小数点，在聚合其中获得的，所以乘以1e10
```
```c
function getConversionRate(uint256 usdtAmount) internal view returns (uint256) {
    uint256 usdtPrice = getPrice();//usdt的eth价格
    uint256 ethAmountInUsd = (usdtPrice * usdtAmount) / 1e18;
    return ethAmountInUsd;
}
```
```ad-question
为什么需要除以1e18
usdt以18为衡量
5usdt = 5\*1e18
因为1e18\*1e18=1e36 而我们需要的明显是1e18
```
```ad-question
### 为什么在 Solidity 中需要 **先乘后除** 来保持精度？

这是由 **Solidity 的整数除法特性** 决定的。Solidity 不支持浮点数运算，所有除法操作 (`/`) 都会自动 **向下取整**（丢弃小数部分）。如果直接先做除法，可能会导致计算结果完全丢失精度，而先乘后除可以保留更多有效数字。
#### 举个直观的例子 🌰

假设要计算 `5 / 3 = 1.666...`，但需要保留两位小数（例如代币金额）。

1. **错误方法（先除后乘）**
    uint256 result = (5 / 3) \* 100;  // (5/3)=1 → 1\*100=100 → 实际得到 1.00
    
    结果完全丢失了小数部分！
    
2. **正确方法（先乘后除）**

    uint256 result = (5 \* 100) / 3;  // 500/3=166 → 实际得到 1.66
    
    成功保留两位小数，精度更高。
```
### Libray
```c
// "./PriceConverter.sol"
library PriceConverter {
    function getPrice() internal view returns (uint256) {
        AggregatorV3Interface priceFeed = AggregatorV3Interface(0x694AA1769357215DE4FAC081bf1f309aDC325306);
        (, int256 answer, , , ) = priceFeed.latestRoundData();
        return uint256(answer * 10000000000);
    }

    function getConversionRate(uint256 ethAmount) internal view returns (uint256) {
        uint256 ethPrice = getPrice();
        uint256 ethAmountInUsd = (ethPrice * ethAmount) / 1000000000000000000;
        return ethAmountInUsd;
    }
}
```
```ad-tip
library 里面函数需要internal
```
### 访问库
```c
import {PriceConverter} from "./PriceConverter.sol";
using PriceConverter for uint256;
```
```ad-question
using PriceConverter for uint256; 声明为uint256的原生
即是该函数集合到uint256里面
便可以这么用
require(msg.value.getConversionRate() >= minimumUsd, "didn't send enough ETH");
```
## SafeMath
早期版本0.8.0以前，现在的会检查并报错
```c
// SafeMathTester.sol
pragma solidity ^0.6.0;

contract SafeMathTester {
    uint8 public bigNumber = 255;//最大255

    function add() public {
        bigNumber = bigNumber + 1;
    }
}
//当达到256会重置为0，257即为1
```
```c
uint8 public bigNumber = 255;
//忽略溢出
function add() public {
    unchecked {
        bigNumber = bigNumber + 1;
    }
}
```

## 提款合同里面的ETH
```c
    function withdraw() public onlyOwner {
        for (uint256 funderIndex = 0; funderIndex < funders.length; funderIndex++) {
            address funder = funders[funderIndex];
            addressToAmountFunded[funder] = 0;
        }
        funders = new address[](0);
        //this 当前合同的余额
        // // transfer
       //payable(address)    transfer（）发送余额
		payable(msg.sender).transfer(address(this).balance);

        // // send
        bool sendSuccess = payable(msg.sender).send(address(this).balance);
        require(sendSuccess, "Send failed");

        // call
        (bool callSuccess,) = payable(msg.sender).call{value: address(this).balance}("");
        require(callSuccess, "Call failed");
    }

```
```ad-note
### **核心区别**

|**属性**|`address(this).balance`|`msg.value`|
|---|---|---|
|**作用对象**|合约地址的 **累计 ETH 余额**|单次交易中用户发送的 **当前 ETH 金额**|
|**数据来源**|区块链上合约地址的实时余额|用户调用函数时附加的 ETH|
|**单位**|Wei（1 ETH = 10¹⁸ Wei）|Wei|
|**可变性**|随合约接收或转出 ETH 动态变化|仅在当前函数调用中有效，不可变|
|**典型用途**|查询合约总余额、批量转账、条件校验|处理单次交易的金额、校验用户支付是否足够|
```
```ad-question
为什么重置数组
假设合约用于阶段性众筹：

1. 用户A、B、C资助，`funders`记录三者地址。
    
2. 所有者调用`withdraw`，资金被提取，各地址金额归零。
    
3. **若不重置数组**：下次调用`withdraw`会再次遍历A、B、C（无意义循环，浪费Gas）。
    
4. **重置数组后**：`funders`变为空，后续操作无需处理旧数据，准备下一轮众筹。
    
```
```ad-important

限制最高2300gas
- `transfer` (2300 gas, throws error)出错报错，撤销交易
- `send` (2300 gas, returns bool)出错返回bool值
- `call` (forward all gas or set gas, returns bool)
```
```c
(bool success, bytes memory data) = address(target).call{value: amount, gas: gasLimit}(abi.encodeWithSignature("函数签名", 参数));
```
```ad-note
**ABI（Application Binary Interface，应用二进制接口）** 是智能合约与外部世界（如其他合约、前端应用或工具）交互的标准化接口。它定义了如何编码和解码数据，以便外部系统能够正确调用合约的函数或解析合约的事件。在区块链开发中，ABI 是智能合约与外部交互的桥梁。
```
### 权限的问题
```ad-note
`msg.sender` 表示**当前调用合约函数的外部账户地址**
在部署是合同部署者，在部署后调用不在是合同部署者，所以通常需要额外声明owner
```
```c
    address public owner;
    //在部署时刻立即执行
    constructor() {
        owner = msg.sender;
    }
    //创建一个关键字onlyOwner
    modifier onlyOwner() {
        // require(msg.sender == owner);
        if (msg.sender != owner) revert NotOwner();
        _;
    }

```
```ad-important
### **`_` 的位置与执行流程**

#### 1. **前置条件（`_` 在末尾）**
modifier beforeAction {
    // 先执行某些操作
    _; // 再执行函数本体
}

- **逻辑**：先执行 `modifier` 中的代码，再执行函数本体。
    

#### 2. **后置条件（`_` 在开头）**
modifier afterAction {
    _; // 先执行函数本体
    // 再执行某些操作
}

- **逻辑**：先执行函数本体，再执行 `modifier` 中的代码。
    

#### 3. **包裹逻辑（`_` 在中间）**
modifier wrapAction {
    // 执行前置操作
    _; // 执行函数本体
    // 执行后置操作
}

- **逻辑**：函数本体被夹在前置和后置操作之间。
```
### 节省一点GAS

```ad-note
使用 `constant` 关键词声明常量可以节约GAS
必须在声明时赋值，且值在**编译时确定**（硬编码）。
通常命名为大写
部署时候的不可变量可以用 `immutable` 关键词声明常量可以节约GAS
可在声明时或**构造函数中赋值一次**，值在**部署时确定**。
通常命名为i_xxx  eg. i_owner

|**特性**|**`constant`**|**`immutable`**|
|---|---|---|
|**初始化时间**|编译时|构造函数中（部署时）|
|**赋值依赖**|必须是编译期常量|可依赖构造函数参数或运行时数据|
|**Gas 成本**|最低（直接内联）|较低（写入代码段）|
|**适用类型**|值类型、固定长度简单类型|值类型、部分复杂类型（如 `string`）|
|**典型用例**|数学常数、固定地址|合约所有者、部署时间戳|
|key|一直不变的|可以由部署者修改|
```

```c
error NotOwner();//在合同外面
//在合同里面 用这个替换require
if (msg.sender != i_owner) {
    revert NotOwner();
}
```
## 意外的情况
合同都是存在一个合同地址的，如果有人直接给这个地址汇款 ，但是不去调用fund函数怎么办
```c
// Ether is sent to contract
//      is msg.data empty?
//          /   \
//         yes  no
//         /     \
//    receive()?  fallback()
//     /   \
//   yes   no
//  /        \
//receive()  fallback()
    fallback() external payable {
        fund();
    }

    receive() external payable {
        fund();
    }
```
```ad-note
|**交易类型**|**触发函数**|**典型场景**|
|---|---|---|---|
|纯 ETH 转账（无数据 `data`）|`receive`|用户直接向合约地址发送 ETH|
|调用未定义函数（含数据 `data`）|`fallback`|前端误调用函数或攻击者尝试漏洞探测|
|调用已定义函数|目标函数|正常业务逻辑调用|

```
## 部署到Zksync的区别
```c
AggregatorV3Interface priceFeed = AggregatorV3Interface(0xfEefF7c3fB57d18C5C6Cdd71e45D2D0b4F9377bF); 
// Add ETH/USD ZKsync Sepolia address here
``` 
## 时间戳
`block.timestamp` 单位s
# 验证一个合同是否安全正常
In order to verify our transactions we need to:

1. Check the address
    
    - Verify the contract we're interacting with is what's expected
        
2. Check the function selector
    
    - Verify the provided function selector vs the function on the contract we expect to be calling
        
3. Decode the calldata
    
    - Verify the calldata to assure the parameters being sent to the function are what we expect to be sending.
# 抽象合约
```c
abstract contract CodeConstants {
    uint256 public constant ETH_SEPOLIA_CHAIN_ID = 11155111;
    uint256 public constant LOCAL_CHAIN_ID = 31337;
}
contract xxx is CodeConstants{

//必须继承才能使用
}
```
# abi函数
## **常用方法**

- ​`abi.encode(...)`
    保留类型信息，按固定长度（32字节）填充参数。
```c
    bytes memory data = abi.encode(uint256(123), "abc"); 
    // 编码结果包含完整的类型信息
```
- ​`abi.encodePacked(...)`
    紧密打包数据，无填充。适用于哈希场景，但需注意类型碰撞风险
    ```c
    bytes memory packedData = abi.encodePacked(uint8(1), uint8(2)); 
    // 结果为0x0102
    ```
    
- ​`abi.encodeWithSelector(bytes4 selector, ...)`* 
    生成带有函数选择器的调用数据。
    ```c
    bytes4 selector = bytes4(keccak256("transfer(address,uint256)"));
    bytes memory data = abi.encodeWithSelector(selector, to, amount);
    ```
    
- ​`abi.encodeWithSignature(string memory signature, ...)`
    根据函数签名生成调用数据，自动计算选择器。
    ```c
    bytes memory data = abi.encodeWithSignature("transfer(address,uint256)", to, amount);
    ```
- `abi.decode(bytes memory encodedData, (Type1, Type2, ...))`
```c
//eg 1.
function encodeDecodeArray() public pure returns (uint256[] memory) {
    uint256[] memory arr = new uint256[](3);
    arr[0] = 1;
    arr[1] = 2;
    arr[2] = 3;
    
    bytes memory encoded = abi.encode(arr);
    uint256[] memory decoded = abi.decode(encoded, (uint256[]));
    return decoded; // [1, 2, 3]
}

//eg 2.
struct Transaction {
    address sender;
    address recipient;
    bytes payload;
}

function decodeTransaction(bytes memory data) public pure {
    Transaction memory tx = abi.decode(data, (Transaction));
    // 使用 tx.sender, tx.recipient, tx.payload
}
```
# call 
- `(bool success, bytes memory data) = address(target).call{value: msg.value}(data);`
```c
address token = 0x...;
bytes memory data = abi.encodeWithSignature("transfer(address,uint256)", to, amount);
(bool success, bytes memory result) = token.call(data);
require(success, "Call failed");
```
- `(bool success, bytes memory data) =address(target).staticcall(data);`

| **特性**     | **call**            | **staticcall** |
| ---------- | ------------------- | -------------- |
| **状态修改**   | ✅ 允许                | ❌ 禁止           |
| **ETH 转账** | ✅ 支持 `{value: ...}` | ❌ 不支持          |
| **Gas 消耗** | 消耗 Gas（执行代码）        | 可能不消耗（仅查询）     |
| **安全性**    | 需手动检查回滚             | 自动阻止状态修改       |
| **典型场景**   | 转账、状态更新             | 数据查询、配置读取      |
## more selector 
```c
//1
function getSelectorTwo() public view returns (bytes4 selector) {
        bytes memory functionCallData = abi.encodeWithSignature("transfer(address,uint256)", address(this), 123);
        selector =
            bytes4(bytes.concat(functionCallData[0], functionCallData[1], functionCallData[2], functionCallData[3]));
    }
//2
  function getSelectorThree(bytes calldata functionCallData) public pure returns (bytes4 selector) {
        // offset is a special attribute of calldata
        assembly {
            selector := calldataload(functionCallData.offset)
        }
    }

//3
 function getSelectorFour() public pure returns (bytes4 selector) {
        return this.transfer.selector;
    }
```
```ad-question
 为什么例子中//1访问了0到3 
**EVM 设计规范**：以太坊虚拟机（EVM）规定函数选择器长度为 ​**4字节**，这是为了在保证唯一性的前提下，尽量减少调用数据的长度，降低 Gas 消耗。
```
# 内联汇编
内联汇编（Inline Assembly）是 Solidity 中允许开发者直接编写 EVM 底层操作码（opcode）的功能

### **1. 基本语法**
在 Solidity 中使用 `assembly` 关键字开启汇编块：
```c
function example() public pure {
    // 内联汇编块
    assembly {
        // EVM 操作码和 Yul 语法
    }
}
```

---

### **2. 核心操作码**

#### **(1) 内存操作**
• **`mstore(offset, value)`**  
  将 `value`（32字节）写入内存的 `offset` 位置。
  ```c
  assembly {
      mstore(0x80, 0x1234) // 在内存 0x80 处写入 0x1234
  }
  ```

• **`mload(offset)`**  
  从内存 `offset` 处读取 32 字节数据。
  ```c
  assembly {
      let value := mload(0x80) // 读取内存 0x80 处的值
  }
  ```

#### **(2) 存储操作**
• **`sstore(slot, value)`**  
  将 `value` 写入存储槽 `slot`。
  ```c
  assembly {
      sstore(0, 0x1234) // 在存储槽 0 写入 0x1234
  }
  ```

• **`sload(slot)`**  
  从存储槽 `slot` 读取值。
  ```c
  assembly {
      let value := sload(0) // 读取存储槽 0 的值
  }
  ```

#### **(3) 调用数据操作**
• **`calldataload(offset)`**  
  从 `calldata` 的 `offset` 处读取 32 字节数据。
  ```solidity
  assembly {
      let selector := calldataload(0) // 读取函数选择器（前4字节）
  }
  ```
### **3. 变量与类型**
#### **(1) 变量声明**
使用 `let` 声明变量，类型由首次赋值决定：
```c
assembly {
    let x := 0x42        // x 的类型为 uint256
    let y := "abc"       // y 的类型为 bytes32（右填充到32字节）
}
```

#### **(2) 类型转换**
Yul（汇编语言）是静态类型的，需显式转换：
```c
assembly {
    let a := 0x1234
    let b := and(a, 0xffff) // 将 a 截断为 2 字节
}
```

---

### **4. 控制流**
#### **(1) 条件判断**
```c
assembly {
    if eq(value, 0) {
        // value == 0 时执行
    }
}
```

#### **(2) 循环**
```c
assembly {
    for { let i := 0 } lt(i, 10) { i := add(i, 1) } {
        // 循环10次
    }
}
```

---

### **5. 实战示例**

#### **(1) 高效计算 Keccak-256 哈希**
```c
function getHash(bytes memory data) public pure returns (bytes32 hash) {
    assembly {
        // data.offset 是数据起始位置，data.length 是长度
        hash := keccak256(add(data, 0x20), mload(data))
    }
}
```
• **`add(data, 0x20)`**：跳过 `bytes` 的长度字段（前32字节）。
• **`mload(data)`**：读取 `bytes` 的实际长度。

#### **(2) 直接操作存储变量**
```c
uint256 public count;

function increment() public {
    assembly {
        let c := sload(0)        // 读取存储槽 0（count）
        sstore(0, add(c, 1))    // count += 1
    }
}
```

---

### **6. 高级技巧**

#### **(1) 内存布局优化**
手动管理内存可减少 Gas 消耗：
```solidity
function pack(uint256 a, uint256 b) public pure returns (bytes32) {
    bytes32 result;
    assembly {
        mstore(0x80, a)     // 写入 a 到 0x80
        mstore(0xA0, b)     // 写入 b 到 0xA0
        result := mload(0x80) // 读取合并后的数据（实际需更复杂处理）
    }
    return result;
}
```

#### **(2) 函数选择器提取**
```c
function getSelector(bytes calldata data) public pure returns (bytes4 selector) {
    assembly {
        selector := calldataload(data.offset)
    }
}
```




